import Foundation
import ControllerCore

@MainActor
final class IntentCheckClock {
    var uptime: Double = 1000
    var wall: Double = 1_800_000_000
    func advance(_ amount: Double) { uptime += amount; wall += amount }
}
@MainActor
final class IntentCheckTransport: BridgeTransporting {
    var onReady: (() -> Void)?
    var onMessage: ((Data) -> Void)?
    var onFailure: ((String) -> Void)?
    var sent: [SCX2Packet] = []
    var closed: [SCX2Packet] = []
    var opened: [(String, UInt16)] = []
    func open(host: String, port: UInt16) { opened.append((host, port)); onReady?() }
    func send(_ data: Data) { sent.append(try! SCX2Codec.decode(data)) }
    func close(afterSending data: Data?) { if let data { closed.append(try! SCX2Codec.decode(data)) } }
    func reply(_ packet: SCX2Packet) { onMessage?(try! SCX2Codec.encode(packet)) }
    var hello: SCX2Packet { sent.last(where: { $0.kind == .hello })! }
    func offer(unavailable: Bool = false) {
        let request = hello
        reply(.init(kind: .ready, session: request.session,
                    boot: .init(bytes: Array(repeating: 11, count: 16)),
                    challenge: unavailable ? .zero : .init(bytes: Array(repeating: 12, count: 16)),
                    hidReady: !unavailable, revision: request.revision,
                    pressureCapability: !unavailable && request.revision == .pressure))
    }
    func acknowledge(_ state: SCX2Packet) {
        reply(.init(kind: .ack, session: state.session, boot: state.boot, challenge: state.challenge,
                    sequence: state.sequence, hidReady: true, revision: state.revision))
    }
    func arm() { offer(); acknowledge(sent.last!) }
}

@main
struct ConnectionIntentClientChecks {
    @MainActor
    static func main() throws {
        var checks = 0
        var domains: [String] = []
        func require(_ value: @autoclosure () -> Bool, _ explanation: String) {
            guard value() else { fatalError("Connection intent check failed: \(explanation)") }
            checks += 1
        }
        func defaults() -> UserDefaults {
            let name = "connection-intent-check-\(UUID().uuidString)"; domains.append(name)
            return UserDefaults(suiteName: name)!
        }
        defer { for domain in domains { UserDefaults.standard.removePersistentDomain(forName: domain) } }
        func model(_ store: UserDefaults, _ link: IntentCheckTransport, _ clock: IntentCheckClock) -> ControllerViewModel {
            ControllerViewModel(defaults: store, transport: link, clock: { clock.uptime }, wallClock: { clock.wall }, resumeClock: { clock.uptime }, automaticTimer: false)
        }
        func connect(_ model: ControllerViewModel, _ link: IntentCheckTransport, pressure: Bool = false) {
            model.host = "192.168.1.80"; model.portText = "42736"
            model.setBridgeTriggerPressureEnabled(pressure); model.setMode(.bridge); model.connect(); link.arm()
        }
        for pressure in [false, true] {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let subject = model(store, link, clock)
            connect(subject, link, pressure: pressure)
            require(subject.isReady && subject.connectionRequested, "Explicit Connect creates live intent")
            subject.updateOutput(.init(gamepad: .init(buttons: [.a]), leftTrigger: pressure ? 0.4 : 0,
                                       rightTrigger: pressure ? 0.8 : 0), epoch: subject.inputEpoch)
            let down = link.sent.last!, oldReply = link.onMessage, oldFailure = link.onFailure
            subject.updateOutput(.init(gamepad: .init(buttons: [.b])), epoch: subject.inputEpoch)
            subject.updateOutput(.neutral, epoch: subject.inputEpoch)
            let oldEpoch = subject.inputEpoch, oldSession = link.hello.session
            subject.cancelQueuedInput(reason: "Page changed")
            require(subject.connectionRequested && !subject.controlsEnabled && subject.state.isNeutral,
                    "Navigation pauses old input while retaining intent")
            require(link.closed.last?.kind == .stop && link.hello.session != oldSession,
                    "Navigation retires queued presses and starts a fresh session")
            let latestCount = link.sent.count, currentSession = link.hello.session
            oldReply?(try SCX2Codec.encode(.init(kind: .ack, session: down.session, boot: down.boot,
                       challenge: down.challenge, sequence: down.sequence, hidReady: true, revision: down.revision)))
            oldFailure?("old socket error")
            subject.updateOutput(.init(gamepad: .init(buttons: [.x])), epoch: oldEpoch)
            require(link.sent.count == latestCount && link.hello.session == currentSession,
                    "Old replies, failures and fingers cannot disturb the replacement")
            subject.cancelQueuedInput(reason: "Next page")
            require(link.hello.session == currentSession, "Rapid pages retain one bounded neutral attempt")
            link.offer(unavailable: true)
            require(subject.isConnecting && !subject.isReady, "Automatic retry waits through receiver neutral barrier")
            link.offer()
            let neutral = link.sent.last!
            require(neutral.sequence == 1 && neutral.output == .neutral && !subject.controlsEnabled,
                    "Both protocol revisions require fresh neutral USB acknowledgement")
            subject.updateOutput(.init(gamepad: .init(buttons: [.y])), epoch: subject.inputEpoch)
            link.acknowledge(neutral)
            require(subject.isReady && subject.outputState == .neutral, "Touches while paused never replay after acknowledgement")
            subject.releaseAll()
            require(subject.connectionRequested && !subject.controlsEnabled, "Release all preserves connection intent")
            link.arm()
            subject.stop()
            let stoppedCount = link.opened.count
            clock.advance(10); subject.tick(); link.offer()
            require(!subject.connectionRequested && !subject.isReady && link.opened.count == stoppedCount,
                    "Explicit Disconnect prevents every later retry")
            require(store.data(forKey: ControllerViewModel.connectionIntentKey) == nil, "Disconnect removes resumable intent")
        }
        // Retry deadlines are bounded and don't renew on page changes or unready replies.
        do {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let subject = model(store, link, clock); connect(subject, link)
            subject.cancelQueuedInput(reason: "Page changed")
            let first = link.hello.session
            clock.advance(2.99); link.offer(unavailable: true); subject.cancelQueuedInput(reason: "Another page")
            clock.advance(0.01); subject.tick()
            require(subject.connectionRequested && !subject.isReady && link.hello.session == first,
                    "Availability waiting expires at its original deadline")
            let count = link.opened.count
            clock.advance(0.99); subject.tick(); require(link.opened.count == count, "Recovery honors backoff")
            clock.advance(0.01); subject.tick()
            require(link.opened.count == count + 1 && link.hello.session != first,
                    "A failed bounded attempt automatically starts a fresh attempt")
            subject.setMode(.practice); clock.advance(20); subject.tick()
            require(!subject.connectionRequested && subject.mode == .practice, "Practice deliberately cancels connection intent")
        }
        // Five-minute absence and process restoration never restore held controls.
        for elapsed in [0.5, 299.99, 300, 400] {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let subject = model(store, link, clock); connect(subject, link)
            subject.updateInput(.init(buttons: [.a]), epoch: subject.inputEpoch)
            subject.setForeground(false)
            let saved = store.data(forKey: ControllerViewModel.connectionIntentKey)
            clock.advance(elapsed / 2); subject.setForeground(false); subject.tick()
            require(store.data(forKey: ControllerViewModel.connectionIntentKey) == saved,
                    "Repeated background callbacks never renew the absence timestamp")
            clock.advance(elapsed / 2); subject.setForeground(true)
            require(subject.connectionRequested == (elapsed < 300), "The five-minute background boundary is exact")
            require(!subject.controlsEnabled && subject.state.isNeutral, "Returning cannot restore old held input")
            if elapsed < 300 { link.arm(); require(subject.isReady && subject.state.isNeutral, "Short absence resumes neutral automatically") }
            subject.stop()
        }
        for elapsed in [1.0, 299.0, 300.0] {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let old = model(store, link, clock); connect(old, link)
            let profileBytes = Data("layout unchanged".utf8)
            store.set(profileBytes, forKey: "controller.profiles.v1")
            clock.advance(elapsed)
            let replacementLink = IntentCheckTransport(), replacement = model(store, replacementLink, clock)
            require(replacementLink.opened.isEmpty, "Process restoration does not open transport before foreground confirmation")
            replacement.setForeground(true)
            require(replacement.connectionRequested == (elapsed < 300), "Short process closure restores intent; extended closure does not")
            require(store.data(forKey: "controller.profiles.v1") == profileBytes, "Intent restoration does not rewrite saved layouts")
            if elapsed < 300 { replacementLink.arm(); require(replacement.isReady && replacement.state.isNeutral, "Relaunch is neutral-ACK gated") }
            replacement.stop(); old.stop()
        }
        // Input uptime may stop during phone sleep; intent expiry uses a separate continuous clock.
        do {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            var continuous: TimeInterval = 2000
            let subject = ControllerViewModel(defaults: store, transport: link, clock: { clock.uptime },
                wallClock: { clock.wall }, resumeClock: { continuous }, automaticTimer: false)
            connect(subject, link); subject.setForeground(false)
            clock.wall += 30; continuous += 30 // The gesture clock intentionally stays unchanged.
            subject.setForeground(true)
            require(subject.connectionRequested && subject.isConnecting, "Thirty seconds of phone sleep resumes with the continuous clock")
            link.arm(); require(subject.isReady && subject.state.isNeutral, "Sleep resume remains neutral-ACK gated")
            subject.stop()
        }
        for rollback in [true, false] {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let original = model(store, link, clock); connect(original, link)
            if rollback { clock.wall -= 1 } else { clock.uptime = 1 }
            let restoredLink = IntentCheckTransport(), restored = model(store, restoredLink, clock)
            restored.setForeground(true)
            require(!restored.connectionRequested && restoredLink.opened.isEmpty, "Clock rollback or reboot cannot restore a stale intent")
            original.stop()
        }
        // Foreground retries keep crash recovery fresh, with bounded preference writes.
        do {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let subject = model(store, link, clock); connect(subject, link)
            let original = store.data(forKey: ControllerViewModel.connectionIntentKey)
            clock.advance(0.5); subject.tick()
            require(store.data(forKey: ControllerViewModel.connectionIntentKey) == original,
                    "Fifty-millisecond heartbeats do not rewrite intent on every tick")
            clock.advance(0.5); subject.tick()
            require(store.data(forKey: ControllerViewModel.connectionIntentKey) != original,
                    "Intent metadata refreshes at the bounded one-second cadence")
            clock.advance(310); subject.tick() // Still foreground, but no bridge replies.
            let replacementLink = IntentCheckTransport(), replacement = model(store, replacementLink, clock)
            replacement.setForeground(true)
            require(replacement.connectionRequested && replacement.isConnecting,
                    "Foreground retry waiting does not make a quick process relaunch look like a long absence")
            replacement.stop(); subject.stop()
        }
        // Form edits cannot move the live connection until explicit Save.
        do {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            let subject = model(store, link, clock); connect(subject, link)
            subject.host = "192.168.1.90"; subject.portText = "43000"
            subject.cancelQueuedInput(reason: "Profile changed")
            require(link.opened.last?.0 == "192.168.1.80" && link.opened.last?.1 == 42736,
                    "Resynchronization uses the connected endpoint rather than unsaved settings")
            link.arm(); subject.saveSettings()
            require(link.opened.last?.0 == "192.168.1.90" && link.opened.last?.1 == 43000,
                    "Explicit Save applies the new validated endpoint")
            subject.host = "invalid"; subject.saveSettings()
            let count = link.opened.count; clock.advance(10); subject.tick()
            require(subject.connectionRequested && !subject.isReady && link.opened.count == count,
                    "Invalid saved target pauses instead of reconnecting to the old address")
            subject.stop()
        }
        // Navigation, profile changes and sheets preserve intent and clear macro/touch owners.
        do {
            let store = defaults(), link = IntentCheckTransport(), clock = IntentCheckClock()
            var profile = try ControllerProfile(name: "Connection checks")
            let home = profile.homePageID, second = try profile.addPage(name: "Drive")
            let macro = ProfileControl(name: "Macro", payload: "X360A(U500),X360B(D700)", macroModeEnabled: true)
            let back = ProfileControl(name: "Back", kind: .pageButton, pageNavigation: .goTo(home))
            try profile.addControl(macro, toPage: home); try profile.addControl(back, toPage: second)
            let another = try ControllerProfile(name: "Other")
            let library = try ControllerProfileLibrary(activeProfileID: profile.id, profiles: [profile, another])
            let bytes = try ControllerProfileLibraryCodec.encode(library)
            store.set(bytes, forKey: ProfileControllerViewModel.libraryKey)
            let subject = ProfileControllerViewModel(defaults: store, transport: link, clock: { clock.uptime },
                wallClock: { clock.wall }, resumeClock: { clock.uptime }, automaticTimer: false)
            subject.host = "192.168.1.80"; subject.setMode(.bridge); subject.connect(); link.arm()
            let oldEpoch = subject.inputEpoch
            subject.handleInput(.begin(contact: 1, control: macro.id, position: .zero), epoch: oldEpoch)
            subject.handleInput(.end(contact: 1), epoch: oldEpoch)
            subject.selectPage(second)
            require(subject.currentPageID == second && subject.connectionRequested && subject.state.isNeutral,
                    "Header page selection releases running macros without losing connection intent")
            link.arm(); subject.tickInput(epoch: oldEpoch)
            require(subject.currentPageID == second && subject.state.isNeutral, "Neutral ACK preserves the selected page and fences old timers")
            subject.handleInput(.begin(contact: 2, control: back.id, position: .zero), epoch: subject.inputEpoch)
            require(subject.currentPageID == home && subject.connectionRequested && !subject.controlsEnabled,
                    "On-canvas page buttons use the same automatic neutral resynchronization")
            link.arm()
            require(store.data(forKey: ProfileControllerViewModel.libraryKey) == bytes,
                    "Changing pages preserves exact saved library bytes")
            subject.beginProfileManagement(); require(subject.connectionRequested && !subject.controlsEnabled, "Profile manager retains intent")
            require(subject.selectProfile(another.id), "A different profile can be selected")
            subject.finishProfileManagement(); link.arm()
            require(subject.profile.id == another.id && subject.isReady && subject.state.isNeutral,
                    "Selected profile resumes neutral automatically")
            subject.beginLayoutEditing(); link.arm()
            require(subject.connectionRequested && !subject.controlsEnabled, "Editing remains paused even after network recovery")
            subject.cancelLayoutEditing(); link.arm()
            subject.prepareSettings(); link.arm()
            require(!subject.controlsEnabled && subject.connectionRequested, "Settings retains the connection but disables controls")
            subject.finishSettings(); link.arm()
            require(subject.isReady && subject.controlsEnabled, "Leaving settings resumes through a neutral handshake")
            require(subject.library.profiles == library.profiles, "Profile contents are unchanged across all navigation and modal transitions")
            subject.stop()
        }
        print("PASS: \(checks) persistent connection app checks; no hardware output.")
    }
}
