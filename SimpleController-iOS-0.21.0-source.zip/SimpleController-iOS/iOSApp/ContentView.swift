import SwiftUI
import UIKit
import ControllerCore

@MainActor
struct ContentView: View {
    @StateObject private var model = ProfileControllerViewModel()
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @State private var showingControls = false
    @State private var nextTool: ControllerTool?
    @State private var historyForTool: PracticeOutputSnapshot?
    @State private var showingSettings = false
    @State private var showingBridgeSettings = false
    @State private var connectAfterBridgeSettings = false
    @State private var showingBridgeStatus = false
    @State private var confirmingProfilesRestore = false
    @State private var showingProfiles = false
    @State private var showingStarterWelcome = false
    @State private var showingProfileOptions = false
    @State private var showingPages = false
    @State private var showingFloating = false
    @State private var showingDisplay = false
    @State private var outputSnapshot: PracticeOutputSnapshot?
    @State private var configuringControl: ControlSelection?

    private struct ControlSelection: Identifiable {
        let control: UUID
        var orientation: ControllerOrientation = .portrait
        var id: UUID { control }
    }

    private let background = Color(uiColor: ControllerAppearancePalette.background)
    private let accent = Color(uiColor: ControllerAppearancePalette.accent)
    private var preferredScheme: ColorScheme? {
        switch model.presentation.theme { case .dark: .dark; case .light: .light; case .system: nil }
    }

    var body: some View {
        GeometryReader { geometry in
            let wide = geometry.size.width > geometry.size.height
            Group {
                if wide {
                    HStack(spacing: 12) {
                        controllerToolbar(compact: true)
                            .frame(width: min(dynamicTypeSize.isAccessibilitySize ? 240 : 180,
                                              geometry.size.width * (dynamicTypeSize.isAccessibilitySize ? 0.32 : 0.23)))
                        VStack(spacing: 10) {
                            canvas(orientation: .landscape).frame(minHeight: 260)
                            layoutActions(orientation: .landscape).dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                        }
                    }
                } else {
                    VStack(spacing: 10) {
                        controllerToolbar(compact: false)
                            .frame(maxHeight: max(154, geometry.size.height - 580))
                        canvas(orientation: .portrait).frame(minHeight: min(480, max(200, geometry.size.height - 270)))
                        layoutActions(orientation: .portrait).dynamicTypeSize(...DynamicTypeSize.xxxLarge)
                    }
                }
            }
            .padding(wide ? 12 : 18)
        }
        .background(background.ignoresSafeArea())
        .preferredColorScheme(preferredScheme)
        .background(ControllerOrientationAdapter(preference: model.requestedOrientation, onError: model.reportBackupMessage).frame(width: 0, height: 0))
        .tint(accent)
        .onChange(of: model.buttonFeedbackGeneration) { _, _ in
            guard !model.latestButtonFeedback.isEmpty else { return }
            UISelectionFeedbackGenerator().selectionChanged()
        }
        .sheet(isPresented: $showingControls, onDismiss: openSelectedTool) {
            ControllerToolsPanel(model: model, choose: chooseTool)
                .presentationDetents([.large])
        }
        .sheet(isPresented: $showingSettings, onDismiss: { model.finishSettings() }) { connectionSettings }
        .sheet(isPresented: $showingBridgeSettings, onDismiss: bridgeSettingsDismissed) { bridgeSettings }
        .alert("Bridge status", isPresented: $showingBridgeStatus) {
            Button("OK", role: .cancel) { }
        } message: { Text(model.statusDetail) }
        .sheet(item: $outputSnapshot, onDismiss: { model.finishSettings() }) { snapshot in
            PracticeOutputHistoryView(snapshot: snapshot, clearHistory: model.clearPracticeHistory)
        }
        .onAppear {
            model.setForeground(scenePhase == .active)
            if model.takeStarterWelcome() {
                model.beginProfileManagement()
                showingStarterWelcome = true
            }
        }
        .sheet(isPresented: $showingStarterWelcome, onDismiss: { model.finishProfileManagement() }) {
            NavigationStack {
                GameStarterPicker(model: model, welcome: true, onFinish: { showingStarterWelcome = false })
            }
        }
        .sheet(isPresented: $showingProfiles, onDismiss: { model.finishProfileManagement() }) {
            ProfileManagerView(model: model)
        }
        .sheet(isPresented: $showingProfileOptions, onDismiss: { model.finishControlConfiguration() }) {
            ProfileOptionsView(profile: model.profile, onSave: model.saveProfileOptions)
        }
        .sheet(isPresented: $showingPages, onDismiss: { model.finishControlConfiguration() }) {
            ProfilePagesView(profile: model.profile, selectedPageID: model.currentPageID,
                             sourceProfiles: model.library.profiles, onSave: model.savePages)
        }
        .sheet(isPresented: $showingFloating, onDismiss: { model.finishControlConfiguration() }) {
            FloatingControlsEditor(profile: model.profile, pageID: model.currentPageID,
                                   snapshots: model.floatingCanvasSnapshots, settingsPresets: model.library.settingsPresets,
                                   onSavePresets: model.saveSettingsPresets, onUnfloat: model.restoreFloatingButtons, onSave: model.saveFloatingDraft)
        }
        .sheet(isPresented: $showingDisplay, onDismiss: { model.finishControlConfiguration() }) {
            DisplaySettingsView(preferences: model.presentation, editorOrientation: model.editorOrientation,
                                isEditing: model.isEditingLayout, onSave: model.savePresentation)
        }
        .sheet(item: $configuringControl, onDismiss: { model.finishControlConfiguration() }) { selection in
            if let control = model.profile.control(for: selection.control) {
                ProfileControlEditor(control: control, pages: model.profile.pages, availableControls: model.profile.controls, orientation: selection.orientation, pageID: model.currentControlPage(control.id), canDuplicate: model.profile.controls.count < 64,
                                     settingsPresets: model.library.settingsPresets, onSavePresets: model.saveSettingsPresets,
                                     onSave: { model.saveControl($0, onPage: $1) },
                                     onDuplicate: { model.duplicateControl($0, toPage: $1) }, onDelete: { id in
                    // Close the owning sheet before removing its backing item.
                    configuringControl = nil
                    model.deleteControl(id)
                })
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { connectAfterBridgeSettings = false; nextTool = nil; historyForTool = nil }
            model.setForeground(phase == .active)
            UIApplication.shared.isIdleTimerDisabled = model.keepsScreenAwake
        }
        .onChange(of: model.keepsScreenAwake) { _, awake in
            UIApplication.shared.isIdleTimerDisabled = awake
        }
        .onDisappear {
            model.setForeground(false)
            UIApplication.shared.isIdleTimerDisabled = false
        }
    }

    // Only the full-height All controls sheet scrolls. Every tile on the
    // controller screen has a stable position and is visible without swiping.
    private func controllerToolbar(compact: Bool) -> some View {
        VStack(spacing: 6) {
            if compact || dynamicTypeSize.isAccessibilitySize {
                bridgeMenu
                cameraButton
                allControlsButton
                if !dynamicTypeSize.isAccessibilitySize {
                    profileButton
                    pageMenu
                }
            } else {
                HStack(spacing: 8) { bridgeMenu; profileButton }
                HStack(spacing: 8) { cameraButton; pageMenu }
                allControlsButton
            }
            Spacer(minLength: 0)
        }
        .dynamicTypeSize(...DynamicTypeSize.xxxLarge)
    }

    private var cameraButton: some View {
        let inPractice = model.mode == .practice && !model.isEditingLayout
        let badge = CameraFollowPresentation.badge(model.cameraFollowSnapshot)
        let detail = model.isEditingLayout ? "Editing layout" : inPractice ? badge.capitalized : "Practice only"
        return Button {
            guard let snapshot = model.cameraFollowSnapshot else { return }
            model.setCameraFollowEnabled(!snapshot.requestedEnabled)
        } label: {
            ControllerToolTile(title: "Camera Follow", detail: detail, symbol: "camera", emphasized: inPractice && badge != "OFF")
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Camera Follow").accessibilityValue(detail)
        .accessibilityHint("Turn Camera Follow on or off in Practice. Strength is in All controls.")
        .disabled(!inPractice || !model.controlsEnabled || model.cameraFollowSnapshot == nil)
    }

    private var allControlsButton: some View {
        let issueCount = controlNotices.count
        let detail = issueCount > 0 ? "\(issueCount) needing attention" :
            dynamicTypeSize.isAccessibilitySize ? "Profiles, pages, strength & settings" : "Settings, camera strength & status"
        return Button { showingControls = true } label: {
            ControllerToolTile(title: "All controls", detail: detail, symbol: "list.bullet", accessory: "chevron.right")
        }
        .buttonStyle(.plain)
        .accessibilityLabel("All controls").accessibilityValue(detail)
        .accessibilityHint("Opens a full-size list of controller tools and settings.")
    }

    private var profileButton: some View {
        Button { openProfilesOrOptions() } label: {
            ControllerToolTile(title: model.isEditingLayout ? "Profile options" : "Profiles",
                               detail: model.canEditLayout ? model.profile.name : "Recovery",
                               symbol: "rectangle.stack", accessory: "chevron.right")
        }
        .buttonStyle(.plain)
        .accessibilityLabel(model.isEditingLayout ? "Profile options" : model.canEditLayout ? "Profiles, \(model.profile.name)" : "Profiles and recovery")
    }

    private var pageMenu: some View {
        Menu {
            ForEach(model.profile.pages) { page in
                Button { model.selectPage(page.id) } label: {
                    if page.id == model.currentPageID { Label(page.name, systemImage: "checkmark") }
                    else { Text(page.name) }
                }
            }
            if model.isEditingLayout {
                Divider()
                Button("Manage pages") { model.beginControlConfiguration(); showingPages = true }
            }
        } label: {
            ControllerToolTile(title: "Page", detail: model.currentPage.name, symbol: "rectangle.on.rectangle", accessory: "chevron.down")
        }
        .menuStyle(.button).buttonStyle(.plain).menuIndicator(.hidden)
        .accessibilityLabel("Current page, \(model.currentPage.name)")
        .accessibilityHint("Choose another page. Changing pages releases all held controls.")
    }

    private func openProfilesOrOptions() {
        if model.isEditingLayout { model.beginControlConfiguration(); showingProfileOptions = true }
        else { model.beginProfileManagement(); showingProfiles = true }
    }

    private func chooseTool(_ tool: ControllerTool) {
        // Capture held Practice outputs before opening history releases them.
        if tool == .history {
            historyForTool = PracticeOutputSnapshot(state: model.practiceState, events: model.recentPracticeEvents,
                                                    omittedCount: model.practiceEventsOmittedCount)
        }
        nextTool = tool
        showingControls = false
    }

    private func openSelectedTool() {
        guard let tool = nextTool else { return }
        nextTool = nil
        guard scenePhase == .active else { historyForTool = nil; return }
        switch tool {
        case .settings: model.prepareSettings(); showingSettings = true
        case .history:
            if let history = historyForTool { model.prepareSettings(); outputSnapshot = history }
            historyForTool = nil
        case .profile: openProfilesOrOptions()
        case .pages: model.beginControlConfiguration(); showingPages = true
        case .display: model.beginControlConfiguration(); showingDisplay = true
        }
    }

    private var bridgeMenu: some View {
        BridgeActionMenu(isBridge: model.mode == .bridge, connectionRequested: model.connectionRequested,
                         editing: model.isEditingLayout, status: model.bridgeMenuStatus) { action in
            switch action {
            case .connect: connectFromMenu()
            case .disconnect: model.stop()
            case .settings: openBridgeSettings()
            case .details: showingBridgeStatus = true
            case .practice: model.setMode(.practice)
            }
        }.equatable()
    }

    private func connectFromMenu() {
        if model.host.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            openBridgeSettings()
        } else {
            model.setMode(.bridge)
            model.connect()
        }
    }

    private func openBridgeSettings() {
        connectAfterBridgeSettings = false
        model.prepareSettings()
        showingBridgeSettings = true
    }

    private func bridgeSettingsDismissed() {
        // Leaving settings releases inputs. Do that before opening a new session.
        let shouldConnect = connectAfterBridgeSettings
        connectAfterBridgeSettings = false
        model.finishSettings()
        if shouldConnect && scenePhase == .active {
            model.setMode(.bridge)
            model.connect()
        }
    }

    private var hasDesktopOutputs: Bool { model.hasDesktopOutputs }
    private var hasPointerOutputs: Bool { model.hasPointerOutputs }
    private var controlNotices: [UUID: String] {
        var notices = model.fixedStickIssues
        for (id, state) in model.floatingRingStates {
            if let issue = state.issue { notices[id] = issue }
        }
        return notices
    }
    private func canvas(orientation: ControllerOrientation) -> some View {
        ProfileCanvas(state: model.state, enabled: model.controlsEnabled,
                         profile: model.profile, pageID: model.currentPageID, orientation: orientation,
                         editing: model.isEditingLayout,
                         allowExtendedControls: model.mode == .practice,
                         allowTriggerControls: model.usesTriggerPressure,
                         activeControls: model.activeControls,
                         latchedControls: model.latchedControls,
                         retainedSticks: model.retainedSticks,
                         stickPositions: model.stickPositions,
                         buttonAimStates: model.buttonAimStates,
                         buttonDirectionalSelections: model.buttonDirectionalSelections,
                         touchAimStates: model.touchAimStates, touchAimScores: model.touchAimScores,
                         touchAimIssues: model.touchAimIssues,
                         floatingRingStates: model.floatingRingStates,
                         dismissedFloatingButtonSessions: model.dismissedFloatingButtonSessions,
                         activeTouchpads: model.activeTouchpads,
                         lockedTouchpads: model.lockedTouchpads,
                         pendingTouchpadLocks: model.pendingTouchpadLocks,
                         scrollModeEnabled: model.practiceState.scrollModeEnabled,
                         showCameraFollow: model.hasCameraFollowOutputs,
                         cameraFollowSnapshot: model.cameraFollowSnapshot,
                         onProfileChange: { [epoch = model.inputEpoch] layout in
                             model.updateProfile(layout, epoch: epoch)
                         }, onInput: { [epoch = model.inputEpoch] event in
                             model.handleInput(event, epoch: epoch)
                         }, onConfigure: { control in
                             guard model.canEditBehaviors else { return }
                             model.beginControlConfiguration()
                             configuringControl = ControlSelection(control: control, orientation: orientation)
                         }, onMeasure: { snapshot, profile, page, measuredOrientation in
                             model.recordCanvasSnapshot(snapshot, profile: profile, pageID: page, orientation: measuredOrientation)
                         }, onIssue: model.reportBackupMessage)
        .id(model.inputEpoch)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(alignment: .top) {
            if model.mode == .practice && !model.isEditingLayout {
                PracticeOutputHeader(state: model.practiceState,
                                     showDesktop: hasDesktopOutputs,
                                     showPointer: hasPointerOutputs,
                                     lastEvent: model.recentPracticeEvents.last,
                                     showCameraFollow: model.hasCameraFollowOutputs,
                                     cameraFollowSnapshot: model.cameraFollowSnapshot)
                    .foregroundStyle(accent)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 2)
                    .background(background)
                    .padding(.horizontal, 8)
                    .padding(.top, 3)

            }
        }
        .overlay {
            if model.mode == .bridge && !model.isReady && scenePhase == .active &&
                !model.isEditingLayout && !model.isShowingSettings && !model.isManagingProfiles && !model.isConfiguringControl {
                Text(model.connectionRequested ? "Connecting automatically…\nControls are paused." : "Open Bridge menu → Connect bridge to play")
                    .font(.callout.weight(.medium))
                    .multilineTextAlignment(.center)
                    .padding(20)
                    .background(background.opacity(0.93), in: RoundedRectangle(cornerRadius: 16))
                    .padding(18)
                    .allowsHitTesting(false)
            }
        }
    }

    @ViewBuilder
    private func layoutActions(orientation: ControllerOrientation) -> some View {
        if model.isEditingLayout {
            HStack(spacing: 12) {
                Button("Cancel") { model.cancelLayoutEditing() }
                    .buttonStyle(.bordered)
                Menu {
                    Group {
                    Button("Button") { addControl(.button, orientation: orientation) }
                    Button("Left stick") { addControl(.leftStick, orientation: orientation) }
                    Button("Right stick") { addControl(.rightStick, orientation: orientation) }
                    Button("Re-center") { addControl(.recenter, orientation: orientation) }
                    Button("Touchpad") { addControl(.touchpad, orientation: orientation) }
                    Button("TouchAim") { addControl(.touchAim, orientation: orientation) }
                    Button("Page button") { addControl(.pageButton, orientation: orientation) }
                    }.disabled(model.profile.controls.count >= 64)
                    Divider()
                    Button("Floating controls") { model.beginControlConfiguration(); showingFloating = true }
                    Button("Display and orientation") { model.beginControlConfiguration(); showingDisplay = true }
                } label: { Text("Add").lineLimit(1) }
                .buttonStyle(.bordered)
                .accessibilityLabel("Add control")
                Button("Save layout") { model.saveLayoutEditing() }
                    .buttonStyle(.borderedProminent)
            }
            .controlSize(.large)
            .frame(maxWidth: .infinity, minHeight: 44)
        } else {
            HStack(spacing: 12) {
                Button("Edit") { model.beginLayoutEditing() }
                    .buttonStyle(.borderedProminent)
                    .disabled(!model.canEditLayout)
                    .accessibilityLabel("Edit layout")
                    .accessibilityHint("Pauses controls so you can drag each button and stick. Save keeps both orientations.")
                Button("Re-center") { model.recenterSticks() }
                    .buttonStyle(.bordered)
                    .tint(.orange)
                    .accessibilityLabel("Re-center sticks")
                    .accessibilityHint("Centers both sticks and releases their Stick Plus actions. Separately held buttons remain held.")
                releaseButton
            }
            .controlSize(.large)
        }
    }

    private var releaseButton: some View {
        Button(action: model.releaseAll) {
            Text("Release all")
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity, minHeight: 20)
        }
        .buttonStyle(.bordered)
        .tint(.orange)
        .controlSize(.large)
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityLabel("Release all controls")
        .accessibilityHint("Releases this phone's buttons, sticks and timed actions while keeping the bridge connection active.")
    }

    private var bridgeSettings: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Use the Pico’s Wi-Fi address. Your iPhone and Pico must be on the same network.")
                        .font(.subheadline)
                }
                bridgeAddress
                Section {
                    Button("Save and connect") {
                        model.saveSettings()
                        connectAfterBridgeSettings = true
                        showingBridgeSettings = false
                    }
                    .disabled(model.host.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                } footer: {
                    Text("Done saves your settings and updates an active connection. If disconnected, use Save and connect to start.")
                }
                bridgeOptions
            }
            .navigationTitle("Bridge settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { model.saveSettings(); showingBridgeSettings = false }
                }
            }
        }
    }

    private var bridgeAddress: some View {
        Section("Your Pico") {
            VStack(alignment: .leading, spacing: 4) {
                Text("Wi-Fi address").font(.caption).foregroundStyle(.secondary)
                TextField("Bridge IPv4 address", text: $model.host)
                    .keyboardType(.decimalPad)
                    .textContentType(.none)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .accessibilityLabel("Bridge IPv4 address")
                    .accessibilityHint("Enter the bridge address provided during setup, not the Xbox console address.")
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("Port").font(.caption).foregroundStyle(.secondary)
                TextField("Port", text: $model.portText).keyboardType(.numberPad).accessibilityLabel("Port")
            }
        }
    }

    private var bridgeOptions: some View {
        Section("Bridge options") {
            Picker("Bridge protocol", selection: Binding(get: { model.bridgeProtocol }, set: { model.setBridgeProtocol($0) })) {
                ForEach(BridgeProtocolVersion.allCases, id: \.self) { item in Text(item.displayName).tag(item) }
            }
            Text(model.bridgeProtocol == .scx2
                 ? "Pages, profiles and Release all clear held inputs while keeping the bridge active. Returning to the app within five minutes resumes automatically with all controls released. After five minutes away, tap Connect bridge to resume."
                 : "Legacy SCX1 is retained for earlier test receivers. Select the protocol matching your receiver; the app never falls back automatically.")
                .font(.footnote).foregroundStyle(.secondary)
            if model.bridgeProtocol == .scx2 {
                Toggle("Adjustable LT and RT", isOn: Binding(
                    get: { model.bridgeTriggerPressureEnabled }, set: { model.setBridgeTriggerPressureEnabled($0) }))
                Text("Requires the pressure-capable Pico firmware and the added analog circuit connected to the XAC's LT/RT jacks. Values such as RT:0.5 retain their requested pressure. An incompatible receiver cannot enable controls. Changing this option releases input; an active bridge connection checks the new setting automatically.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
    }

    private var connectionSettings: some View {
        NavigationStack {
            Form {
                Section("Display") {
                    NavigationLink("Theme and screen orientation") {
                        DisplaySettingsView(preferences: model.presentation, editorOrientation: model.editorOrientation,
                                            isEditing: false, wrapInNavigationStack: false, onSave: model.savePresentation)
                    }
                    if let issue = model.presentationIssue { Text(issue).foregroundStyle(.orange) }
                }
                bridgeAddress
                bridgeOptions
                Section {
                    Text("On the controller screen, tap Bridge menu, then Connect bridge. Practice works without a Pico.")
                    Text("Allow Local Network access when iOS asks. Use the same trusted home network as the bridge.")
                    Text("The Xbox stays connected to your TV. Your Adaptive Controller connects the bridge to the console.")
                } header: { Text("Before connecting") }
                Section("Current prototype") {
                    Label("Practice mode works without a bridge", systemImage: "hand.tap")
                    Label("No Xbox hardware test completed yet", systemImage: "wrench.and.screwdriver")
                }
                Section("Profiles and controls") {
                    Text("Use the profile button on the controller screen to create, copy, rename or switch profiles.")
                    Text("Tap Edit, then Add for a new control. Hold a control to change its name, size, actions or behavior, or to copy or delete it. Done updates the draft; Save layout keeps every change. Cancel on the controller restores the entire saved profile.")
                    Text("Portrait and landscape have separate positions. Each control can also use separate sizes; names and behaviors apply to both orientations.")
                    Text("Custom payloads set trigger pressure and timed pulses. For bridge output, enable Adjustable LT and RT after preparing the Pico's analog circuit. Practice needs no hardware. Xbox output still needs physical validation.")
                    Text("Profile options in Edit controls Turbo and sliding between controls. Each button can also use Auto-tap or Hold Toggle. Release all cancels every repeat and delayed action.")
                    if let message = model.message { Text(message).foregroundStyle(.secondary) }
                    Button("Restore profiles", role: .destructive) { confirmingProfilesRestore = true }
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { model.saveSettings(); showingSettings = false }
                }
            }
            .confirmationDialog("Start a fresh profile library?", isPresented: $confirmingProfilesRestore, titleVisibility: .visible) {
                Button("Restore profiles", role: .destructive) { model.restoreProfiles() }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("This returns to the standard controller. A recovery copy of your previous saved profiles is kept on this phone.")
            }
        }
    }

    private func addControl(_ kind: ProfileControlKind, orientation: ControllerOrientation) {
        guard let id = model.addControl(kind: kind) else { return }
        model.beginControlConfiguration()
        configuringControl = ControlSelection(control: id, orientation: orientation)
    }
}

/// Holds and repeating game inputs change much more often than the bridge menu.
/// Keep an open native menu stable until its actual label or actions change.
private struct BridgeActionMenu: View, Equatable {
    enum Action { case connect, disconnect, settings, details, practice }
    let isBridge: Bool
    let connectionRequested: Bool
    let editing: Bool
    let status: String
    let perform: (Action) -> Void
    private var accent: Color { Color(uiColor: ControllerAppearancePalette.accent) }

    nonisolated static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.isBridge == rhs.isBridge && lhs.connectionRequested == rhs.connectionRequested &&
            lhs.editing == rhs.editing && lhs.status == rhs.status
    }

    var body: some View {
        Menu {
            Section("Xbox bridge") {
                if connectionRequested {
                    Button { perform(.disconnect) } label: {
                        Label("Disconnect bridge", systemImage: "xmark.circle")
                    }
                } else {
                    Button { perform(.connect) } label: {
                        Label("Connect bridge", systemImage: "wifi")
                    }
                }
                Button { perform(.settings) } label: {
                    Label("Bridge settings", systemImage: "gearshape")
                }
                if isBridge {
                    Button { perform(.details) } label: {
                        Label("Connection details", systemImage: "info.circle")
                    }
                }
            }
            Section {
                Button { perform(.practice) } label: {
                    Label("Practice on this iPhone", systemImage: !isBridge ? "checkmark" : "hand.tap")
                }
            }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "wifi").foregroundStyle(accent)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 1) {
                    Text("Bridge menu").font(.headline).foregroundStyle(.primary)
                    Text(status).font(.caption.weight(.medium)).foregroundStyle(.secondary)
                }
                .multilineTextAlignment(.leading)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "chevron.down").font(.footnote.weight(.bold)).foregroundStyle(accent)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 3)
            .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
            .background(accent.opacity(0.11), in: RoundedRectangle(cornerRadius: 12))
            .overlay { RoundedRectangle(cornerRadius: 12).strokeBorder(accent.opacity(0.65)) }
            .contentShape(Rectangle())
        }
        .menuStyle(.button)
        .buttonStyle(.plain)
        .menuIndicator(.hidden)
        .menuOrder(.fixed)
        .accessibilityLabel("Bridge menu")
        .accessibilityValue(status)
        .accessibilityHint("Connect your Xbox bridge, change bridge settings, or use Practice.")
        .disabled(editing)
    }
}

private struct ControllerToolTile: View {
    let title: String
    let detail: String
    let symbol: String
    var accessory: String? = nil
    var emphasized = false
    private var accent: Color { Color(uiColor: ControllerAppearancePalette.accent) }

    var body: some View {
        HStack(spacing: 7) {
            Image(systemName: symbol).foregroundStyle(accent)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(detail).font(.caption.weight(.medium)).foregroundStyle(emphasized ? accent : .secondary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            if let accessory { Image(systemName: accessory).font(.caption.weight(.semibold)).foregroundStyle(accent) }
        }
        .multilineTextAlignment(.leading)
        .padding(.horizontal, 9).padding(.vertical, 3)
        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
        .background(accent.opacity(emphasized ? 0.17 : 0.065), in: RoundedRectangle(cornerRadius: 12))
        .overlay { RoundedRectangle(cornerRadius: 12).strokeBorder(accent.opacity(emphasized ? 0.9 : 0.34)) }
        .contentShape(Rectangle())
    }
}

private enum ControllerTool { case settings, history, profile, pages, display }

private struct ControllerToolsPanel: View {
    @ObservedObject var model: ProfileControllerViewModel
    let choose: (ControllerTool) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Camera Follow") {
                    if model.mode == .practice && !model.isEditingLayout, let snapshot = model.cameraFollowSnapshot {
                        CameraFollowPracticeView(snapshot: snapshot, enabled: model.controlsEnabled,
                                                 onEnable: model.setCameraFollowEnabled, onStrength: model.setCameraFollowStrength)
                    } else {
                        Text(model.isEditingLayout ? "Save or cancel your edits to use Camera Follow in Practice." :
                             "Camera Follow works in Practice. It does not send camera movement to the Xbox bridge.")
                            .foregroundStyle(.secondary)
                    }
                }
                Section("Controller tools") {
                    if !model.isEditingLayout {
                        Button { choose(.settings) } label: { Label("Settings", systemImage: "gearshape") }
                    }
                    Button { choose(.profile) } label: {
                        Label(model.isEditingLayout ? "Profile options" : "Profiles: \(model.profile.name)", systemImage: "rectangle.stack")
                    }
                    Picker("Page", selection: Binding(get: { model.currentPageID }, set: { model.selectPage($0) })) {
                        ForEach(model.profile.pages) { Text($0.name).tag($0.id) }
                    }
                    if model.isEditingLayout {
                        Button("Manage pages") { choose(.pages) }
                        Button("Display and orientation") { choose(.display) }
                    }
                    if model.mode == .practice && !model.isEditingLayout && model.hasDesktopOutputs {
                        Button { choose(.history) } label: { Label("Practice output history", systemImage: "list.bullet.rectangle") }
                    }
                    if !model.isEditingLayout { Button("Release all controls", action: model.releaseAll) }
                }
                Section("Status") {
                    Text(model.statusTitle).font(.headline)
                    Text(model.statusDetail)
                    if let message = model.layoutMessage { Text(message) }
                    if model.profile.turboEnabled { Text("Turbo · \(model.profile.turboIntervalMilliseconds) ms interval") }
                    if model.profile.globalHoldEnabled { Text("Tap to hold ordinary buttons. Tap again to release.") }
                    if !model.latchedControls.isEmpty || !model.retainedSticks.isEmpty || !model.lockedTouchpads.isEmpty || !model.pendingTouchpadLocks.isEmpty {
                        Text("Held input active. Re-center stops sticks; Release all stops everything.")
                    }
                    if model.mode == .bridge {
                        Text(model.usesTriggerPressure
                             ? "Adjustable LT/RT requires the Pico’s analog trigger circuit. Keyboard, mouse, Xbox and Share are Practice only."
                             : "Keyboard, mouse, LT, RT, Xbox and Share are Practice only with the current bridge settings.")
                        Text("Xbox hardware testing is still pending.")
                    }
                }
                if !notices.isEmpty {
                    Section("Controls needing attention") {
                        ForEach(notices.keys.sorted { $0.uuidString < $1.uuidString }, id: \.self) { id in
                            let name = model.profile.control(for: id)?.name ??
                                model.currentPage.floatingRingZones.first(where: { $0.id == id })?.name ?? "Floating control"
                            Text("\(name): \(notices[id] ?? "")")
                        }
                    }
                }
            }
            .navigationTitle("All controls")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
    private var notices: [UUID: String] {
        var notes = model.fixedStickIssues
        for (id, state) in model.floatingRingStates { if let issue = state.issue { notes[id] = issue } }
        return notes
    }
}
