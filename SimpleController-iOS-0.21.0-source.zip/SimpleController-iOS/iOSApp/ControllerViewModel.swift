import Combine
import Foundation
import Darwin
import Network
import ControllerCore

@MainActor
final class ControllerViewModel: ObservableObject {
    enum Mode: String, CaseIterable {
        case practice = "Practice", bridge = "Xbox bridge"
    }

    enum Phase: Equatable {
        case idle, connecting, ready, stopped(String)
    }

    @Published private(set) var connectionRequested = false
    @Published private(set) var mode: Mode = .practice
    @Published private(set) var phase: Phase = .idle
    @Published private(set) var state: GamepadState = .neutral
    @Published private(set) var inputEpoch = 0
    // Diagnostic counter only. Publishing every heartbeat makes an open native
    // menu rebuild while the user is trying to select Disconnect or Details.
    private(set) var acknowledgedPackets: UInt64 = 0
    @Published var host: String
    @Published var portText: String
    @Published private(set) var bridgeProtocol: BridgeProtocolVersion
    @Published private(set) var bridgeTriggerPressureEnabled: Bool
    private(set) var outputState: BridgeOutputState = .neutral
    @Published private(set) var layout = ControllerLayout.default
    @Published private(set) var isEditingLayout = false
    @Published private(set) var layoutMessage: String?
    @Published private(set) var behaviors = ControllerBehaviors.default
    @Published private(set) var behaviorMessage: String?
    @Published private(set) var isConfiguringControl = false
    @Published private(set) var latchedControls: Set<ControllerControlID> = []
    @Published private(set) var retainedSticks: Set<ControllerControlID> = []

    private var inputEngine = ControllerInputEngine()
    private var behaviorTimer: Timer?
    private var protectedBehaviorData: Data?
    private static let behaviorKey = "controller.behaviors.v1"

    private var layoutBeforeEditing: ControllerLayout?
    private var protectedLayoutData: Data?
    private static let layoutKey = "controller.layout.v1"

    private let defaults: UserDefaults
    private let transport: any BridgeTransporting
    private let clock: () -> TimeInterval
    private let wallClock: () -> TimeInterval
    private let resumeClock: () -> TimeInterval
    private let automaticTimer: Bool
    private let persistSettings: Bool
    private var timer: Timer?
    private var session: String?
    private var sequence: UInt64 = 0
    private var lastAcknowledged: UInt64 = 0
    private var lastResponse: TimeInterval = 0
    private var startedAt: TimeInterval = 0
    private var lastHello: TimeInterval = -.infinity
    private var socketReady = false
    private var foreground = true
    private var scx2: SCX2ClientMachine?
    static let connectionIntentKey = "bridge.connection-intent.v1"
    nonisolated static let backgroundResumeLimit: TimeInterval = 300
    private struct Endpoint: Codable, Equatable {
        var host: String
        var port: UInt16
        var protocolVersion: BridgeProtocolVersion
        var pressure: Bool
        var valid: Bool {
            guard let address = IPv4Address(host), let first = address.rawValue.first else { return false }
            return first > 0 && first < 224 && port > 0 && (protocolVersion == .scx2 || !pressure)
        }
    }
    private struct ResumeRecord: Codable {
        var endpoint: Endpoint
        var uptime: TimeInterval
        var wallTime: TimeInterval
        func isFresh(uptime now: TimeInterval, wallTime wall: TimeInterval) -> Bool {
            let elapsed = now - uptime, wallElapsed = wall - wallTime
            return endpoint.valid && now.isFinite && wall.isFinite && uptime.isFinite && wallTime.isFinite &&
                uptime >= 0 && elapsed >= 0 && wallElapsed >= 0 &&
                elapsed < ControllerViewModel.backgroundResumeLimit && wallElapsed < ControllerViewModel.backgroundResumeLimit &&
                abs(elapsed - wallElapsed) < 5
        }
    }
    private var endpoint: Endpoint?
    private var backgroundRecord: ResumeRecord?
    private var nextRetry: TimeInterval?
    private var failureCount = 0
    private var connectionGeneration = 0
    private var lastIntentWrite: TimeInterval = -.infinity
    /// Unlike gesture uptime, the persisted absence clock advances while the phone sleeps.
    nonisolated private static func continuousTime() -> TimeInterval {
        var timebase = mach_timebase_info_data_t()
        mach_timebase_info(&timebase)
        return Double(mach_continuous_time()) * Double(timebase.numer) / Double(timebase.denom) / 1_000_000_000
    }
    private var pendingRelaunch = false
    private var wireProtocol: BridgeProtocolVersion { endpoint?.protocolVersion ?? bridgeProtocol }


    init(defaults: UserDefaults = .standard,
         transport: (any BridgeTransporting)? = nil,
         clock: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime },
         wallClock: @escaping () -> TimeInterval = { Date().timeIntervalSince1970 },
         resumeClock: (() -> TimeInterval)? = nil,
         automaticTimer: Bool = true,
         persistSettings: Bool = true) {
        self.defaults = defaults
        self.transport = transport ?? UDPBridgeTransport()
        self.clock = clock
        self.wallClock = wallClock
        self.resumeClock = resumeClock ?? { ControllerViewModel.continuousTime() }
        self.automaticTimer = automaticTimer
        self.persistSettings = persistSettings
        host = defaults.string(forKey: "bridge.host") ?? ""
        let selectedProtocol: BridgeProtocolVersion
        if let saved = defaults.string(forKey: "bridge.protocol"), let version = BridgeProtocolVersion(rawValue: saved) {
            selectedProtocol = version
        } else if defaults.object(forKey: "bridge.protocol") == nil &&
                    (defaults.object(forKey: "bridge.host") != nil || defaults.object(forKey: "bridge.port") != nil) {
            selectedProtocol = .scx1 // Preserve explicit earlier connection settings, without silently upgrading the peer.
        } else {
            selectedProtocol = .scx2
        }
        bridgeProtocol = selectedProtocol
        bridgeTriggerPressureEnabled = defaults.bool(forKey: "bridge.triggerPressure")
        portText = defaults.string(forKey: "bridge.port") ?? String(selectedProtocol.defaultPort)
        if let saved = defaults.data(forKey: Self.layoutKey) {
            do { layout = try ControllerLayoutCodec.decode(saved) }
            catch {
                protectedLayoutData = saved
                layoutMessage = "Your saved layout could not be opened. It has been kept unchanged. Reset the layout in settings to start over."
            }
        }
        if let saved = defaults.data(forKey: Self.behaviorKey) {
            do { behaviors = try ControllerBehaviorsCodec.decode(saved) }
            catch {
                protectedBehaviorData = saved
                behaviorMessage = "Your saved control settings could not be opened. They have been kept unchanged. Reset control behaviors in Settings to start over."
            }
        }
        inputEngine.apply(configuration: behaviors)
        restoreConnectionIntent()

    }

    var controlsEnabled: Bool { foreground && !isEditingLayout && !isConfiguringControl && (mode == .practice || phase == .ready) }
    var canEditLayout: Bool { protectedLayoutData == nil }
    var canEditBehaviors: Bool { protectedBehaviorData == nil }
    var keepsScreenAwake: Bool { foreground && ((mode == .bridge && phase == .ready) || !state.isNeutral) }
    var isConnecting: Bool { phase == .connecting || (connectionRequested && foreground && nextRetry != nil) }
    var isReady: Bool { phase == .ready }
    var usesTriggerPressure: Bool { wireProtocol == .scx2 && (endpoint?.pressure ?? bridgeTriggerPressureEnabled) }

    var statusTitle: String {
        if isEditingLayout { return "Editing layout • controls paused" }
        if mode == .practice { return "Practice • nothing is sent" }
        switch phase {
        case .idle: return "Bridge not connected"
        case .connecting: return "Waiting for the bridge"
        case .ready: return "Bridge is responding"
        case .stopped: return connectionRequested ? "Controls paused" : "Controls stopped"
        }
    }

    var statusDetail: String {
        if isEditingLayout { return "Drag to move. Hold a control to change its behavior. Rotate to arrange the other orientation, then tap Save." }
        if mode == .practice { return "Try the touch controls here. This mode does not control your Xbox." }
        switch phase {
        case .idle:
            return "A compatible bridge must connect to your Adaptive Controller. The bridge hardware is still being validated."
        case .connecting:
            if usesTriggerPressure { return "Waiting for a pressure-capable Pico and neutral stick and trigger outputs. Controls stay paused." }
            return bridgeProtocol == .scx2
                ? "Waiting for the candidate bridge and a completed neutral USB report. Controls stay paused."
                : "Waiting for the legacy SCX1 prototype. Its readiness reply is not physical Xbox verification."
        case .ready:
            if usesTriggerPressure { return "The Pico accepted controller and adjustable trigger output. Actual Xbox response still needs hardware verification." }
            return bridgeProtocol == .scx2
                ? "The candidate bridge acknowledged USB transfers. Xbox input and hardware compatibility still need physical verification."
                : "The legacy bridge reports USB readiness. This does not verify Xbox input."
        case .stopped(let reason):
            return reason
        }
    }

    func setMode(_ newMode: Mode) {
        guard !isEditingLayout, !isConfiguringControl else { return }
        guard newMode != mode else { return }
        stop()
        mode = newMode
        phase = .idle
    }

    func setBridgeProtocol(_ version: BridgeProtocolVersion) {
        guard version != bridgeProtocol else { return }
        let previousDefault = String(bridgeProtocol.defaultPort)
        cancelQueuedInput(reason: "Bridge settings changed. Controls released.")
        bridgeProtocol = version
        if portText.trimmingCharacters(in: .whitespacesAndNewlines) == previousDefault || portText.isEmpty {
            portText = String(version.defaultPort)
        }
    }

    func updateInput(_ newState: GamepadState, epoch: Int) {
        updateOutput(.init(gamepad: newState,
                           leftTrigger: newState.buttons.contains(.leftTrigger) ? 1 : 0,
                           rightTrigger: newState.buttons.contains(.rightTrigger) ? 1 : 0), epoch: epoch)
    }

    func setBridgeTriggerPressureEnabled(_ enabled: Bool) {
        guard enabled != bridgeTriggerPressureEnabled else { return }
        cancelQueuedInput(reason: "Trigger settings changed. Controls released.")
        bridgeTriggerPressureEnabled = enabled
    }

    func updateOutput(_ output: BridgeOutputState, epoch: Int) {
        guard epoch == inputEpoch, controlsEnabled else { return }
        guard output.isValid else { pauseAfterFailure(reason: "Invalid trigger or controller input. All controls were released."); return }
        if mode == .bridge && !liveSessionIsFresh() { return }
        var accepted = output.gamepad
        if mode == .bridge {
            accepted.buttons.subtract([.guide, .share])
            if !usesTriggerPressure { accepted.buttons.subtract([.leftTrigger, .rightTrigger]) }
        }
        state = accepted
        var wireGamepad = accepted
        wireGamepad.buttons.subtract([.leftTrigger, .rightTrigger])
        outputState = .init(gamepad: wireGamepad,
                            leftTrigger: mode == .practice || usesTriggerPressure ? output.leftTrigger : 0,
                            rightTrigger: mode == .practice || usesTriggerPressure ? output.rightTrigger : 0)
        if isReady { sendState() }
    }

    func releaseAll() {
        cancelQueuedInput(reason: "All controls released. Preparing fresh controls…")
    }

    /// Retire queued old presses before a page, profile, editor or Release all.
    /// The user's connection intent survives; only a new neutral ACK permits input.
    func cancelQueuedInput(reason: String) {
        if mode == .bridge, wireProtocol == .scx2, connectionRequested {
            if phase == .connecting || nextRetry != nil {
                clearLocalInput() // The existing attempt contains neutral only; don't extend it.
            } else if foreground, endpoint != nil {
                startAttempt(automatic: true)
            } else { clearLocalInput() }
            return
        }
        clearLocalInput()
        if isReady { sendState() }
    }

    func handleInput(_ event: ControllerInputEvent, epoch: Int) {
        guard epoch == inputEpoch, controlsEnabled else { return }
        if mode == .bridge && !liveSessionIsFresh() { return }
        do { try inputEngine.handle(event, at: now) }
        catch { releaseAll(); return }
        publishEngineState()
        refreshBehaviorTimer()
    }

    func tickInput(epoch: Int? = nil) {
        guard epoch == nil || epoch == inputEpoch, controlsEnabled else { return }
        if mode == .bridge && !liveSessionIsFresh() { return }
        do { try inputEngine.tick(at: now) }
        catch { releaseAll(); return }
        publishEngineState()
        refreshBehaviorTimer()
    }

    private func publishEngineState() {
        latchedControls = inputEngine.latchedControls
        retainedSticks = Set(inputEngine.retainedSticks.keys)
        updateInput(inputEngine.state, epoch: inputEpoch)
    }

    private func refreshBehaviorTimer() {
        guard automaticTimer, controlsEnabled, inputEngine.nextDeadline != nil else {
            behaviorTimer?.invalidate()
            behaviorTimer = nil
            return
        }
        guard behaviorTimer == nil else { return }
        let epoch = inputEpoch
        let timer = Timer(timeInterval: 0.02, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tickInput(epoch: epoch) }
        }
        behaviorTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func recenterSticks() {
        guard controlsEnabled else { return }
        inputEngine.recenterSticks()
        publishEngineState()
        refreshBehaviorTimer()
    }

    func beginControlConfiguration() {
        guard canEditBehaviors else { return }
        cancelQueuedInput(reason: "Controls released for editing.")
        isConfiguringControl = true
    }

    func finishControlConfiguration() {
        isConfiguringControl = false
        clearLocalInput()
    }

    func saveBehaviors(_ updated: ControllerBehaviors) {
        guard canEditBehaviors else { return }
        do {
            let data = try ControllerBehaviorsCodec.encode(updated)
            cancelQueuedInput(reason: "Controls released for editing.")
            behaviors = updated
            inputEngine.apply(configuration: updated)
            if persistSettings { defaults.set(data, forKey: Self.behaviorKey) }
            behaviorMessage = "Control behavior saved. All held input was released."
        } catch {
            behaviorMessage = "Control settings could not be saved. Your previous settings are unchanged."
        }
    }

    func resetBehaviors() {
        cancelQueuedInput(reason: "Controls released for editing.")
        if persistSettings, let original = protectedBehaviorData {
            defaults.set(original, forKey: "controller.behaviors.recovery.\(UUID().uuidString)")
        }
        protectedBehaviorData = nil
        behaviors = .default
        inputEngine.apply(configuration: .default)
        if persistSettings, let data = try? ControllerBehaviorsCodec.encode(behaviors) {
            defaults.set(data, forKey: Self.behaviorKey)
        }
        behaviorMessage = "Default control behaviors restored. Button positions are unchanged."
    }

    func prepareSettings() {
        if isEditingLayout { cancelLayoutEditing() }
        cancelQueuedInput(reason: "Controls released for editing.")
    }

    func beginLayoutEditing() {
        guard canEditLayout, !isEditingLayout else { return }
        cancelQueuedInput(reason: "Controls released for editing.")
        layoutBeforeEditing = layout
        isEditingLayout = true
        layoutMessage = nil
    }

    func updateLayout(_ newLayout: ControllerLayout, epoch: Int) {
        guard foreground, isEditingLayout, epoch == inputEpoch else { return }
        // Encoding validates a layout before accepting callbacks from the UI.
        guard (try? ControllerLayoutCodec.encode(newLayout)) != nil else { return }
        layout = newLayout
    }

    func saveLayoutEditing() {
        guard isEditingLayout, canEditLayout else { return }
        do {
            let data = try ControllerLayoutCodec.encode(layout)
            if persistSettings { defaults.set(data, forKey: Self.layoutKey) }
            isEditingLayout = false
            layoutBeforeEditing = nil
            clearLocalInput()
            layoutMessage = "Layout saved for portrait and landscape."
        } catch {
            layoutMessage = "The layout could not be saved. Your previous saved layout is unchanged."
        }
    }

    func cancelLayoutEditing() {
        if let original = layoutBeforeEditing { layout = original }
        layoutBeforeEditing = nil
        isEditingLayout = false
        clearLocalInput()
    }

    func resetLayout() {
        cancelQueuedInput(reason: "Controls released for editing.")
        // Retain unreadable source bytes separately when the user explicitly
        // resets, so recovery never silently destroys a newer layout format.
        if persistSettings, let original = protectedLayoutData {
            defaults.set(original, forKey: "controller.layout.recovery")
        }
        layout = .default
        protectedLayoutData = nil
        layoutBeforeEditing = nil
        isEditingLayout = false
        if persistSettings, let data = try? ControllerLayoutCodec.encode(layout) {
            defaults.set(data, forKey: Self.layoutKey)
        }
        layoutMessage = "Default layout restored."
    }

    private func settingsEndpoint() -> Endpoint? {
        guard let port = UInt16(portText.trimmingCharacters(in: .whitespacesAndNewlines)) else { return nil }
        let value = Endpoint(host: host.trimmingCharacters(in: .whitespacesAndNewlines), port: port,
                             protocolVersion: bridgeProtocol, pressure: bridgeProtocol == .scx2 && bridgeTriggerPressureEnabled)
        return value.valid ? value : nil
    }
    private func persistConnectionSettings() {
        guard persistSettings else { return }
        defaults.set(host, forKey: "bridge.host")
        defaults.set(portText, forKey: "bridge.port")
        defaults.set(bridgeProtocol.rawValue, forKey: "bridge.protocol")
        defaults.set(bridgeTriggerPressureEnabled, forKey: "bridge.triggerPressure")
    }
    func saveSettings() {
        host = host.trimmingCharacters(in: .whitespacesAndNewlines)
        portText = portText.trimmingCharacters(in: .whitespacesAndNewlines)
        persistConnectionSettings()
        guard connectionRequested else { return }
        guard let target = settingsEndpoint() else {
            endpoint = nil; nextRetry = nil
            if persistSettings { defaults.removeObject(forKey: Self.connectionIntentKey) }
            closeSession(reason: "The saved bridge address or port is invalid. Correct it in Bridge settings to resume.")
            ensureHeartbeat()
            return
        }
        guard target != endpoint else { return }
        endpoint = target; writeConnectionIntent(force: true)
        if foreground { startAttempt(automatic: true) }
    }

    func setForeground(_ active: Bool) {
        guard active != foreground else { return }
        foreground = active
        if !active {
            if connectionRequested, let endpoint {
                backgroundRecord = ResumeRecord(endpoint: endpoint, uptime: resumeClock(), wallTime: wallClock())
                writeConnectionIntent(force: true)
            }
            nextRetry = nil
            closeSession(reason: connectionRequested
                ? "Controls paused while the app is away. Return within five minutes to resume automatically." : nil)
        } else if connectionRequested {
            let record = backgroundRecord
            backgroundRecord = nil
            if let record, record.isFresh(uptime: resumeClock(), wallTime: wallClock()) {
                startAttempt(automatic: true)
            } else {
                stop(reason: "The app was away for five minutes or longer. Tap Connect bridge when you are ready.")
            }
        }
    }

    func connect() {
        guard mode == .bridge, foreground, !isEditingLayout, !isConfiguringControl else { return }
        guard let target = settingsEndpoint() else {
            stop(reason: "Open Bridge menu → Bridge settings. Enter the Pico’s IPv4 address and a port from 1 to 65535, then tap Save and connect.")
            return
        }
        host = target.host; portText = String(target.port)
        persistConnectionSettings()
        let automatic = connectionRequested
        endpoint = target; connectionRequested = true; failureCount = 0
        writeConnectionIntent(force: true)
        startAttempt(automatic: automatic)
    }

    private func startAttempt(automatic: Bool) {
        guard connectionRequested, foreground, let endpoint, endpoint.valid else { return }
        nextRetry = nil; pendingRelaunch = false
        closeSession()
        if endpoint.protocolVersion == .scx2 {
            scx2 = SCX2ClientMachine(revision: endpoint.pressure ? .pressure : .legacy, at: now,
                                     waitForAvailability: automatic)
        } else { session = UUID().uuidString }
        sequence = 0; lastAcknowledged = 0; acknowledgedPackets = 0
        startedAt = now; lastHello = -.infinity
        phase = .connecting
        installTransportCallbacks()
        ensureHeartbeat()
        writeConnectionIntent(force: false)
        transport.open(host: endpoint.host, port: endpoint.port)
    }
    private func installTransportCallbacks() {
        let generation = connectionGeneration
        transport.onReady = { [weak self] in
            guard let self, self.connectionGeneration == generation, self.phase == .connecting else { return }
            self.socketReady = true; self.tick()
        }
        transport.onMessage = { [weak self] data in
            guard let self, self.connectionGeneration == generation else { return }
            self.receive(data)
        }
        transport.onFailure = { [weak self] message in
            guard let self, self.connectionGeneration == generation else { return }
            self.pauseAfterFailure(reason: "Check Wi-Fi and Local Network access. \(message)")
        }
    }
    private func ensureHeartbeat() {
        guard automaticTimer, foreground, connectionRequested, timer == nil else { return }
        let heartbeat = Timer(timeInterval: 0.05, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
        timer = heartbeat; RunLoop.main.add(heartbeat, forMode: .common)
    }
    /// Only explicit Disconnect/Practice, or expiry of the five-minute absence, clears intent.
    func stop(reason: String? = nil) {
        connectionRequested = false; nextRetry = nil; endpoint = nil
        backgroundRecord = nil; pendingRelaunch = false
        if persistSettings { defaults.removeObject(forKey: Self.connectionIntentKey) }
        closeSession(reason: reason)
    }
    private func closeSession(reason: String? = nil, finalPacket override: Data? = nil) {
        timer?.invalidate(); timer = nil
        var finalPacket = override
        if finalPacket == nil {
            if var machine = scx2, let stop = machine.stop() { finalPacket = try? SCX2Codec.encode(stop) }
            else if let session, sequence < UInt64.max {
                finalPacket = try? BridgeCodec.encode(BridgePacket(kind: .stop, session: session, sequence: sequence + 1))
            }
        }
        connectionGeneration += 1
        session = nil; scx2 = nil; socketReady = false
        clearLocalInput()
        transport.close(afterSending: finalPacket)
        phase = reason.map(Phase.stopped) ?? .idle
    }
    private func pauseAfterFailure(reason: String, finalPacket: Data? = nil) {
        closeSession(reason: connectionRequested ? reason + " Controls are paused; reconnecting automatically." : reason,
                     finalPacket: finalPacket)
        if connectionRequested, foreground, endpoint != nil, now.isFinite, now >= 0 {
            failureCount = min(failureCount + 1, 4)
            nextRetry = now + min(8, pow(2, Double(failureCount - 1)))
            ensureHeartbeat()
        }
    }
    private func writeConnectionIntent(force: Bool) {
        guard persistSettings, connectionRequested, let endpoint, endpoint.valid else { return }
        let time = resumeClock(), wall = wallClock()
        guard time.isFinite, time >= 0, wall.isFinite else { return }
        guard force || (foreground && time - lastIntentWrite >= 1) else { return }
        let record = backgroundRecord ?? ResumeRecord(endpoint: endpoint, uptime: time, wallTime: wall)
        if let data = try? JSONEncoder().encode(record) {
            defaults.set(data, forKey: Self.connectionIntentKey); lastIntentWrite = time
        }
    }
    private func restoreConnectionIntent() {
        guard persistSettings, let data = defaults.data(forKey: Self.connectionIntentKey) else { return }
        guard data.count <= 4096, let record = try? JSONDecoder().decode(ResumeRecord.self, from: data),
              record.isFresh(uptime: resumeClock(), wallTime: wallClock()) else {
            defaults.removeObject(forKey: Self.connectionIntentKey); return
        }
        endpoint = record.endpoint; connectionRequested = true; mode = .bridge
        // Restore the same validated endpoint, never uncommitted settings-form text.
        host = record.endpoint.host; portText = String(record.endpoint.port)
        bridgeProtocol = record.endpoint.protocolVersion; bridgeTriggerPressureEnabled = record.endpoint.pressure
        // App construction can happen before its scene is active. Preserve the
        // original absence timestamp until the scene explicitly enters foreground.
        pendingRelaunch = true; backgroundRecord = record; foreground = false
    }

    private var now: TimeInterval { clock() }

    private func clearLocalInput() {
        inputEpoch += 1
        behaviorTimer?.invalidate()
        behaviorTimer = nil
        inputEngine.releaseAll()
        latchedControls = []
        retainedSticks = []
        state = .neutral
        outputState = .neutral
    }

    func tick() {
        guard foreground else { return }
        writeConnectionIntent(force: false)
        if let retry = nextRetry {
            if now >= retry { startAttempt(automatic: true) }
            return
        }
        if var machine = scx2 {
            guard foreground else { return }
            let packets = socketReady ? machine.socketDidBecomeReady(at: now) : machine.tick(at: now)
            scx2 = machine
            applySCX2(packets)
            return
        }
        guard foreground, let session else { return }
        switch phase {
        case .connecting:
            guard now - startedAt < 3 else {
                pauseAfterFailure(reason: "No bridge replied. Check its address, power, Wi-Fi, and iPhone Local Network permission.")
                return
            }
            if socketReady && now - lastHello >= 0.25 {
                lastHello = now
                send(BridgePacket(kind: .hello, session: session, sequence: 0))
            }
        case .ready:
            guard now - lastResponse < 0.75 else {
                pauseAfterFailure(reason: "The bridge stopped replying. All local controls were released. Check the connection.")
                return
            }
            sendState()
        default:
            break
        }
    }

    private func sendState() {
        if var machine = scx2 {
            guard isReady, foreground else { return }
            let packets = machine.updateOutput(outputState, at: now)
            scx2 = machine
            applySCX2(packets)
            return
        }
        guard isReady, foreground, let session, sequence < UInt64.max else { return }
        guard liveSessionIsFresh() else { return }
        sequence += 1
        send(BridgePacket(kind: .state, session: session, sequence: sequence, state: state))
    }

    private func send(_ packet: BridgePacket) {
        do { transport.send(try BridgeCodec.encode(packet)) }
        catch { pauseAfterFailure(reason: "A controller message could not be sent.") }
    }

    private func receive(_ data: Data) {
        if var machine = scx2 {
            guard foreground else { return }
            // Malformed traffic also checks the deadline; a delayed timer cannot preserve a hold.
            var packets = machine.tick(at: now)
            if let packet = try? SCX2Codec.decode(data) { packets += machine.receive(packet, at: now) }
            scx2 = machine
            applySCX2(packets)
            return
        }
        guard foreground, let session,
              let packet = try? BridgeCodec.decode(data), packet.session == session else { return }
        // Timers can be delayed by main-thread work. A late response must not
        // revive a session merely because the next timer callback has not run.
        if phase == .connecting && now - startedAt >= 3 {
            pauseAfterFailure(reason: "The bridge replied too late. Check the connection.")
            return
        }
        if isReady && !liveSessionIsFresh() { return }
        if phase == .connecting && packet.kind == .ready && packet.sequence == 0 {
            guard packet.hidReady == true else {
                pauseAfterFailure(reason: "The bridge replied, but its USB output is not ready. Check its connection to the Adaptive Controller.")
                return
            }
            lastResponse = now
            phase = .ready; failureCount = 0
            clearLocalInput()
            sendState() // Start with a neutral report, never a held practice control.
        } else if isReady && packet.kind == .ack && packet.sequence > lastAcknowledged && packet.sequence <= sequence {
            guard packet.hidReady == true else {
                pauseAfterFailure(reason: "The bridge’s USB output stopped. Check the Adaptive Controller connection.")
                return
            }
            lastAcknowledged = packet.sequence
            acknowledgedPackets += 1
            lastResponse = now
        }
    }

    private func liveSessionIsFresh() -> Bool {
        if scx2 != nil {
            tick()
            return isReady
        }
        guard isReady else { return false }
        guard now - lastResponse < 0.75 else {
            pauseAfterFailure(reason: "The bridge stopped replying. All local controls were released. Check the connection.")
            return false
        }
        return true
    }

    private func applySCX2(_ packets: [SCX2Packet]) {
        guard let machine = scx2 else { return }
        if case .stopped(let failure) = machine.phase {
            let stop = packets.last(where: { $0.kind == .stop }).flatMap { try? SCX2Codec.encode($0) }
            pauseAfterFailure(reason: failure == .helloTimeout && usesTriggerPressure
                ? "No pressure-capable Pico replied. This option requires matching firmware and the analog trigger circuit."
                : Self.message(for: failure), finalPacket: stop)
            return
        }
        if machine.controlsEnabled && !isReady {
            clearLocalInput() // ACK1 is the only point that arms SCX2 controls.
            phase = .ready; failureCount = 0
        }
        acknowledgedPackets = machine.acknowledgedPackets
        for packet in packets {
            do { transport.send(try SCX2Codec.encode(packet)) }
            catch { pauseAfterFailure(reason: "A controller message could not be sent."); return }
        }
    }

    private static func message(for failure: SCX2ClientMachine.Failure) -> String {
        switch failure {
        case .helloTimeout:
            "No SCX2 bridge replied. Check its address, power, Wi-Fi, and iPhone Local Network access."
        case .neutralTimeout:
            "The bridge did not confirm a neutral USB report. Controls stayed paused. Check the candidate hardware."
        case .acknowledgmentTimeout:
            "USB acknowledgments stopped arriving. All controls were released locally. Check the bridge."
        case .usbUnavailable:
            "The candidate bridge reports USB output unavailable. Check its connection and power."
        case .pressureUnavailable:
            "The Pico's adjustable trigger output is unavailable. Check the analog trigger circuit and matching firmware. Controls stayed paused."
        case .bridgeChanged:
            "The bridge restarted or changed its connection token. All controls were released."
        case .queueOverflow:
            "The bridge could not keep up with control changes. Input stopped and its pending queue was cleared. Check the connection."
        case .sequenceExhausted:
            "This bridge session reached its message limit. All controls were released."
        case .invalidTime, .invalidSession, .invalidState:
            "The controller connection stopped because its state could not be validated. All controls were released."
        }
    }
}
