# Bridge protocol

The app and Pico W use SCX2. USB input starts after a neutral report is acknowledged. The [Pico bridge protocol specification](https://github.com/kortorder/simplecontroller-pico-wifi-bridge/blob/main/bridge/PROTOCOL.md) describes packets, timing, capability negotiation and stop behavior.

[Wire fixtures](fixtures) are included for ControllerCore tests.

Starting with iOS 0.21, connection intent remains enabled across pages, profiles, settings and Release all. Each automatic resynchronization discards old queued input and completes a fresh session and neutral acknowledgment; it never appends neutral behind old commands. An automatic handshake can wait for an unavailable receiver only within its existing three-second limit, then retries with bounded backoff. The packet formats and firmware are unchanged. Disconnect/Practice cancels recovery. A background absence of five minutes also cancels it.
