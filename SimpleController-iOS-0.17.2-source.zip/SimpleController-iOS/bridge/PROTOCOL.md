# Bridge protocol

The app and Pico W use SCX2. USB input starts after a neutral report is acknowledged. The [Pico bridge protocol specification](https://github.com/kortorder/simplecontroller-pico-wifi-bridge/blob/main/bridge/PROTOCOL.md) describes packets, timing, capability negotiation and stop behavior.

[Wire fixtures](fixtures) are included for ControllerCore tests.
