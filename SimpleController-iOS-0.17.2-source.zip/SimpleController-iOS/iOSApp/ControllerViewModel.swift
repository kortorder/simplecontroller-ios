import Combine
import Foundation
import Network
import ControllerCore

@MainActor
final class ControllerViewModel: ObservableObject {
    enum Mode: String, CaseIterable {
        case practice = "Practice", bridge = "Xbox bridge"
    }

    enum Phase: Equatable {
        case idle, connecting, ready, stopped(String)
    }

    @Published private(set) var mode: Mode = .practice
    @Published private(set) var phase: Phase = .idle
    @Published private(set) var state: GamepadState = .neutral
    @Published private(set) var inputEpoch = 0
    // Diagnostic counter only. Publishing every heartbeat makes an open native
    // menu rebuild while the user is trying to select Disconnect or Details.
    private(set) var acknowledgedPackets: UInt64 = 0
    @Published var host: String
    @Published var portText: String
    @Published private(set) var bridgeProtocol: BridgeProtocolVersion
    @Published private(set) var bridgeTriggerPressureEnabled: Bool
    private(set) var outputState: BridgeOutputState = .neutral
    @Published private(set) var layout = ControllerLayout.default
    @Published private(set) var isEditingLayout = false
    @Published private(set) var layoutMessage: String?
    @Published private(set) var behaviors = ControllerBehaviors.default
    @Published private(set) var behaviorMessage: String?
    @Published private(set) var isConfiguringControl = false
    @Published private(set) var latchedControls: Set<ControllerControlID> = []
    @Published private(set) var retainedSticks: Set<ControllerControlID> = []

    private var inputEngine = ControllerInputEngine()
    private var behaviorTimer: Timer?
    private var protectedBehaviorData: Data?
    private static let behaviorKey = "controller.behaviors.v1"

    private var layoutBeforeEditing: ControllerLayout?
    private var protectedLayoutData: Data?
    private static let layoutKey = "controller.layout.v1"

    private let defaults: UserDefaults
    private let transport: any BridgeTransporting
    private let clock: () -> TimeInterval
    private let automaticTimer: Bool
    private let persistSettings: Bool
    private var timer: Timer?
    private var session: String?
    private var sequence: UInt64 = 0
    private var lastAcknowledged: UInt64 = 0
    private var lastResponse: TimeInterval = 0
    private var startedAt: TimeInterval = 0
    private var lastHello: TimeInterval = -.infinity
    private var socketReady = false
    private var foreground = true
    private var scx2: SCX2ClientMachine?

    init(defaults: UserDefaults = .standard,
         transport: (any BridgeTransporting)? = nil,
         clock: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime },
         automaticTimer: Bool = true,
         persistSettings: Bool = true) {
        self.defaults = defaults
        self.transport = transport ?? UDPBridgeTransport()
        self.clock = clock
        self.automaticTimer = automaticTimer
        self.persistSettings = persistSettings
        host = defaults.string(forKey: "bridge.host") ?? ""
        let selectedProtocol: BridgeProtocolVersion
        if let saved = defaults.string(forKey: "bridge.protocol"), let version = BridgeProtocolVersion(rawValue: saved) {
            selectedProtocol = version
        } else if defaults.object(forKey: "bridge.protocol") == nil &&
                    (defaults.object(forKey: "bridge.host") != nil || defaults.object(forKey: "bridge.port") != nil) {
            selectedProtocol = .scx1 // Preserve explicit earlier connection settings, without silently upgrading the peer.
        } else {
            selectedProtocol = .scx2
        }
        bridgeProtocol = selectedProtocol
        bridgeTriggerPressureEnabled = defaults.bool(forKey: "bridge.triggerPressure")
        portText = defaults.string(forKey: "bridge.port") ?? String(selectedProtocol.defaultPort)
        if let saved = defaults.data(forKey: Self.layoutKey) {
            do { layout = try ControllerLayoutCodec.decode(saved) }
            catch {
                protectedLayoutData = saved
                layoutMessage = "Your saved layout could not be opened. It has been kept unchanged. Reset the layout in settings to start over."
            }
        }
        if let saved = defaults.data(forKey: Self.behaviorKey) {
            do { behaviors = try ControllerBehaviorsCodec.decode(saved) }
            catch {
                protectedBehaviorData = saved
                behaviorMessage = "Your saved control settings could not be opened. They have been kept unchanged. Reset control behaviors in Settings to start over."
            }
        }
        inputEngine.apply(configuration: behaviors)
        self.transport.onReady = { [weak self] in
            guard let self, self.phase == .connecting else { return }
            self.socketReady = true
            self.tick()
        }
        self.transport.onMessage = { [weak self] in self?.receive($0) }
        self.transport.onFailure = { [weak self] message in
            self?.stop(reason: "Connection stopped. Check Wi-Fi and Local Network access. \(message)")
        }
    }

    var controlsEnabled: Bool { foreground && !isEditingLayout && !isConfiguringControl && (mode == .practice || phase == .ready) }
    var canEditLayout: Bool { protectedLayoutData == nil }
    var canEditBehaviors: Bool { protectedBehaviorData == nil }
    var keepsScreenAwake: Bool { foreground && ((mode == .bridge && phase == .ready) || !state.isNeutral) }
    var isConnecting: Bool { phase == .connecting }
    var isReady: Bool { phase == .ready }
    var usesTriggerPressure: Bool { bridgeProtocol == .scx2 && bridgeTriggerPressureEnabled }

    var statusTitle: String {
        if isEditingLayout { return "Editing layout • controls paused" }
        if mode == .practice { return "Practice • nothing is sent" }
        switch phase {
        case .idle: return "Bridge not connected"
        case .connecting: return "Waiting for the bridge"
        case .ready: return "Bridge is responding"
        case .stopped: return "Controls stopped"
        }
    }

    var statusDetail: String {
        if isEditingLayout { return "Drag to move. Hold a control to change its behavior. Rotate to arrange the other orientation, then tap Save." }
        if mode == .practice { return "Try the touch controls here. This mode does not control your Xbox." }
        switch phase {
        case .idle:
            return "A compatible bridge must connect to your Adaptive Controller. The bridge hardware is still being validated."
        case .connecting:
            if usesTriggerPressure { return "Waiting for a pressure-capable Pico and neutral stick and trigger outputs. Controls stay paused." }
            return bridgeProtocol == .scx2
                ? "Waiting for the candidate bridge and a completed neutral USB report. Controls stay paused."
                : "Waiting for the legacy SCX1 prototype. Its readiness reply is not physical Xbox verification."
        case .ready:
            if usesTriggerPressure { return "The Pico accepted controller and adjustable trigger output. Actual Xbox response still needs hardware verification." }
            return bridgeProtocol == .scx2
                ? "The candidate bridge acknowledged USB transfers. Xbox input and hardware compatibility still need physical verification."
                : "The legacy bridge reports USB readiness. This does not verify Xbox input."
        case .stopped(let reason):
            return reason
        }
    }

    func setMode(_ newMode: Mode) {
        guard !isEditingLayout, !isConfiguringControl else { return }
        guard newMode != mode else { return }
        stop()
        mode = newMode
        phase = .idle
    }

    func setBridgeProtocol(_ version: BridgeProtocolVersion) {
        guard version != bridgeProtocol else { return }
        let previousDefault = String(bridgeProtocol.defaultPort)
        stop()
        bridgeProtocol = version
        if portText.trimmingCharacters(in: .whitespacesAndNewlines) == previousDefault || portText.isEmpty {
            portText = String(version.defaultPort)
        }
    }

    func updateInput(_ newState: GamepadState, epoch: Int) {
        updateOutput(.init(gamepad: newState,
                           leftTrigger: newState.buttons.contains(.leftTrigger) ? 1 : 0,
                           rightTrigger: newState.buttons.contains(.rightTrigger) ? 1 : 0), epoch: epoch)
    }

    func setBridgeTriggerPressureEnabled(_ enabled: Bool) {
        guard enabled != bridgeTriggerPressureEnabled else { return }
        stop()
        bridgeTriggerPressureEnabled = enabled
    }

    func updateOutput(_ output: BridgeOutputState, epoch: Int) {
        guard epoch == inputEpoch, controlsEnabled else { return }
        guard output.isValid else { stop(reason: "Invalid trigger or controller input. All controls were released."); return }
        if mode == .bridge && !liveSessionIsFresh() { return }
        var accepted = output.gamepad
        if mode == .bridge {
            accepted.buttons.subtract([.guide, .share])
            if !usesTriggerPressure { accepted.buttons.subtract([.leftTrigger, .rightTrigger]) }
        }
        state = accepted
        var wireGamepad = accepted
        wireGamepad.buttons.subtract([.leftTrigger, .rightTrigger])
        outputState = .init(gamepad: wireGamepad,
                            leftTrigger: mode == .practice || usesTriggerPressure ? output.leftTrigger : 0,
                            rightTrigger: mode == .practice || usesTriggerPressure ? output.rightTrigger : 0)
        if isReady { sendState() }
    }

    func releaseAll() {
        cancelQueuedInput(reason: "All controls released. Connect again to resume.")
    }

    /// Cancellation must not drain old SCX2 presses after an editor/page/lifecycle change.
    func cancelQueuedInput(reason: String) {
        if mode == .bridge, bridgeProtocol == .scx2, scx2 != nil {
            stop(reason: reason)
            return
        }
        clearLocalInput()
        if isReady { sendState() }
    }

    func handleInput(_ event: ControllerInputEvent, epoch: Int) {
        guard epoch == inputEpoch, controlsEnabled else { return }
        if mode == .bridge && !liveSessionIsFresh() { return }
        do { try inputEngine.handle(event, at: now) }
        catch { releaseAll(); return }
        publishEngineState()
        refreshBehaviorTimer()
    }

    func tickInput(epoch: Int? = nil) {
        guard epoch == nil || epoch == inputEpoch, controlsEnabled else { return }
        if mode == .bridge && !liveSessionIsFresh() { return }
        do { try inputEngine.tick(at: now) }
        catch { releaseAll(); return }
        publishEngineState()
        refreshBehaviorTimer()
    }

    private func publishEngineState() {
        latchedControls = inputEngine.latchedControls
        retainedSticks = Set(inputEngine.retainedSticks.keys)
        updateInput(inputEngine.state, epoch: inputEpoch)
    }

    private func refreshBehaviorTimer() {
        guard automaticTimer, controlsEnabled, inputEngine.nextDeadline != nil else {
            behaviorTimer?.invalidate()
            behaviorTimer = nil
            return
        }
        guard behaviorTimer == nil else { return }
        let epoch = inputEpoch
        let timer = Timer(timeInterval: 0.02, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tickInput(epoch: epoch) }
        }
        behaviorTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func recenterSticks() {
        guard controlsEnabled else { return }
        inputEngine.recenterSticks()
        publishEngineState()
        refreshBehaviorTimer()
    }

    func beginControlConfiguration() {
        guard canEditBehaviors else { return }
        stop()
        isConfiguringControl = true
    }

    func finishControlConfiguration() {
        isConfiguringControl = false
        clearLocalInput()
    }

    func saveBehaviors(_ updated: ControllerBehaviors) {
        guard canEditBehaviors else { return }
        do {
            let data = try ControllerBehaviorsCodec.encode(updated)
            stop()
            behaviors = updated
            inputEngine.apply(configuration: updated)
            if persistSettings { defaults.set(data, forKey: Self.behaviorKey) }
            behaviorMessage = "Control behavior saved. All held input was released."
        } catch {
            behaviorMessage = "Control settings could not be saved. Your previous settings are unchanged."
        }
    }

    func resetBehaviors() {
        stop()
        if persistSettings, let original = protectedBehaviorData {
            defaults.set(original, forKey: "controller.behaviors.recovery.\(UUID().uuidString)")
        }
        protectedBehaviorData = nil
        behaviors = .default
        inputEngine.apply(configuration: .default)
        if persistSettings, let data = try? ControllerBehaviorsCodec.encode(behaviors) {
            defaults.set(data, forKey: Self.behaviorKey)
        }
        behaviorMessage = "Default control behaviors restored. Button positions are unchanged."
    }

    func prepareSettings() {
        if isEditingLayout { cancelLayoutEditing() }
        stop()
    }

    func beginLayoutEditing() {
        guard canEditLayout, !isEditingLayout else { return }
        stop()
        layoutBeforeEditing = layout
        isEditingLayout = true
        layoutMessage = nil
    }

    func updateLayout(_ newLayout: ControllerLayout, epoch: Int) {
        guard foreground, isEditingLayout, epoch == inputEpoch else { return }
        // Encoding validates a layout before accepting callbacks from the UI.
        guard (try? ControllerLayoutCodec.encode(newLayout)) != nil else { return }
        layout = newLayout
    }

    func saveLayoutEditing() {
        guard isEditingLayout, canEditLayout else { return }
        do {
            let data = try ControllerLayoutCodec.encode(layout)
            if persistSettings { defaults.set(data, forKey: Self.layoutKey) }
            isEditingLayout = false
            layoutBeforeEditing = nil
            clearLocalInput()
            layoutMessage = "Layout saved for portrait and landscape."
        } catch {
            layoutMessage = "The layout could not be saved. Your previous saved layout is unchanged."
        }
    }

    func cancelLayoutEditing() {
        if let original = layoutBeforeEditing { layout = original }
        layoutBeforeEditing = nil
        isEditingLayout = false
        clearLocalInput()
    }

    func resetLayout() {
        stop()
        // Retain unreadable source bytes separately when the user explicitly
        // resets, so recovery never silently destroys a newer layout format.
        if persistSettings, let original = protectedLayoutData {
            defaults.set(original, forKey: "controller.layout.recovery")
        }
        layout = .default
        protectedLayoutData = nil
        layoutBeforeEditing = nil
        isEditingLayout = false
        if persistSettings, let data = try? ControllerLayoutCodec.encode(layout) {
            defaults.set(data, forKey: Self.layoutKey)
        }
        layoutMessage = "Default layout restored."
    }

    func saveSettings() {
        host = host.trimmingCharacters(in: .whitespacesAndNewlines)
        portText = portText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard persistSettings else { return }
        defaults.set(host, forKey: "bridge.host")
        defaults.set(portText, forKey: "bridge.port")
        defaults.set(bridgeProtocol.rawValue, forKey: "bridge.protocol")
        defaults.set(bridgeTriggerPressureEnabled, forKey: "bridge.triggerPressure")
    }

    func setForeground(_ active: Bool) {
        foreground = active
        if !active {
            stop(reason: "The app was interrupted. Connect again when you are ready.")
        }
    }

    func connect() {
        guard mode == .bridge, foreground, !isEditingLayout, !isConfiguringControl else { return }
        stop()
        saveSettings()
        guard let address = IPv4Address(host),
              address.rawValue.first.map({ $0 > 0 && $0 < 224 }) == true,
              let port = UInt16(portText), port > 0 else {
            phase = .stopped("Open Bridge menu → Bridge settings. Enter the Pico’s IPv4 address and a port from 1 to 65535, then tap Save and connect.")
            return
        }
        if bridgeProtocol == .scx2 {
            scx2 = SCX2ClientMachine(revision: usesTriggerPressure ? .pressure : .legacy, at: now)
            session = nil
        } else {
            session = UUID().uuidString
        }
        sequence = 0
        lastAcknowledged = 0
        acknowledgedPackets = 0
        startedAt = now
        lastHello = -.infinity
        phase = .connecting
        if automaticTimer {
            let heartbeat = Timer(timeInterval: 0.05, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.tick() }
            }
            timer = heartbeat
            RunLoop.main.add(heartbeat, forMode: .common)
        }
        transport.open(host: host, port: port)
    }

    func stop(reason: String? = nil) {
        timer?.invalidate()
        timer = nil
        var finalPacket: Data?
        if var machine = scx2, let stop = machine.stop() {
            finalPacket = try? SCX2Codec.encode(stop)
        } else if let session, sequence < UInt64.max {
            finalPacket = try? BridgeCodec.encode(
                BridgePacket(kind: .stop, session: session, sequence: sequence + 1)
            )
        }
        // Invalidate state before old asynchronous replies can arrive.
        session = nil
        scx2 = nil
        socketReady = false
        clearLocalInput()
        transport.close(afterSending: finalPacket)
        phase = reason.map(Phase.stopped) ?? .idle
    }

    private var now: TimeInterval { clock() }

    private func clearLocalInput() {
        inputEpoch += 1
        behaviorTimer?.invalidate()
        behaviorTimer = nil
        inputEngine.releaseAll()
        latchedControls = []
        retainedSticks = []
        state = .neutral
        outputState = .neutral
    }

    func tick() {
        if var machine = scx2 {
            guard foreground else { return }
            let packets = socketReady ? machine.socketDidBecomeReady(at: now) : machine.tick(at: now)
            scx2 = machine
            applySCX2(packets)
            return
        }
        guard foreground, let session else { return }
        switch phase {
        case .connecting:
            guard now - startedAt < 3 else {
                stop(reason: "No bridge replied. Check its address, power, Wi-Fi, and iPhone Local Network permission.")
                return
            }
            if socketReady && now - lastHello >= 0.25 {
                lastHello = now
                send(BridgePacket(kind: .hello, session: session, sequence: 0))
            }
        case .ready:
            guard now - lastResponse < 0.75 else {
                stop(reason: "The bridge stopped replying. All local controls were released. Check the connection, then reconnect.")
                return
            }
            sendState()
        default:
            break
        }
    }

    private func sendState() {
        if var machine = scx2 {
            guard isReady, foreground else { return }
            let packets = machine.updateOutput(outputState, at: now)
            scx2 = machine
            applySCX2(packets)
            return
        }
        guard isReady, foreground, let session, sequence < UInt64.max else { return }
        guard liveSessionIsFresh() else { return }
        sequence += 1
        send(BridgePacket(kind: .state, session: session, sequence: sequence, state: state))
    }

    private func send(_ packet: BridgePacket) {
        do { transport.send(try BridgeCodec.encode(packet)) }
        catch { stop(reason: "A controller message could not be sent. Reconnect to try again.") }
    }

    private func receive(_ data: Data) {
        if var machine = scx2 {
            guard foreground else { return }
            // Malformed traffic also checks the deadline; a delayed timer cannot preserve a hold.
            var packets = machine.tick(at: now)
            if let packet = try? SCX2Codec.decode(data) { packets += machine.receive(packet, at: now) }
            scx2 = machine
            applySCX2(packets)
            return
        }
        guard foreground, let session,
              let packet = try? BridgeCodec.decode(data), packet.session == session else { return }
        // Timers can be delayed by main-thread work. A late response must not
        // revive a session merely because the next timer callback has not run.
        if phase == .connecting && now - startedAt >= 3 {
            stop(reason: "The bridge replied too late. Check the connection and reconnect.")
            return
        }
        if isReady && !liveSessionIsFresh() { return }
        if phase == .connecting && packet.kind == .ready && packet.sequence == 0 {
            guard packet.hidReady == true else {
                stop(reason: "The bridge replied, but its USB output is not ready. Check its connection to the Adaptive Controller.")
                return
            }
            lastResponse = now
            phase = .ready
            clearLocalInput()
            sendState() // Start with a neutral report, never a held practice control.
        } else if isReady && packet.kind == .ack && packet.sequence > lastAcknowledged && packet.sequence <= sequence {
            guard packet.hidReady == true else {
                stop(reason: "The bridge’s USB output stopped. Check the Adaptive Controller connection.")
                return
            }
            lastAcknowledged = packet.sequence
            acknowledgedPackets += 1
            lastResponse = now
        }
    }

    private func liveSessionIsFresh() -> Bool {
        if scx2 != nil {
            tick()
            return isReady
        }
        guard isReady else { return false }
        guard now - lastResponse < 0.75 else {
            stop(reason: "The bridge stopped replying. All local controls were released. Check the connection, then reconnect.")
            return false
        }
        return true
    }

    private func applySCX2(_ packets: [SCX2Packet]) {
        guard let machine = scx2 else { return }
        if case .stopped(let failure) = machine.phase {
            let stop = packets.last(where: { $0.kind == .stop }).flatMap { try? SCX2Codec.encode($0) }
            timer?.invalidate(); timer = nil; scx2 = nil; socketReady = false
            clearLocalInput()
            transport.close(afterSending: stop)
            phase = .stopped(failure == .helloTimeout && usesTriggerPressure
                ? "No pressure-capable Pico replied. This option requires the updated firmware and analog trigger circuit. Controls stayed paused."
                : Self.message(for: failure))
            return
        }
        if machine.controlsEnabled && !isReady {
            clearLocalInput() // ACK1 is the only point that arms SCX2 controls.
            phase = .ready
        }
        acknowledgedPackets = machine.acknowledgedPackets
        for packet in packets {
            do { transport.send(try SCX2Codec.encode(packet)) }
            catch { stop(reason: "A controller message could not be sent. Connect again to try again."); return }
        }
    }

    private static func message(for failure: SCX2ClientMachine.Failure) -> String {
        switch failure {
        case .helloTimeout:
            "No SCX2 bridge replied. Check its address, power, Wi-Fi, and iPhone Local Network access."
        case .neutralTimeout:
            "The bridge did not confirm a neutral USB report. Controls stayed paused. Check the candidate hardware, then connect again."
        case .acknowledgmentTimeout:
            "USB acknowledgments stopped arriving. All controls were released locally. Check the bridge, then connect again."
        case .usbUnavailable:
            "The candidate bridge reports USB output unavailable. Check its connection and power before reconnecting."
        case .pressureUnavailable:
            "The Pico's adjustable trigger output is unavailable. Check the analog trigger circuit and matching firmware. Controls stayed paused."
        case .bridgeChanged:
            "The bridge restarted or changed its connection token. All controls were released. Connect again to resume."
        case .queueOverflow:
            "The bridge could not keep up with control changes. Input stopped and its pending queue was cleared. Check the connection, then reconnect."
        case .sequenceExhausted:
            "This bridge session reached its message limit. All controls were released. Connect again to start a new session."
        case .invalidTime, .invalidSession, .invalidState:
            "The controller connection stopped because its state could not be validated. All controls were released. Connect again to retry."
        }
    }
}
