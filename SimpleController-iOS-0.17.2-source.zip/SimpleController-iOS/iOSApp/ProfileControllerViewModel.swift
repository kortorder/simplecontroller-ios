import Combine
import Foundation
import ControllerCore

struct AndroidImportPreview: Identifiable, Sendable {
    let id = UUID()
    let archiveID: UUID
    let data: Data
    let displayName: String
    let plan: AndroidProfileImportPlan

    static func prepare(_ data: Data, displayName: String) throws -> Self {
        let cleaned = displayName.unicodeScalars.filter { !CharacterSet.controlCharacters.contains($0) }.map(String.init).joined()
        let name = String(cleaned.trimmingCharacters(in: .whitespacesAndNewlines).prefix(128))
        let safeName = name.isEmpty ? "Android profile" : name
        let document = try AndroidProfileDocument.parse(data, fallbackName: String(safeName.prefix(64)))
        let archiveID = UUID()
        return .init(archiveID: archiveID, data: data, displayName: safeName,
                     plan: try .prepare(document, archiveID: archiveID))
    }
}

struct AndroidEditedExportReview: Identifiable, Sendable {
    let id = UUID()
    let profileName: String
    let preview: AndroidEditedExportPreview
}

/// Exact local recovery bytes. Only profile-related keys are exposed, never account/connection settings.
struct ProfileRecoveryDocument: Identifiable, Sendable {
    let id: String
    let title: String
    let data: Data
    let profileNames: [String]?
    let validationIssue: String?
}

/// Profile editing and input ownership sit above the existing tested bridge client.
/// The bridge still accepts only complete gamepad states, never editor operations.
@MainActor
final class ProfileControllerViewModel: ObservableObject {
    typealias Mode = ControllerViewModel.Mode
    @Published private(set) var library: ControllerProfileLibrary
    @Published private(set) var draft: ControllerProfile?
    @Published private(set) var currentPageID: UUID
    @Published private(set) var message: String?
    @Published private(set) var inputEpoch = 0
    @Published private(set) var isConfiguringControl = false
    @Published private(set) var isManagingProfiles = false
    @Published private(set) var isShowingSettings = false
    @Published private(set) var presentation = ControllerPresentationPreferences.default
    @Published private(set) var editorOrientation = ControllerDisplayOrientation.automatic
    @Published private(set) var presentationIssue: String?
    @Published private(set) var latchedControls: Set<UUID> = []
    @Published private(set) var retainedSticks: Set<UUID> = []
    @Published private(set) var activeControls: Set<UUID> = []
    @Published private(set) var stickPositions: [UUID: StickPosition] = [:]
    @Published private(set) var buttonAimStates: [UUID: ButtonAimVisualState] = [:]
    @Published private(set) var buttonDirectionalSelections: [UUID: ButtonDirectionalSelection] = [:]
    @Published private(set) var buttonFeedbackGeneration = 0
    private(set) var latestButtonFeedback: [ButtonFeedback] = []
    @Published private(set) var touchAimStates: [UUID: TouchAimState] = [:]
    @Published private(set) var touchAimScores: [UUID: Double] = [:]
    @Published private(set) var touchAimIssues: [UUID: String] = [:]
    @Published private(set) var activeTouchAims: Set<UUID> = []
    @Published private(set) var floatingRingStates: [UUID: FloatingRingState] = [:]
    @Published private(set) var dismissedFloatingButtonSessions: [UUID: UUID] = [:]
    @Published private(set) var fixedStickIssues: [UUID: String] = [:]
    @Published private(set) var cameraFollowSnapshot: CameraFollowPracticeSnapshot?
    @Published private(set) var activeTouchpads: Set<UUID> = []
    @Published private(set) var lockedTouchpads: Set<UUID> = []
    @Published private(set) var pendingTouchpadLocks: Set<UUID> = []
    @Published private(set) var practiceState = PracticeOutputState.neutral
    @Published private(set) var recentPracticeEvents: [PracticeOutputEvent] = []
    @Published private(set) var practiceEventsOmittedCount = 0

    private let connection: ControllerViewModel
    private let defaults: UserDefaults
    private let androidArchiveStore: AndroidProfileArchiveStore
    private let clock: () -> TimeInterval
    private let automaticTimer: Bool
    private let persistSettings: Bool
    private var engine: ProfileInputEngine
    private var behaviorTimer: Timer?
    private var behaviorTimerGeneration = 0
    private var observations: Set<AnyCancellable> = []
    private var protectedData: [String: Data] = [:]
    private var foreground = true
    private var capabilityProfile: ControllerProfile?
    private var capabilityPageID: UUID?
    private var pageBeforeEditing: UUID?
    private var cachedDesktopOutputs = false
    private var cachedPointerOutputs = false
    private var cachedCameraFollowOutputs = false
    private var measuredCanvasProfile: ControllerProfile?
    private var measuredCanvasPage: UUID?
    private var measuredCanvasSnapshots: [ControllerOrientation: FloatingCanvasSnapshot] = [:]
    static let libraryKey = "controller.profiles.v1"
    static let presentationKey = "controller.presentation.v1"
    private var protectedPresentation: Data?

    init(defaults: UserDefaults = .standard,
         transport: (any BridgeTransporting)? = nil,
         clock: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime },
         automaticTimer: Bool = true, persistSettings: Bool = true,
         androidArchiveDirectory: URL? = nil) {
        self.defaults = defaults
        let archiveDirectory = androidArchiveDirectory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("SimpleController", isDirectory: true).appendingPathComponent("AndroidOriginals", isDirectory: true)
        self.androidArchiveStore = AndroidProfileArchiveStore(directory: archiveDirectory)
        self.clock = clock
        self.automaticTimer = automaticTimer
        self.persistSettings = persistSettings
        connection = ControllerViewModel(defaults: defaults, transport: transport, clock: clock,
                                         automaticTimer: automaticTimer, persistSettings: persistSettings)
        var loaded = ControllerProfileLibrary.default
        var protected: [String: Data] = [:]
        var loadMessage: String?
        if let raw = defaults.data(forKey: Self.libraryKey) {
            do { loaded = try ControllerProfileLibraryCodec.decode(raw) }
            catch {
                protected[Self.libraryKey] = raw
                loadMessage = "Your saved profiles could not be opened. They are kept unchanged. Open Profiles and recovery → Recovery documents to export the saved data or restore a valid copy."
            }
        } else {
            let layoutRaw = defaults.data(forKey: "controller.layout.v1")
            let behaviorsRaw = defaults.data(forKey: "controller.behaviors.v1")
            do {
                let layout = try layoutRaw.map(ControllerLayoutCodec.decode) ?? .default
                let behaviors = try behaviorsRaw.map(ControllerBehaviorsCodec.decode) ?? .default
                var migrated = try ControllerProfile.migrating(layout: layout, behaviors: behaviors)
                // Legacy phone layouts retain their existing button-slide gesture. A first
                // launch without saved user data starts with deliberate direct touches.
                if layoutRaw == nil && behaviorsRaw == nil { migrated.swipeMode = .off }
                loaded = try ControllerProfileLibrary(activeProfileID: migrated.id, profiles: [migrated])
                if persistSettings {
                    defaults.set(try ControllerProfileLibraryCodec.encode(loaded), forKey: Self.libraryKey)
                }
                // Keep both old documents intact as a migration recovery source.
            } catch {
                if let layoutRaw { protected["controller.layout.v1"] = layoutRaw }
                if let behaviorsRaw { protected["controller.behaviors.v1"] = behaviorsRaw }
                loadMessage = "Your earlier layout or settings could not be opened. They are kept unchanged. Open Profiles and recovery → Recovery documents to export the saved data or restore a valid copy."
            }
        }
        library = loaded
        currentPageID = loaded.activeProfile.homePageID
        protectedData = protected
        message = loadMessage
        engine = try! ProfileInputEngine(profile: loaded.activeProfile, allowCameraFollowPractice: true)
        cameraFollowSnapshot = engine.cameraFollowSnapshot
        connection.objectWillChange.sink { [weak self] _ in self?.objectWillChange.send() }
            .store(in: &observations)
        connection.$inputEpoch.dropFirst().sink { [weak self] _ in self?.clearEngine() }
            .store(in: &observations)
        if let bytes = defaults.data(forKey: Self.presentationKey) {
            do { presentation = try ControllerPresentationCodec.decode(bytes) }
            catch {
                protectedPresentation = bytes
                presentationIssue = "Saved display settings could not be read. Defaults are shown. Saving new display settings keeps a recovery copy of the old data."
            }
        }
    }

    var profile: ControllerProfile { draft ?? library.activeProfile }
    var currentPage: ProfilePage { profile.page(for: currentPageID) ?? profile.page(for: profile.homePageID)! }
    var currentPageControls: [ProfileControl] { profile.controls(on: currentPage.id) }
    var currentControlPage: (UUID) -> UUID? { { id in self.profile.pages.first { $0.controlIDs.contains(id) }?.id } }
    var hasDesktopOutputs: Bool { refreshCapabilities(); return cachedDesktopOutputs }
    var hasPointerOutputs: Bool { refreshCapabilities(); return cachedPointerOutputs }
    var hasCameraFollowOutputs: Bool { refreshCapabilities(); return cachedCameraFollowOutputs }
    private func refreshCapabilities() {
        let current = profile
        guard capabilityProfile != current || capabilityPageID != currentPageID else { return }
        capabilityProfile = current; capabilityPageID = currentPageID
        let rings = currentPage.floatingRingZones.filter(\.enabled)
        // Capability, not the live toggle, reserves the output row. A camera
        // update must never resize the canvas or cancel the active finger.
        cachedCameraFollowOutputs = currentPageControls.contains { control in
            if control.isCameraFollowAction { return true }
            guard !control.excludeFromCameraFollow else { return false }
            if control.logicalStick == .leftStick && !control.isDirectional { return true }
            if control.isTouchAim && control.touchAim.aim.output == .leftStick { return true }
            if control.buttonAim.enabled && (control.buttonAim.tuning.output == .leftStick ||
                (control.buttonAim.alternate.enabled && control.buttonAim.alternate.tuning.output == .leftStick)) { return true }
            return control.outputTargets.contains(.leftStick)
        } || rings.contains { ring in
            let movement = ring.config.movement
            if movement.enabled && movement.output == .leftStick && !movement.excludeFromCameraFollow { return true }
            // Movement-layer exclusion must not hide independent ADS/fire/boost
            // fixed-left-stick commands on the same ring.
            var otherLayers = ring.config
            otherLayers.movement.enabled = false
            return otherLayers.outputTargets.contains(.leftStick)
        }
        cachedDesktopOutputs = currentPageControls.contains { $0.hasKeyboardOrMouseOutputs } || rings.contains { $0.config.hasDesktopOutputs }
        cachedPointerOutputs = currentPageControls.contains { control in
            control.kind == .touchpad || (control.isTouchAim && control.touchAim.aim.output.isMouse) || (control.buttonAim.enabled && (control.buttonAim.tuning.output.isMouse ||
                (control.buttonAim.alternate.enabled && control.buttonAim.alternate.tuning.output.isMouse))) || ((try? control.payloadProgram().steps.contains {
                if case .scrollModeToggle = $0 { true } else { false }
            }) ?? false)
        } || rings.contains { $0.config.aim.enabled && $0.config.aim.tuning.output.isMouse }
    }
    var isEditingLayout: Bool { draft != nil }
    var requestedOrientation: ControllerDisplayOrientation {
        ControllerPresentationPolicy.orientation(preferences: presentation, isEditing: isEditingLayout, editorOrientation: editorOrientation)
    }
    @discardableResult
    func savePresentation(_ value: ControllerPresentationPreferences, editorOrientation: ControllerDisplayOrientation) -> Bool {
        do {
            let bytes = try ControllerPresentationCodec.encode(value)
            releaseAll() // Neutralize before UIKit changes the screen geometry or the editor exits.
            if persistSettings {
                if let protectedPresentation {
                    defaults.set(protectedPresentation, forKey: "controller.presentation.recovery.\(UUID().uuidString)")
                }
                defaults.set(bytes, forKey: Self.presentationKey)
            }
            presentation = value
            self.editorOrientation = isEditingLayout ? editorOrientation : .automatic
            protectedPresentation = nil; presentationIssue = nil
            return true
        } catch { presentationIssue = error.localizedDescription; return false }
    }
    var canEditLayout: Bool { protectedData.isEmpty }
    var canEditBehaviors: Bool { canEditLayout }
    var layoutMessage: String? { message }
    var mode: Mode { connection.mode }
    var state: GamepadState { mode == .practice ? practiceState.gamepad : connection.state }
    var host: String { get { connection.host } set { connection.host = newValue } }
    var portText: String { get { connection.portText } set { connection.portText = newValue } }
    var bridgeProtocol: BridgeProtocolVersion { connection.bridgeProtocol }
    func setBridgeProtocol(_ value: BridgeProtocolVersion) { connection.setBridgeProtocol(value) }
    var bridgeTriggerPressureEnabled: Bool { connection.bridgeTriggerPressureEnabled }
    var usesTriggerPressure: Bool { connection.usesTriggerPressure }
    func setBridgeTriggerPressureEnabled(_ value: Bool) { connection.setBridgeTriggerPressureEnabled(value) }
    var isReady: Bool { connection.isReady }
    var isConnecting: Bool { connection.isConnecting }
    var bridgeMenuStatus: String {
        if isEditingLayout { return "Editing layout" }
        if mode == .practice { return "Practice" }
        switch connection.phase {
        case .idle: return "Disconnected"
        case .connecting: return "Connecting…"
        case .ready: return "Connected"
        case .stopped: return "Connection stopped"
        }
    }
    var controlsEnabled: Bool {
        connection.controlsEnabled && !isEditingLayout && !isConfiguringControl && !isManagingProfiles && !isShowingSettings
    }
    var keepsScreenAwake: Bool { connection.keepsScreenAwake }
    var statusTitle: String { isEditingLayout ? "Editing profile • controls paused" : connection.statusTitle }
    var statusDetail: String {
        isEditingLayout ? "Drag to move. Hold a control to change its size, actions or behavior. Save keeps every change in this profile." : connection.statusDetail
    }

    func setMode(_ mode: Mode) {
        guard !isEditingLayout, !isConfiguringControl, !isManagingProfiles, !isShowingSettings else { return }
        let changed = mode != self.mode
        connection.setMode(mode)
        if changed {
            do { try engine.setCameraFollowPracticeAllowed(mode == .practice, at: clock()) }
            catch { releaseAll() }
            publishEngine(); clearPracticeHistory()
        }
    }
    func connect() {
        guard !isEditingLayout, !isConfiguringControl, !isManagingProfiles, !isShowingSettings else { return }
        connection.connect()
    }
    func stop() { connection.stop() }
    func saveSettings() { connection.saveSettings() }
    func setForeground(_ active: Bool) { foreground = active; connection.setForeground(active) }
    func tick() { connection.tick() }
    func releaseAll() { connection.releaseAll() }

    @discardableResult
    func handleInput(_ event: ProfileInputEvent, epoch: Int) -> Bool {
        guard controlsEnabled, epoch == inputEpoch else { return false }
        // Local Release all must stop transport queues and invalidate UIKit callbacks as well as the engine.
        let directID: UUID?
        switch event {
        case .begin(_, let id, _), .beginButton(_, let id, _), .accessibilityActivate(let id): directID = id
        default: directID = nil
        }
        if let id = directID, currentPage.controlIDs.contains(id), profile.control(for: id)?.isReleaseAllAction == true {
            releaseAll(); return true
        }
        if let id = directID, mode != .practice, profile.control(for: id)?.isCameraFollowAction == true { return false }
        // Sensor surfaces require a real direct touch; reject a semantic tap without canceling other owners.
        if case .accessibilityActivate(let id) = event, profile.control(for: id)?.isTouchAim == true { return false }
        // Check the bridge lease before advancing any hold timers or owners.
        if mode == .bridge { connection.tick(); guard controlsEnabled, epoch == inputEpoch else { return false } }
        let previousPage = engine.currentPageID
        do {
            let now = clock()
            try engine.setCameraFollowPracticeAllowed(mode == .practice, at: now)
            try engine.handle(event, at: now)
        }
        catch { releaseAll(); return false }
        if engine.currentPageID != previousPage {
            currentPageID = engine.currentPageID
            inputEpoch += 1 // The old page's callbacks must never reach its replacement.
            connection.cancelQueuedInput(reason: "Page changed and all controls released. Connect again to resume.")
        }
        publishEngine()
        refreshTimer()
        switch event {
        case let .registerFloatingButtonSession(zoneID, sessionID):
            return engine.floatingButtonSessions[zoneID] == sessionID
        case let .beginButton(contact, _, _), let .beginStick(contact, _, _), let .beginTouchAim(contact, _, _), let .beginTouchpad(contact, _), let .beginFloatingRing(contact, _, _, _, _):
            return engine.isCapturedInputOwner(for: contact)
        case let .begin(contact, destination, _):
            return profile.control(for: destination)?.isLocalAction == true || engine.isCapturedInputOwner(for: contact)
        case let .handoff(contact, destination, _, _, _),
             let .handoffTravel(contact, destination, _, _, _),
             let .handoffFloatingButton(contact, _, destination):
            return engine.capturedControl(for: contact) == destination
        default: break
        }
        return true
    }
    func tickInput(epoch: Int? = nil) {
        guard controlsEnabled, epoch == nil || epoch == inputEpoch else { return }
        if mode == .bridge { connection.tick(); guard controlsEnabled else { return } }
        do {
            let now = clock()
            try engine.setCameraFollowPracticeAllowed(mode == .practice, at: now)
            try engine.tick(at: now)
        }
        catch { releaseAll(); return }
        publishEngine()
        refreshTimer()
    }
    func recenterSticks() {
        guard controlsEnabled else { return }
        engine.recenterSticks()
        publishEngine()
        refreshTimer()
    }
    func setCameraFollowEnabled(_ enabled: Bool) { updateCameraFollow(enabled: enabled, strength: nil) }
    func setCameraFollowStrength(_ strength: Double) { updateCameraFollow(enabled: cameraFollowSnapshot?.requestedEnabled ?? false, strength: strength) }
    private func updateCameraFollow(enabled: Bool, strength: Double?) {
        guard mode == .practice, controlsEnabled else { return }
        do {
            let now = clock()
            try engine.setCameraFollowPracticeAllowed(true, at: now)
            try engine.setCameraFollowEnabled(enabled, strengthPercent: strength, at: now)
            publishEngine(); refreshTimer()
        } catch { releaseAll(); message = error.localizedDescription }
    }
    private func publishEngine() {
        latchedControls = engine.latchedControls
        retainedSticks = Set(engine.retainedSticks.keys)
        activeControls = engine.outputControls
        stickPositions = engine.stickPositions
        buttonAimStates = engine.buttonAimStates
        buttonDirectionalSelections = engine.buttonDirectionalSelections
        let feedback = engine.drainButtonFeedback()
        if !feedback.isEmpty { latestButtonFeedback = feedback; buttonFeedbackGeneration += 1 }
        touchAimStates = engine.touchAimStates; touchAimScores = engine.touchAimScores
        touchAimIssues = engine.touchAimIssues; activeTouchAims = engine.activeTouchAims
        floatingRingStates = engine.floatingRingStates
        dismissedFloatingButtonSessions = engine.dismissedFloatingButtonSessions
        fixedStickIssues = engine.fixedStickIssues
        cameraFollowSnapshot = engine.cameraFollowSnapshot
        activeTouchpads = engine.activeTouchpads
        lockedTouchpads = engine.lockedTouchpads
        pendingTouchpadLocks = engine.pendingTouchpadLocks
        practiceState = engine.practiceState
        collectPracticeEvents()
        connection.updateOutput(.init(gamepad: engine.state,
                                      leftTrigger: practiceState.leftTrigger,
                                      rightTrigger: practiceState.rightTrigger), epoch: connection.inputEpoch)
    }
    private func clearEngine() {
        inputEpoch += 1
        behaviorTimerGeneration += 1
        behaviorTimer?.invalidate(); behaviorTimer = nil
        engine.releaseAll()
        _ = engine.drainButtonFeedback(); latestButtonFeedback = []
        buttonAimStates = [:]; buttonDirectionalSelections = [:]
        latchedControls = []; retainedSticks = []; activeControls = []; stickPositions = [:]
        touchAimStates = [:]; touchAimScores = [:]; touchAimIssues = [:]; activeTouchAims = []
        floatingRingStates = [:]
        dismissedFloatingButtonSessions = [:]
        fixedStickIssues = [:]; cameraFollowSnapshot = engine.cameraFollowSnapshot
        activeTouchpads = []; lockedTouchpads = []; pendingTouchpadLocks = []
        practiceState = .neutral
        collectPracticeEvents()
    }
    private func collectPracticeEvents() {
        let batch = engine.drainPracticeEvents()
        practiceEventsOmittedCount += batch.omittedCount
        recentPracticeEvents.append(contentsOf: batch.events)
        let excess = max(0, recentPracticeEvents.count - 32)
        if excess > 0 {
            recentPracticeEvents.removeFirst(excess)
            practiceEventsOmittedCount += excess
        }
    }
    func clearPracticeHistory() {
        _ = engine.drainPracticeEvents()
        recentPracticeEvents = []
        practiceEventsOmittedCount = 0
    }
    private func refreshTimer() {
        behaviorTimer?.invalidate(); behaviorTimer = nil
        behaviorTimerGeneration += 1
        guard automaticTimer, controlsEnabled, let deadline = engine.nextDeadline else { return }
        let epoch = inputEpoch
        let generation = behaviorTimerGeneration
        let timer = Timer(timeInterval: max(0.001, deadline - clock()), repeats: false) { [weak self] _ in
            Task { @MainActor in
                guard let self, self.inputEpoch == epoch, self.behaviorTimerGeneration == generation else { return }
                self.behaviorTimer = nil
                self.tickInput(epoch: epoch)
            }
        }
        behaviorTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func beginLayoutEditing() {
        guard canEditLayout, !isEditingLayout, !isShowingSettings, !isManagingProfiles else { return }
        pageBeforeEditing = currentPageID
        stop(); editorOrientation = .automatic; draft = library.activeProfile; message = nil
    }
    func updateProfile(_ value: ControllerProfile, epoch: Int) {
        guard foreground, isEditingLayout, !isConfiguringControl, epoch == inputEpoch,
              value.id == draft?.id, (try? value.validate()) != nil else { return }
        draft = value
    }
    func saveLayoutEditing() {
        guard let draft, canEditLayout else { return }
        var candidate = library
        guard let index = candidate.profiles.firstIndex(where: { $0.id == draft.id }) else { return }
        candidate.profiles[index] = draft
        if saveLibrary(candidate, selectedPageID: currentPageID) { self.draft = nil; pageBeforeEditing = nil; message = "Profile saved, including all pages and both orientations." }
    }
    func cancelLayoutEditing() {
        draft = nil; isConfiguringControl = false; stop()
        try? engine.apply(profile: library.activeProfile)
        if let page = pageBeforeEditing, library.activeProfile.page(for: page) != nil {
            _ = try? engine.selectPage(page, at: clock())
        }
        currentPageID = engine.currentPageID; pageBeforeEditing = nil
    }

    /// Page selection releases old input; SCX2 also retires its queued network session.
    func selectPage(_ id: UUID) {
        guard foreground, canEditLayout, !isConfiguringControl, !isShowingSettings, !isManagingProfiles,
              profile.page(for: id) != nil, id != currentPageID else { return }
        if isEditingLayout {
            clearEngine(); currentPageID = id
        } else {
            do {
                guard try engine.selectPage(id, at: clock()) else { return }
                currentPageID = engine.currentPageID; inputEpoch += 1
                connection.cancelQueuedInput(reason: "Page changed and all controls released. Connect again to resume.")
                publishEngine(); refreshTimer()
            } catch { releaseAll() }
        }
    }

    func savePages(_ updated: ControllerProfile, selectedPageID: UUID) {
        guard isEditingLayout, updated.id == draft?.id, (try? updated.validate()) != nil else { return }
        draft = updated
        currentPageID = updated.page(for: selectedPageID) == nil ? updated.homePageID : selectedPageID
        clearEngine()
    }

    func moveControl(_ id: UUID, toPage page: UUID) {
        guard var next = draft else { return }
        do { try next.moveControl(id, toPage: page); draft = next }
        catch { message = "This control could not be moved to that page." }
    }

    func beginControlConfiguration() {
        guard canEditLayout, isEditingLayout else { return }
        stop(); isConfiguringControl = true
    }
    func finishControlConfiguration() { isConfiguringControl = false; releaseAll() }

    @discardableResult
    func addControl(kind: ProfileControlKind) -> UUID? {
        guard var next = draft, next.controls.count < 64 else { return nil }
        let label: String
        switch kind {
        case .button: label = "A"
        case .leftStick: label = "Left stick"
        case .rightStick: label = "Right stick"
        case .recenter: label = "Re-center"
        case .touchpad: label = "Touchpad"
        case .touchAim: label = "Touch Aim"
        case .pageButton: label = "Home"
        }
        var control = ProfileControl(name: label, kind: kind,
                                     actions: kind == .button ? [.a] : [],
                                     diameter: kind.isStick ? 104 : 60)
        if kind == .touchAim { control.touchAim.requiresLocalSetup = true }
        do { try next.addControl(control, toPage: currentPage.id) }
        catch { message = "This control could not be added."; return nil }
        draft = next
        return control.id
    }
    func saveControl(_ control: ProfileControl, onPage page: UUID? = nil) {
        guard var next = draft, let index = next.controls.firstIndex(where: { $0.id == control.id }) else { return }
        next.controls[index] = control
        if let page {
            do { try next.moveControl(control.id, toPage: page) }
            catch { message = "These control settings could not be applied."; return }
        }
        guard (try? next.validate()) != nil else { message = "These control settings could not be applied."; return }
        draft = next
    }
    func saveProfileOptions(_ updated: ControllerProfile) {
        guard var next = draft, next.id == updated.id else { return }
        next.name = updated.name
        next.turboEnabled = updated.turboEnabled
        next.turboIntervalMilliseconds = updated.turboIntervalMilliseconds
        next.swipeMode = updated.swipeMode
        next.globalHoldEnabled = updated.globalHoldEnabled
        for index in next.controls.indices {
            guard let edited = updated.control(for: next.controls[index].id), edited.kind == next.controls[index].kind else { continue }
            if next.controls[index].kind.isStick { next.controls[index].stickBehavior.autoCenter = edited.stickBehavior.autoCenter }
            if next.controls[index].buttonAim.enabled {
                next.controls[index].buttonAim.tuning.autoCenter = edited.buttonAim.tuning.autoCenter
                next.controls[index].buttonAim.alternate.tuning.autoCenter = edited.buttonAim.alternate.tuning.autoCenter
            }
        }
        guard (try? next.validate()) != nil else { message = "These profile options could not be applied."; return }
        draft = next
    }

    var floatingCanvasSnapshots: [ControllerOrientation: FloatingCanvasSnapshot] {
        measuredCanvasProfile == profile && measuredCanvasPage == currentPageID ? measuredCanvasSnapshots : [:]
    }
    func recordCanvasSnapshot(_ snapshot: FloatingCanvasSnapshot, profile measuredProfile: ControllerProfile,
                              pageID: UUID, orientation: ControllerOrientation) {
        guard profile == measuredProfile, currentPageID == pageID, (try? snapshot.validate()) != nil else { return }
        if measuredCanvasProfile != measuredProfile || measuredCanvasPage != pageID { measuredCanvasSnapshots = [:] }
        measuredCanvasProfile = measuredProfile; measuredCanvasPage = pageID
        measuredCanvasSnapshots[orientation] = snapshot
    }
    func saveFloatingDraft(_ updated: ControllerProfile) {
        guard isEditingLayout, updated.id == profile.id, (try? updated.validate()) != nil else {
            message = "The floating layout could not be applied. Check its members, sizes and activation areas."; return
        }
        releaseAll(); draft = updated
        message = "Floating controls updated in the draft. Save layout to keep them."
    }
    /// Restores imported source geometry into a returned draft; archive reads never save a layout.
    func restoreFloatingButtons(_ value: ControllerProfile, zoneID: UUID, pageID: UUID) async throws -> ControllerProfile {
        guard isEditingLayout, value.id == profile.id, value.page(for: pageID) != nil else {
            throw FloatingControlError("The layout draft changed. Open the floating control again.")
        }
        try value.validate()
        let sources = value.androidSources.filter { $0.zones.contains { $0.nativeID == zoneID } }
        guard !sources.isEmpty else {
            var restored = value; try restored.unfloatButtons(zoneID, on: pageID); return restored
        }
        guard sources.count == 1, let source = sources.first,
              let reference = library.androidSources.first(where: { $0.id == source.archiveID }) else {
            throw FloatingControlError("The preserved Android original is needed to restore these buttons. Your draft has not changed.")
        }
        let directory = androidArchiveStore.directory, expectedEpoch = inputEpoch
        let restored = try await Task.detached(priority: .userInitiated) {
            let archived = try AndroidProfileArchiveStore(directory: directory).load(reference)
            let original = try AndroidProfileDocument.parse(archived.originalData)
            return try AndroidFloatingRestoration.restore(profile: value, zoneID: zoneID, pageID: pageID, original: original, source: source)
        }.value
        try Task.checkCancellation()
        guard isEditingLayout, value.id == profile.id, inputEpoch == expectedEpoch else {
            throw FloatingControlError("The layout changed while its original was being read. Open the floating control again.")
        }
        return restored
    }
    func duplicateControl(_ control: ProfileControl, toPage requestedPage: UUID? = nil) {
        guard var next = draft, next.controls.count < 64,
              next.control(for: control.id) != nil, (try? control.validate()) != nil else { return }
        var copy = control
        copy.id = UUID()
        copy.name = copiedName(control.name)
        func position(_ placements: [ProfilePlacement]) -> NormalizedControlPosition {
            let point = placements.first { $0.id == control.id }!.position
            return .init(x: min(0.95, point.x + 0.06), y: min(0.95, point.y + 0.06))
        }
        let page = requestedPage ?? next.pages.first { $0.controlIDs.contains(control.id) }!.id
        do {
            try next.addControl(copy, toPage: page, portrait: position(next.portrait), landscape: position(next.landscape))
            try next.duplicateSourceBinding(from: control.id, to: copy.id)
        }
        catch { message = "This control could not be copied."; return }
        draft = next
    }
    func deleteControl(_ id: UUID) {
        guard var next = draft else { return }
        do { try next.removeControl(id) }
        catch { message = "This control could not be removed."; return }
        draft = next
    }

    func prepareSettings() { guard !isEditingLayout else { return }; stop(); isShowingSettings = true }
    func finishSettings() { isShowingSettings = false; releaseAll() }
    func beginProfileManagement() {
        guard !isEditingLayout else { return }
        stop(); isManagingProfiles = true
    }
    func finishProfileManagement() { isManagingProfiles = false; releaseAll() }

    @discardableResult
    func selectProfile(_ id: UUID) -> Bool {
        guard !isEditingLayout, canEditLayout, library.profiles.contains(where: { $0.id == id }) else { return false }
        var candidate = library; candidate.activeProfileID = id
        return saveLibrary(candidate)
    }
    @discardableResult
    func createProfile(name: String, standardControls: Bool) -> Bool {
        guard !isEditingLayout, canEditLayout, library.profiles.count < 32 else { return false }
        do {
            var profile = standardControls
                ? try ControllerProfile.migrating(layout: .default, behaviors: .default, name: name)
                : try ControllerProfile(name: name, controls: [], portrait: [], landscape: [])
            profile.swipeMode = .off
            var candidate = library
            candidate.profiles.append(profile); candidate.activeProfileID = profile.id
            return saveLibrary(candidate)
        } catch { message = "Choose a profile name from 1 to 64 characters."; return false }
    }
    @discardableResult
    func renameProfile(_ id: UUID, name: String) -> Bool {
        guard !isEditingLayout, canEditLayout,
              let index = library.profiles.firstIndex(where: { $0.id == id }) else { return false }
        var candidate = library; candidate.profiles[index].name = name
        return saveLibrary(candidate)
    }
    @discardableResult
    func duplicateProfile(_ id: UUID) -> Bool {
        guard !isEditingLayout, canEditLayout, library.profiles.count < 32,
              let original = library.profiles.first(where: { $0.id == id }) else { return false }
        guard let copy = try? original.cloned(name: copiedName(original.name)) else { return false }
        var candidate = library; candidate.profiles.append(copy); candidate.activeProfileID = copy.id
        return saveLibrary(candidate)
    }
    @discardableResult
    func deleteProfile(_ id: UUID) -> Bool {
        guard !isEditingLayout, canEditLayout, library.profiles.count > 1,
              let removed = library.profiles.first(where: { $0.id == id }) else { return false }
        // Retain a recoverable copy before a confirmed profile deletion.
        if persistSettings, let raw = try? ControllerProfileLibraryCodec.encode(library) {
            defaults.set(raw, forKey: "controller.profiles.before-delete.\(removed.id.uuidString)")
        }
        var candidate = library; candidate.profiles.removeAll { $0.id == id }
        if candidate.activeProfileID == id { candidate.activeProfileID = candidate.profiles[0].id }
        return saveLibrary(candidate)
    }
    @discardableResult
    func deleteProfiles(_ ids: Set<UUID>) -> Bool {
        guard !isEditingLayout, canEditLayout else { return false }
        do {
            let plan = try ControllerProfileBulkDeletion.prepare(library: library, selectedIDs: ids)
            _ = try ControllerProfileLibraryCodec.encode(plan.candidate)
            if persistSettings {
                defaults.set(try ControllerProfileLibraryCodec.encode(library), forKey: "controller.profiles.before-batch-delete.\(UUID().uuidString)")
            }
            guard saveLibrary(plan.candidate) else { return false }
            message = "Deleted \(plan.deletedProfileIDs.count) profiles. Your selected profile is unchanged, and a recovery copy is kept on this phone."
            return true
        } catch { message = error.localizedDescription; return false }
    }
    func restoreProfiles() {
        guard !isEditingLayout else { return }
        if persistSettings {
            if let raw = defaults.data(forKey: Self.libraryKey) {
                defaults.set(raw, forKey: "controller.profiles.recovery.\(UUID().uuidString)")
            }
            for (_, raw) in protectedData {
                defaults.set(raw, forKey: "controller.profiles.recovery.\(UUID().uuidString)")
            }
        }
        if saveLibrary(.default) { protectedData = [:]; message = "A fresh profile is ready. Previous saved data has a recovery copy." }
    }

    var recoveryDocuments: [ProfileRecoveryDocument] {
        var copies = defaults.dictionaryRepresentation().compactMapValues { $0 as? Data }
            .filter { Self.isProfileRecoveryKey($0.key) }
        for (key, data) in protectedData { copies[key] = data }
        return copies.keys.sorted().enumerated().map { index, key in
            let data = copies[key]!
            let title: String
            if protectedData[key] != nil { title = "Unreadable saved profile data" }
            else if key.hasPrefix("controller.profiles.before-format-") {
                title = "Before profile format \(key.replacingOccurrences(of: "controller.profiles.before-format-", with: ""))"
            } else if key.hasPrefix("controller.profiles.before-batch-delete.") { title = "Before deleting several profiles" }
            else if key.hasPrefix("controller.profiles.before-delete.") { title = "Before deleting a profile" }
            else { title = "Saved recovery copy \(index + 1)" }
            do {
                let recovered = try ControllerProfileLibraryCodec.decode(data)
                return .init(id: key, title: title, data: data, profileNames: recovered.profiles.map(\.name), validationIssue: nil)
            } catch {
                return .init(id: key, title: title, data: data, profileNames: nil,
                    validationIssue: "This copy cannot be restored as a supported iPhone profile library. You can still export its exact contents for recovery.")
            }
        }
    }
    private static func isProfileRecoveryKey(_ key: String) -> Bool {
        key.hasPrefix("controller.profiles.before-format-") || key.hasPrefix("controller.profiles.before-delete.") ||
        key.hasPrefix("controller.profiles.before-batch-delete.") || key.hasPrefix("controller.profiles.recovery.")
    }
    @discardableResult
    func restoreRecoveryDocument(_ snapshot: ProfileRecoveryDocument) -> Bool {
        guard !isEditingLayout else { message = "Save or cancel the layout draft before recovering profiles."; return false }
        guard Self.isProfileRecoveryKey(snapshot.id) || protectedData[snapshot.id] != nil,
              (protectedData[snapshot.id] ?? defaults.data(forKey: snapshot.id)) == snapshot.data else {
            message = "This recovery copy changed or is no longer available. Open Recovery documents again."; return false
        }
        do {
            let recovered = try ControllerProfileLibraryCodec.decode(snapshot.data)
            _ = try ControllerProfileLibraryCodec.encode(recovered)
            if persistSettings {
                if let current = defaults.data(forKey: Self.libraryKey) {
                    defaults.set(current, forKey: "controller.profiles.recovery.\(UUID().uuidString)")
                }
                for (key, data) in protectedData where key != Self.libraryKey {
                    defaults.set(data, forKey: "controller.profiles.recovery.\(UUID().uuidString)")
                }
            }
            guard saveLibrary(recovered) else { return false }
            protectedData = [:]
            message = "Restored \(recovered.profiles.count) profiles. The previous saved library is kept in Recovery documents. All controls are released."
            return true
        } catch {
            message = "This recovery copy could not be restored. Your current profiles are unchanged. Export the copy to keep its exact contents."
            return false
        }
    }

    /// Export only the validated native profile document, never settings or runtime owners.
    func exportProfiles() -> Data? {
        guard canEditLayout else {
            message = "Your saved profiles could not be read. Export is unavailable until you recover them or explicitly restore profiles."
            return nil
        }
        guard !isEditingLayout else {
            message = "Save or cancel the layout draft before exporting profiles."
            return nil
        }
        do {
            var backupLibrary = library
            // Include recoverable originals from interrupted imports as well as referenced ones.
            for reference in try androidArchiveStore.list() where !backupLibrary.androidSources.contains(where: { $0.id == reference.id }) {
                backupLibrary.androidSources.append(reference)
            }
            let native = try ControllerProfileLibraryCodec.encode(backupLibrary)
            let data: Data
            if backupLibrary.androidSources.isEmpty { data = native }
            else {
                let archives = try backupLibrary.androidSources.map { try androidArchiveStore.load($0) }
                data = try AndroidPortableBackup(nativeLibraryData: native, archives: archives).encodedData()
            }
            message = nil
            return data
        } catch {
            message = "The profile backup could not be prepared. Your saved profiles are unchanged."
            return nil
        }
    }

    /// Merge validated native backups atomically; existing profiles and selection stay intact.
    @discardableResult
    func importProfiles(_ data: Data) -> Bool {
        guard canEditLayout else {
            message = "Your saved profiles need recovery before importing. They have not been changed."
            return false
        }
        guard !isEditingLayout else {
            message = "Save or cancel the layout draft before importing profiles."
            return false
        }
        do {
            guard data.count <= AndroidPortableBackup.maximumBytes else { throw AndroidArchiveError("This backup exceeds 40 MiB.") }
            let header = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            var imported: ControllerProfileLibrary
            var bundled: [AndroidArchivedSource] = []
            if header?["fileType"] as? String == "simplecontroller-ios-portable-backup" {
                let portable = try AndroidPortableBackup.decode(data)
                imported = try ControllerProfileLibraryCodec.decode(portable.nativeLibraryData)
                bundled = portable.archives
            } else {
                imported = try ControllerProfileLibraryCodec.decode(data)
                // A bare native document must not strand references to missing originals.
                bundled = try imported.androidSources.map { try androidArchiveStore.load($0) }
            }
            guard library.profiles.count + imported.profiles.count <= 32 else {
                message = "This backup would exceed the 32-profile limit. Nothing was imported; your current profiles are unchanged."
                return false
            }
            // Imported sensor fits need new local validation. Presets merge independently, never replacing local entries.
            imported = try imported.requiringLocalTouchCalibrationValidation()
            var candidate = library
            try candidate.settingsPresets.merge(imported.settingsPresets, at: Int64(Date().timeIntervalSince1970 * 1000))
            let storedSources = try androidArchiveStore.insertVerified(bundled)
            for index in imported.profiles.indices {
                imported.profiles[index].androidSources = imported.profiles[index].androidSources.map { source in
                    source.replacingArchiveID(storedSources[source.archiveID]!.id)
                }
            }
            imported.androidSources = Array(Set(imported.androidSources.compactMap { storedSources[$0.id]?.id })).compactMap { id in
                storedSources.values.first { $0.id == id }
            }
            for reference in imported.androidSources where !candidate.androidSources.contains(where: { $0.id == reference.id }) {
                candidate.androidSources.append(reference)
            }
            var occupiedNames = Set(library.profiles.map { $0.name.lowercased() })
            for original in imported.profiles {
                var copy = try original.cloned()
                let base = original.name.trimmingCharacters(in: .whitespacesAndNewlines)
                var counter = 1
                while true {
                    let suffix = counter == 1 ? " imported" : " imported \(counter)"
                    let name = String(base.prefix(64 - suffix.count)) + suffix
                    if occupiedNames.insert(name.lowercased()).inserted {
                        copy.name = name
                        break
                    }
                    counter += 1
                }
                candidate.profiles.append(copy)
            }
            // saveLibrary validates the whole merged document before stopping input or writing.
            guard saveLibrary(candidate) else { return false }
            let count = imported.profiles.count
            message = "Imported \(count) \(count == 1 ? "profile" : "profiles") as new copies. Your current profile stays selected."
            return true
        } catch let error as SettingsPresetError {
            message = "The reusable settings could not be imported. \(error.localizedDescription) Your profiles and presets are unchanged."
        } catch let error as AndroidArchiveError {
            message = "Import could not finish. \(error.localizedDescription) Your profiles are unchanged; any already-preserved original remains available under Android originals."
        } catch ControllerProfileError.oversizedData {
            message = "The native profiles exceed their 2 MiB limit. Nothing was imported."
        } catch ControllerProfileError.unsupportedVersion {
            message = "This backup uses a newer or unsupported iPhone format. Nothing was imported."
        } catch {
            message = "This is not a valid iPhone profile backup. Use Import Android profiles for Android files. Nothing was imported."
        }
        return false
    }

    /// The preview is prepared before confirmation. Store exact originals before native conversion is saved.
    @discardableResult
    func importAndroid(_ preview: AndroidImportPreview) -> Bool {
        guard canEditLayout, !isEditingLayout else {
            message = "Save or cancel editing and resolve profile recovery before importing."; return false
        }
        do {
            let provisional = try library.androidSources.first(where: {
                $0.sha256 == preview.plan.sourceSHA256 && $0.byteCount == preview.data.count
            }) ?? AndroidSourceArchiveReference(id: preview.archiveID, sha256: preview.plan.sourceSHA256,
                byteCount: preview.data.count, displayName: preview.displayName)
            // Validate capacity, native sizes and references before writing any source file.
            _ = try ControllerProfileLibraryCodec.encode(preview.plan.merged(into: library, source: provisional))
            let reference = try androidArchiveStore.insert(preview.data, displayName: preview.displayName)
            let candidate = try preview.plan.merged(into: library, source: reference)
            guard saveLibrary(candidate) else {
                message = "The original was preserved, but native profiles could not be saved. Your previous profiles remain available."; return false
            }
            message = "Imported \(preview.plan.profiles.count) profiles with \(preview.plan.convertedControlCount) controls and \(preview.plan.convertedPresetCount) reusable settings. \(preview.plan.archivedOnlyControlCount) controls remain in the original only. Your current profile stays selected."
            return true
        } catch {
            message = "Android import could not finish. \(error.localizedDescription) Your current profiles are unchanged."
            return false
        }
    }

    func androidOriginals() -> [AndroidSourceArchiveReference] {
        do { return try androidArchiveStore.list() }
        catch { message = "Android originals could not be listed. \(error.localizedDescription)"; return [] }
    }
    func exportAndroidOriginal(_ reference: AndroidSourceArchiveReference) -> Data? {
        do {
            let original = try androidArchiveStore.load(reference)
            message = "Exporting the unchanged Android original. iPhone edits are in the iPhone profile backup."
            return original.originalData
        } catch {
            message = "The original could not be exported. \(error.localizedDescription)"; return nil
        }
    }

    /// Computes a separate file; neither the native profile nor the immutable archive is changed.
    func prepareEditedAndroidExport(_ profileID: UUID) async -> AndroidEditedExportReview? {
        guard canEditLayout, !isEditingLayout,
              let profile = library.profiles.first(where: { $0.id == profileID }) else {
            message = "Save or cancel the layout draft before exporting Android edits."; return nil
        }
        guard profile.androidSources.count == 1, let source = profile.androidSources.first,
              let reference = library.androidSources.first(where: { $0.id == source.archiveID }) else {
            message = "An edited Android copy needs one original source. Profiles built on iPhone or assembled from multiple Android originals can be saved with Export all profiles."; return nil
        }
        let directory = androidArchiveStore.directory
        do {
            let preview = try await Task.detached(priority: .userInitiated) {
                let archived = try AndroidProfileArchiveStore(directory: directory).load(reference)
                let original = try AndroidProfileDocument.parse(archived.originalData)
                return AndroidEditedExportPreview.prepare(profile: profile, original: original, source: source)
            }.value
            guard !Task.isCancelled, library.profiles.first(where: { $0.id == profileID }) == profile else {
                message = "The profile changed while the export was being prepared. Open its export preview again."; return nil
            }
            return .init(profileName: profile.name, preview: preview)
        } catch {
            message = "The Android export could not be prepared. \(error.localizedDescription)"; return nil
        }
    }

    /// File picker completion and I/O errors share the profile screen's visible status.
    func reportBackupMessage(_ text: String) { message = text }

    /// Preset edits are an explicit library save and never replace the in-progress control/profile draft.
    @discardableResult
    func saveSettingsPresets(_ presets: SettingsPresetLibrary) -> Bool {
        guard canEditLayout else { message = "Recover the saved profiles before changing presets."; return false }
        do {
            var candidate = library; candidate.settingsPresets = presets
            let data = try ControllerProfileLibraryCodec.encode(candidate)
            persistLibraryData(data)
            library = candidate
            message = "Saved reusable settings. Your controller draft is unchanged."
            return true
        } catch {
            message = "The preset library could not be saved. \(error.localizedDescription)"
            return false
        }
    }

    private func persistLibraryData(_ data: Data) {
        guard persistSettings else { return }
        if let previous = defaults.data(forKey: Self.libraryKey),
           let fields = (try? JSONSerialization.jsonObject(with: previous)) as? [String: Any],
           let version = fields["version"] as? Int, version < ControllerProfileLibrary.currentVersion {
            let recoveryKey = "controller.profiles.before-format-\(version)"
            if defaults.data(forKey: recoveryKey) == nil { defaults.set(previous, forKey: recoveryKey) }
        }
        defaults.set(data, forKey: Self.libraryKey)
    }

    private func copiedName(_ name: String) -> String { String(name.prefix(59)) + " copy" }
    private func saveLibrary(_ candidate: ControllerProfileLibrary, selectedPageID: UUID? = nil) -> Bool {
        do {
            let data = try ControllerProfileLibraryCodec.encode(candidate)
            stop()
            try engine.apply(profile: candidate.activeProfile)
            if let page = selectedPageID, candidate.activeProfile.page(for: page) != nil {
                _ = try engine.selectPage(page, at: clock())
            }
            currentPageID = engine.currentPageID
            clearPracticeHistory()
            persistLibraryData(data)
            library = candidate
            message = nil
            return true
        } catch {
            message = "Changes could not be saved. Check names, control sizes and actions. Your saved profiles are unchanged."
            return false
        }
    }
}
