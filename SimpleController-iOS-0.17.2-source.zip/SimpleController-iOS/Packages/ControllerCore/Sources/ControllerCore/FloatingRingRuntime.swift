import Foundation

public struct FloatingRingSample: Equatable, Sendable {
    public var point: FloatingPoint
    /// Seconds since this contact began, from the same monotonic source as its other samples.
    public var elapsed: Double
    public init(point: FloatingPoint, elapsed: Double) { self.point = point; self.elapsed = elapsed }
    public var isValid: Bool { point.isValid && elapsed.isFinite && (0...3600).contains(elapsed) }
}
public enum FloatingRingSlot: String, CaseIterable, Sendable { case ads, fire, boostOne, boostTwo }
public struct FloatingRingState: Equatable, Sendable {
    public let sessionID: UUID
    public let geometry: FloatingRingGeometry
    public let placement: FloatingRingPlacement
    public let contact: Int?
    public let role: FloatingStartRole?
    public let visible: Bool
    public let retained: Bool
    public let finished: Bool
    public let movement: StickPosition
    public let aim: StickPosition?
    /// Live aim acquisition, including mouse outputs that have no analog position.
    public let aiming: Bool
    public let ads: Bool
    public let firing: Bool
    public let repeating: Bool
    public let armed: Bool
    public let pending: Bool
    public let busy: Bool
    public let suppressed: Bool
    public let fine: Bool
    public let boosts: Set<RingBoostStage>
    public let heldBoosts: Set<RingBoostStage>
    public let latchedBoosts: Set<RingBoostStage>
    public let overridden: Set<FloatingRingSlot>
    public let issue: String?
    /// Actual target frames in canvas points; circle hit testing remains in geometry.knob(at:).
    public var knobFrames: [String: FloatingRect] {
        Dictionary(uniqueKeysWithValues: geometry.config.knobs.filter(\.enabled).map { knob in
            let center = geometry.knobCenter(knob), size = knob.targetDiameter
            return (knob.id, .init(x: placement.origin.x + center.x - size/2,
                                  y: placement.origin.y + center.y - size/2, width: size, height: size))
        })
    }
}

struct FloatingRingEnvironment: Sendable {
    var occupiedChannels: Set<ControllerControlID> = []
    var blockedPayloadKeys: Set<RingOutputKey> = []
}
struct FloatingRingAnalog: Sendable {
    var channel: ControllerControlID
    var position: StickPosition
    var retained: Bool
}

/// A value-owned surfaced ring. There are no callbacks or detached timers; the enclosing
/// engine validates/cancels a complete input packet before advancing its one-shot deadline.
struct FloatingRingRuntime: Sendable {
    struct Boost: Sendable {
        var inside = false
        var latched = false
        var direction: StickDirection?
        var pendingPayload = ""
        var deadline: Double?
    }
    struct Aim: Sendable {
        var origin: ButtonPointerSample
        var last: ButtonPointerSample
        var smoothed: PointerDelta = .zero
        var centerOffset = FloatingPoint(x: 0, y: 0)
        var suspended = false
        var analog: FloatingRingAnalog?
    }
    let sessionID: UUID
    let geometry: FloatingRingGeometry
    let placement: FloatingRingPlacement
    private(set) var contact: Int?
    private(set) var finished = false
    private(set) var issue: String?
    private(set) var movementAnalog: FloatingRingAnalog?
    private var aimRuntime: Aim?
    private var aimActive = false
    private var macrosSuppressed = false
    var aimAnalog: FloatingRingAnalog? { aimRuntime?.analog }
    private var role: FloatingStartRole?
    private var knobID: String?
    private var outputs: [FloatingRingSlot: FloatingRingOutput] = Dictionary(uniqueKeysWithValues: FloatingRingSlot.allCases.map { ($0, .init()) })
    private var boosts: [RingBoostStage: Boost] = [.one: .init(), .two: .init()]
    private var overridden: Set<FloatingRingSlot> = []
    private var gesture: UInt64 = 0
    private var began: Double = 0
    private var elapsed: Double = 0
    private var lastPoint = FloatingPoint(x: 0, y: 0)
    private var applyGrabOffset = false
    private var finishGuard = FloatingFinishEntryGuard()
    private var previousOutputs: [FloatingRingSlot: (generation: UInt64, retained: Bool)] = [:]
    private var visited: Set<RingBoostStage> = []
    private var fineLatchStages: Set<RingBoostStage> = []
    private var fineGesture = false
    private var insideAim = false
    private var armed = false
    private var fireEligible = false
    private var fireStopped = false
    private var adsStopped = false
    private var firedThisGesture = false
    private var releaseCancelled = false
    private var suppressed = false
    private var returnDeadline: Double?
    private var directOneUnlocked = false
    private var movementOverridden = false
    private var aimOverridden = false
    private var config: FloatingRingConfig { geometry.config }
    private var knob: RingAimKnob? { knobID.flatMap(config.knob) }
    private func slot(_ stage: RingBoostStage) -> FloatingRingSlot { stage == .one ? .boostOne : .boostTwo }
    private var fine: Bool {
        config.aim.fine.enabled && (fineGesture || (config.aim.fine.persistWhileAdsLatched && fineLatchStages.contains {
            boosts[$0]?.latched == true && outputs[slot($0)]?.held == true
        }))
    }
    var state: FloatingRingState {
        .init(sessionID: sessionID, geometry: geometry, placement: placement, contact: contact, role: role,
              visible: !finished, retained: movementAnalog?.retained == true || aimAnalog?.retained == true || outputs.values.contains(where: \.retained),
              finished: finished, movement: movementAnalog?.position ?? .zero, aim: aimAnalog?.position, aiming: aimActive,
              ads: outputs[.ads]!.held || RingBoostStage.allCases.contains { boosts[$0]!.latched && outputs[slot($0)]!.held && isADS(outputs[slot($0)]!.payload) },
              firing: outputs[.fire]!.held, repeating: outputs[.fire]!.repeating, armed: armed,
              pending: returnDeadline != nil || boosts.values.contains { $0.deadline != nil }, busy: outputs.values.contains { $0.busy || $0.queued != nil },
              suppressed: suppressed, fine: fine,
              boosts: Set(RingBoostStage.allCases.filter { boosts[$0]!.inside || boosts[$0]!.latched || boosts[$0]!.deadline != nil || outputs[slot($0)]!.hasReservation }),
              heldBoosts: Set(RingBoostStage.allCases.filter { outputs[slot($0)]!.held }),
              latchedBoosts: Set(RingBoostStage.allCases.filter { boosts[$0]!.latched && outputs[slot($0)]!.held }),
              overridden: overridden, issue: issue)
    }
    var claims: GesturePayloadClaims {
        outputs.values.reduce(into: GesturePayloadClaims()) { $0.union($1.claims) }
    }
    func macroLeases(control: UUID) -> [SustainedMacroLease] {
        guard !macrosSuppressed else { return [] }
        return FloatingRingSlot.allCases.compactMap { slot in
            let priority: Int
            switch slot { case .ads: priority = 0; case .boostOne: priority = 1; case .boostTwo: priority = 2; case .fire: priority = 3 }
            return outputs[slot]?.macroLease(control: control, priority: priority)
        }
    }
    var reservedKeys: Set<RingOutputKey> { outputs.values.reduce(into: []) { $0.formUnion($1.exclusiveKeys) } }
    var heldKeys: Set<RingOutputKey> { outputs.values.filter(\.held).reduce(into: []) { $0.formUnion($1.keys) } }
    var occupiedChannels: Set<ControllerControlID> {
        Set([movementAnalog, aimAnalog].compactMap { $0?.retained == false ? $0?.channel : nil })
    }
    var retainedChannels: Set<ControllerControlID> {
        Set([movementAnalog, aimAnalog].compactMap { $0?.retained == true ? $0?.channel : nil })
    }
    var nextDeadline: Double? { (outputs.values.compactMap(\.deadline) + boosts.values.compactMap(\.deadline) + [returnDeadline].compactMap { $0 }).min() }

    init(config: FloatingRingConfig, sessionID: UUID, touch: FloatingPoint, usable: FloatingRect) throws {
        geometry = try .init(config: config); self.sessionID = sessionID
        guard config.isActive, let placed = geometry.place(at: touch, usable: usable) else {
            throw FloatingControlError("The ring and its Finish target do not fit this canvas, or every ring layer is disabled.")
        }
        placement = placed
    }
    mutating func clearIssue() { issue = nil }
    mutating func begin(contact token: Int, point: FloatingPoint, initial: Bool, time: Double,
                        environment: FloatingRingEnvironment) -> Bool {
        guard !finished, contact == nil, point.isValid else { return false }
        let physical = placement.local(point, applyGrabOffset: false)
        if !initial && geometry.finish.contains(physical) { finish(); return true }
        let selectedRole = initial ? config.startRole : geometry.role(at: physical)
        guard let selectedRole else { return false }
        let selectedKnob = initial ? config.knob(config.startKnobID) : geometry.knob(at: physical)
        gesture &+= 1; began = time; elapsed = 0; contact = token; role = selectedRole
        lastPoint = point; applyGrabOffset = initial; finishGuard = .init(initiallyInside: geometry.finish.contains(physical))
        previousOutputs = outputs.filter { $0.value.hasReservation }.mapValues { ($0.generation, $0.retained) }
        overridden = []; issue = nil; visited = []; fineGesture = false; directOneUnlocked = false
        movementOverridden = false; aimOverridden = false
        aimActive = false
        fireStopped = false; adsStopped = false; releaseCancelled = false; armed = false; fireEligible = false; firedThisGesture = false
        returnDeadline = nil
        let logical = placement.local(point, applyGrabOffset: initial); insideAim = geometry.insideAim(logical)
        switch selectedRole {
        case .movement:
            updateMovement(initial ? config.movement.initialPosition : geometry.movementVector(at: logical), environment: environment)
        case .aim:
            guard let selectedKnob, startAim(selectedKnob, physical: physical, directAddition: false, time: time, environment: environment) else {
                cancel(); return false
            }
        case .boostOne, .boostTwo:
            let stage: RingBoostStage = selectedRole == .boostOne ? .one : .two
            boosts[stage]!.inside = true
            enterBoost(stage, direction: geometry.boostDirection(at: logical), sampleTime: time, now: time, terminal: false, environment: environment)
        }
        macrosSuppressed = false
        return true
    }
    /// Validation has no effects. The complete Finish path is checked before output dispatch.
    mutating func samples(contact token: Int, samples: [FloatingRingSample], ending: Bool, now: Double,
                          environment: FloatingRingEnvironment) throws -> [PointerDelta] {
        guard contact == token, !finished else { return [] }
        guard samples.count <= 256 else { throw ControllerInputError.invalidPosition }
        var previous = elapsed
        for sample in samples {
            let local = placement.local(sample.point, applyGrabOffset: false)
            // UITouch timestamps and the enclosing callback clock share uptime but arrive
            // with different delivery latency. Match TouchAim's bounded 50 ms tolerance.
            guard sample.isValid, sample.elapsed >= previous, began + sample.elapsed <= now + 0.05,
                  abs(local.x) <= 65_536, abs(local.y) <= 65_536 else { throw ControllerInputError.invalidPosition }
            previous = sample.elapsed
        }
        var guardCopy = finishGuard
        if samples.contains(where: { guardCopy.observe(inside: geometry.finish.contains(placement.local($0.point, applyGrabOffset: false))) }) {
            finish(); return []
        }
        finishGuard = guardCopy
        var movement: [PointerDelta] = []
        for (index, sample) in samples.enumerated() {
            movement += observe(sample, terminal: ending && index == samples.count - 1, now: now, environment: environment)
            elapsed = sample.elapsed
        }
        if ending { lift(now: now, environment: environment) }
        return movement
    }
    private mutating func observe(_ sample: FloatingRingSample, terminal: Bool, now: Double,
                                  environment: FloatingRingEnvironment) -> [PointerDelta] {
        let previous = placement.local(lastPoint, applyGrabOffset: applyGrabOffset)
        let logical = placement.local(sample.point, applyGrabOffset: applyGrabOffset)
        let physical = placement.local(sample.point, applyGrabOffset: false)
        lastPoint = sample.point
        let wasInside = insideAim; insideAim = geometry.insideAim(logical)
        if role == .movement { updateMovement(geometry.movementVector(at: logical), environment: environment) }
        let direct = role == .boostOne || role == .boostTwo
        if direct && !aimActive && config.directBoostToAim && insideAim && !terminal,
           let destination = config.knob(config.directBoostAimKnobID), destination.enabled {
            _ = startAim(destination, physical: physical, directAddition: true, time: now, environment: environment)
        }
        if participatesInBoosts {
            evaluateBoosts(point: logical, previous: previous, direct: direct, sampleTime: began + sample.elapsed,
                           now: now, terminal: terminal, environment: environment)
        }
        if aimActive {
            if wasInside && !insideAim { leaveAim(at: physical) }
            if (!wasInside && insideAim) || (direct && insideAim && !visited.isEmpty) {
                returnToAim(at: physical, sampleTime: began + sample.elapsed, now: now, terminal: terminal, environment: environment)
            }
            if config.aim.continueOutside || insideAim { return updateAim(at: physical) }
        }
        return []
    }
    private var participatesInBoosts: Bool {
        switch role { case .movement: config.movement.participateInBoosts; case .aim: config.aim.participateInBoosts
        case .boostOne, .boostTwo: true; case nil: false }
    }
    private mutating func updateMovement(_ vector: StickPosition, environment: FloatingRingEnvironment) {
        guard !movementOverridden, let channel = config.movement.output.logicalStick else { return }
        if environment.occupiedChannels.contains(channel) || (aimAnalog?.channel == channel && aimAnalog?.retained == false) {
            movementAnalog = nil; movementOverridden = true; issue = "Another active control owns this movement stick."; return
        }
        if aimAnalog?.channel == channel && aimAnalog?.retained == true { aimRuntime = nil }
        movementAnalog = .init(channel: channel, position: StickResponseSettings(mode: config.movement.response, sensitivity: config.movement.sensitivity).applyValidated(vector), retained: false)
    }
    private func aimSample(_ physical: FloatingPoint) -> ButtonPointerSample {
        let size = min(1200, max(1, config.innerRadius * 2))
        return .init(x: physical.x - geometry.center.x + size/2, y: physical.y - geometry.center.y + size/2, width: size, height: size)
    }
    private var effectiveTuning: ButtonAimTuning {
        var tuning = config.aim.tuning; if fine { tuning.sensitivity = config.aim.fine.sensitivity }; return tuning
    }
    private mutating func startAim(_ selected: RingAimKnob, physical: FloatingPoint, directAddition: Bool, time: Double,
                                   environment: FloatingRingEnvironment) -> Bool {
        guard !aimOverridden else { return false }
        if knobID != nil && knobID != selected.id { stopOutput(.fire); stopOutput(.ads) }
        knobID = selected.id
        let tuning = effectiveTuning
        if let channel = tuning.output.logicalStick,
           environment.occupiedChannels.contains(channel) || (movementAnalog?.channel == channel && movementAnalog?.retained == false) {
            aimOverridden = true; issue = "Another active control owns this aim stick."; return false
        }
        let sample = aimSample(physical)
        aimRuntime = .init(origin: sample, last: sample)
        aimActive = true
        if let channel = tuning.output.logicalStick {
            if movementAnalog?.channel == channel && movementAnalog?.retained == true { movementAnalog = nil }
            aimRuntime?.analog = .init(channel: channel, position: .zero, retained: false)
            if directAddition && tuning.origin == .controlCenter {
                aimRuntime?.centerOffset = .init(x: sample.x - sample.width/2, y: sample.y - sample.height/2)
            }
            if !directAddition && tuning.origin == .controlCenter { _ = updateAim(at: physical) }
        }
        if config.aim.suppressCameraFollow && tuning.output.isMouse { suppressed = true }
        if !directAddition {
            if !adsStopped { hold(.ads, payload: selected.fire.adsPayload, environment: environment) }
            if !selected.fire.returnFire.enabled { activateFire(now: time, environment: environment) }
        }
        return true
    }
    private mutating func updateAim(at physical: FloatingPoint) -> [PointerDelta] {
        guard var aim = aimRuntime, !aim.suspended else { return [] }
        let sample = aimSample(physical), tuning = effectiveTuning
        defer { aim.last = sample; aimRuntime = aim }
        if let channel = tuning.output.logicalStick {
            guard aim.analog != nil else { return [] }
            var adjusted = sample; adjusted.x -= aim.centerOffset.x; adjusted.y -= aim.centerOffset.y
            aim.analog = .init(channel: channel, position: AimSurfaceMath.stick(sample: adjusted, origin: aim.origin, tuning: tuning), retained: false)
            return []
        }
        var dx = (sample.x - aim.last.x) * tuning.sensitivity
        var dy = (sample.y - aim.last.y) * tuning.sensitivity * (tuning.invertY ? -1 : 1)
        if tuning.mouseResponse == .smoothedNonlinear {
            dx = (dx + aim.smoothed.dx)/2; dy = (dy + aim.smoothed.dy)/2; aim.smoothed = .init(dx: dx, dy: dy)
            dx = AimSurfaceMath.mouseCurve(dx); dy = AimSurfaceMath.mouseCurve(dy)
        }
        return dx == 0 && dy == 0 ? [] : [.init(dx: dx, dy: dy)]
    }
    private mutating func leaveAim(at point: FloatingPoint) {
        guard let fire = knob?.fire else { return }
        if !config.aim.continueOutside {
            let sample = aimSample(point); aimRuntime?.suspended = true; aimRuntime?.last = sample
            aimRuntime?.smoothed = .zero; aimRuntime?.analog?.position = .zero
        }
        if fire.returnFire.enabled && fire.returnFire.cancelOnExit { returnDeadline = nil; if !fireEligible { armed = false } }
        if !fire.continueADSOutside { stopOutput(.ads) }
        if !fire.continueFireOutside && (fire.mode == .hold || fire.mode == .repeat) { stopOutput(.fire) }
        if fire.mode == .releaseShot && fire.cancelReleaseShotOnBoundaryExit { releaseCancelled = true; armed = false }
    }
    private mutating func returnToAim(at point: FloatingPoint, sampleTime: Double, now: Double, terminal: Bool,
                                      environment: FloatingRingEnvironment) {
        guard let fire = knob?.fire else { return }
        if aimRuntime?.suspended == true {
            let sample = aimSample(point); aimRuntime?.origin = sample; aimRuntime?.last = sample
            aimRuntime?.smoothed = .zero; aimRuntime?.suspended = false
            if config.aim.tuning.origin == .controlCenter {
                aimRuntime?.centerOffset = .init(x: sample.x - sample.width/2, y: sample.y - sample.height/2)
            }
        }
        if config.aim.fine.enabled && !visited.isDisjoint(with: config.aim.fine.qualifyingStages) {
            fineGesture = true
            aimRuntime?.smoothed = .zero
            fineLatchStages.formUnion(visited.intersection(config.aim.fine.qualifyingStages).filter { boosts[$0]!.latched })
        }
        if releaseCancelled && fire.rearmReleaseShotOnBoundaryReturn {
            releaseCancelled = false; if fireEligible { armed = fire.mode == .releaseShot }
        }
        if !terminal && !fireStopped && fire.mode != .none && fire.returnFire.enabled &&
            !visited.isDisjoint(with: fire.returnFire.qualifyingStages) && returnDeadline == nil {
            fireEligible = false; armed = false; firedThisGesture = false
            if fire.returnFire.delayMilliseconds == 0 { activateFire(now: now, environment: environment) }
            else { returnDeadline = sampleTime + Double(fire.returnFire.delayMilliseconds)/1000 }
        } else if !terminal && !fireStopped && returnDeadline == nil &&
                    ((fire.returnFire.enabled && fireEligible) || (!fire.returnFire.enabled && role == .aim && (fire.mode == .hold || fire.mode == .repeat))) {
            activateFire(now: now, environment: environment)
        }
        if !terminal && role == .aim && !fire.continueADSOutside && !adsStopped { hold(.ads, payload: fire.adsPayload, environment: environment) }
        visited = []
    }
    private mutating func activateFire(now: Double, environment: FloatingRingEnvironment) {
        guard !fireStopped, contact != nil, !finished, let fire = knob?.fire else { return }
        fireEligible = true
        if !insideAim && !fire.continueFireOutside && fire.mode != .releaseShot { return }
        switch fire.mode {
        case .none: break
        case .hold: hold(.fire, payload: fire.firePayload, environment: environment)
        case .tap:
            if !firedThisGesture { firedThisGesture = true; pulse(.fire, payload: fire.firePayload, press: fire.pulsePressMilliseconds, gap: fire.pulseGapMilliseconds, now: now, environment: environment) }
        case .releaseShot: if !releaseCancelled { armed = true }
        case .repeat: repeatOutput(.fire, payload: fire.firePayload, press: fire.pulsePressMilliseconds, gap: fire.pulseGapMilliseconds, now: now, environment: environment)
        }
    }
    private mutating func evaluateBoosts(point: FloatingPoint, previous: FloatingPoint, direct: Bool, sampleTime: Double,
                                         now: Double, terminal: Bool, environment: FloatingRingEnvironment) {
        let selected: RingBoostStage = role == .boostOne ? .one : .two, distance = geometry.distance(to: point)
        let returning = role == .boostTwo && config.directBoostTwoToOne && config.boost1.enabled && !directOneUnlocked &&
            geometry.distance(to: previous) >= config.boost2.directInnerDistance && distance < config.boost2.directInnerDistance
        if returning { directOneUnlocked = true }
        func returningOne(_ stage: RingBoostStage) -> Bool { role == .boostTwo && directOneUnlocked && stage == .one }
        for stage in RingBoostStage.allCases.reversed() {
            if direct && stage != selected && !returningOne(stage) { continue }
            let settings = config.boost(stage), state = boosts[stage]!
            let inside = direct && !returningOne(stage) ? geometry.directHit(stage, at: point) : settings.enabled && distance >= settings.distance - (state.inside ? settings.hysteresis : 0)
            if state.inside && !inside { boosts[stage]!.inside = false; exitBoost(stage) }
        }
        for stage in RingBoostStage.allCases {
            if direct && stage != selected && !returningOne(stage) { continue }
            let settings = config.boost(stage), crossed = returningOne(stage) && returning
            let enters = direct && !returningOne(stage) ? geometry.directHit(stage, at: point) : settings.enabled && distance >= settings.distance
            let direction = geometry.boostDirection(at: crossed && !enters ? previous : point, previous: boosts[stage]!.direction)
            if !boosts[stage]!.inside && (enters || crossed) {
                boosts[stage]!.inside = true
                enterBoost(stage, direction: direction, sampleTime: sampleTime, now: now, terminal: terminal, environment: environment)
                if distance < settings.distance - settings.hysteresis { boosts[stage]!.inside = false; exitBoost(stage) }
            } else if boosts[stage]!.inside && direction != boosts[stage]!.direction && boosts[stage]!.deadline == nil && !boosts[stage]!.latched {
                if settings.action != .tap { stopOutput(slot(stage)) }
                enterBoost(stage, direction: direction, sampleTime: sampleTime, now: now, terminal: terminal, environment: environment)
            }
        }
    }
    private mutating func enterBoost(_ stage: RingBoostStage, direction: StickDirection, sampleTime: Double, now: Double,
                                     terminal: Bool, environment: FloatingRingEnvironment) {
        visited.insert(stage); boosts[stage]!.direction = direction
        guard !terminal, boosts[stage]!.deadline == nil, !boosts[stage]!.latched,
              !outputs[slot(stage)]!.retained, !overridden.contains(slot(stage)) else { return }
        let settings = config.boost(stage), payload = settings.payload(for: direction), keys = ringKeys(payload)
        guard !payload.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        if fireStopped && config.knobs.contains(where: { !keys.isDisjoint(with: ringKeys($0.fire.firePayload)) }) { return }
        if adsStopped && (isADS(payload) || config.knobs.contains(where: { !keys.isDisjoint(with: ringKeys($0.fire.adsPayload)) })) { return }
        if settings.activationDelayMilliseconds > 0 {
            boosts[stage]!.pendingPayload = payload
            boosts[stage]!.deadline = sampleTime + Double(settings.activationDelayMilliseconds)/1000
        } else { activateBoost(stage, payload: payload, now: now, environment: environment) }
    }
    private mutating func activateBoost(_ stage: RingBoostStage, payload: String, now: Double, environment: FloatingRingEnvironment) {
        let settings = config.boost(stage), id = slot(stage)
        switch settings.action {
        case .tap: pulse(id, payload: payload, press: settings.pulsePressMilliseconds, gap: settings.pulseGapMilliseconds, now: now, environment: environment)
        case .hold:
            if boosts[stage]!.inside || settings.latchOnExit {
                hold(id, payload: payload, environment: environment); boosts[stage]!.latched = settings.latchOnExit && outputs[id]!.held
                if boosts[stage]!.latched && fineGesture && config.aim.fine.qualifyingStages.contains(stage) { fineLatchStages.insert(stage) }
            }
        case .repeat:
            if boosts[stage]!.inside || settings.repeatAfterExit {
                repeatOutput(id, payload: payload, press: settings.pulsePressMilliseconds, gap: settings.pulseGapMilliseconds, now: now, environment: environment)
            }
        }
    }
    private mutating func exitBoost(_ stage: RingBoostStage) {
        let settings = config.boost(stage), id = slot(stage)
        if settings.cancelDelayOnExit { boosts[stage]!.deadline = nil; boosts[stage]!.pendingPayload = "" }
        if settings.action == .hold && !boosts[stage]!.latched && !outputs[id]!.retained { stopOutput(id) }
        if settings.action == .repeat && !settings.repeatAfterExit && !outputs[id]!.retained { stopOutput(id) }
    }
    private func isADS(_ payload: String) -> Bool {
        let keys = ringKeys(payload)
        return keys.contains(.trigger(.left)) || keys.contains(.mouse(.right))
    }
    private mutating func stopOutput(_ id: FloatingRingSlot) { outputs[id]!.stop() }
    private mutating func failed(_ id: FloatingRingSlot) {
        overridden.insert(id); issue = "Another active output owns this ring action. Lift and start a new gesture to retry."
    }
    private mutating func hold(_ id: FloatingRingSlot, payload: String, environment: FloatingRingEnvironment) {
        guard !overridden.contains(id) else { return }
        let keys = ringKeys(payload)
        let fireKeys = config.knobs.reduce(into: Set<RingOutputKey>()) { $0.formUnion(ringKeys($1.fire.firePayload)) }
        let exclusive = id == .ads ? [] : id == .fire ? keys : keys.intersection(fireKeys)
        if !outputs[id]!.hold(payload, gesture: gesture, exclusive: exclusive, permitted: exclusive.isDisjoint(with: environment.blockedPayloadKeys)) { failed(id) }
    }
    private mutating func pulse(_ id: FloatingRingSlot, payload: String, press: Int, gap: Int, now: Double, environment: FloatingRingEnvironment) {
        guard !overridden.contains(id) else { return }
        if !outputs[id]!.pulse(payload, pressMilliseconds: press, gapMilliseconds: gap, gesture: gesture, now: now,
                              permitted: ringKeys(payload).isDisjoint(with: environment.blockedPayloadKeys)) { failed(id) }
    }
    private mutating func repeatOutput(_ id: FloatingRingSlot, payload: String, press: Int, gap: Int, now: Double, environment: FloatingRingEnvironment) {
        guard !overridden.contains(id) else { return }
        if !outputs[id]!.repeatOutput(payload, pressMilliseconds: press, gapMilliseconds: gap, gesture: gesture, now: now,
                                     permitted: ringKeys(payload).isDisjoint(with: environment.blockedPayloadKeys)) { failed(id) }
    }
    mutating func advance(to now: Double, environment: FloatingRingEnvironment) {
        guard !finished else { return }
        for id in FloatingRingSlot.allCases {
            if !outputs[id]!.advance(to: now, permits: { $0.isDisjoint(with: environment.blockedPayloadKeys) }) { failed(id) }
        }
        guard contact != nil else { return }
        for stage in RingBoostStage.allCases {
            if let due = boosts[stage]!.deadline, now + 1e-10 >= due {
                let settings = config.boost(stage), payload = boosts[stage]!.pendingPayload
                boosts[stage]!.deadline = nil; boosts[stage]!.pendingPayload = ""
                if boosts[stage]!.inside || !settings.cancelDelayOnExit { activateBoost(stage, payload: payload, now: now, environment: environment) }
            }
        }
        if let due = returnDeadline, now + 1e-10 >= due {
            returnDeadline = nil
            if !fireStopped && aimActive && (insideAim || knob?.fire.returnFire.cancelOnExit == false) { activateFire(now: now, environment: environment) }
        }
    }
    private mutating func lift(now: Double, environment: FloatingRingEnvironment) {
        guard contact != nil, !finished else { return }
        returnDeadline = nil
        for stage in RingBoostStage.allCases { boosts[stage]!.deadline = nil; boosts[stage]!.pendingPayload = "" }
        let fire = knob?.fire
        if aimActive, let fire, fire.mode == .releaseShot && armed && !releaseCancelled && !fireStopped {
            pulse(.fire, payload: fire.firePayload, press: fire.pulsePressMilliseconds, gap: fire.pulseGapMilliseconds, now: now, environment: environment)
        }
        armed = false
        if role == .movement {
            if config.movement.autoCenter { movementAnalog = nil } else { movementAnalog?.retained = true }
        }
        if aimActive {
            if config.aim.tuning.autoCenter || aimAnalog == nil { aimRuntime = nil } else { aimRuntime?.analog?.retained = true }
            if let fire {
                outputs[.ads]!.retainOrRelease(fire.retainADSOnLift)
                if fire.mode != .tap && fire.mode != .releaseShot { outputs[.fire]!.retainOrRelease(fire.retainFireOnLift) }
            }
        }
        for stage in RingBoostStage.allCases {
            let id = slot(stage), settings = config.boost(stage)
            if settings.action != .tap { outputs[id]!.retainOrRelease(settings.retainOnLift) }
            boosts[stage]!.latched = boosts[stage]!.latched && outputs[id]!.held; boosts[stage]!.inside = false
            if !boosts[stage]!.latched { fineLatchStages.remove(stage) }
        }
        endPointer()
    }
    mutating func cancel() {
        guard contact != nil else { return }
        let cancelled = gesture; gesture &+= 1; returnDeadline = nil; armed = false
        for stage in RingBoostStage.allCases { boosts[stage]!.deadline = nil; boosts[stage]!.pendingPayload = ""; boosts[stage]!.inside = false }
        if aimActive { aimRuntime = nil }
        if role == .movement && movementAnalog?.retained != true { movementAnalog = nil }
        for id in FloatingRingSlot.allCases {
            let output = outputs[id]!, old = previousOutputs[id]
            if old?.generation != output.generation || output.activeGesture == cancelled { stopOutput(id) }
            else if let old, output.hasReservation { outputs[id]!.restoreRetained(old.retained, cancelQueuedFrom: cancelled) }
        }
        for stage in RingBoostStage.allCases {
            boosts[stage]!.latched = boosts[stage]!.latched && outputs[slot(stage)]!.held
            if !boosts[stage]!.latched { fineLatchStages.remove(stage) }
        }
        endPointer()
    }
    private mutating func endPointer() { contact = nil; role = nil; aimActive = false; visited = []; previousOutputs = [:]; applyGrabOffset = false }
    mutating func finish() { finished = true; clear() }
    mutating func clear() {
        gesture &+= 1; returnDeadline = nil; armed = false; suppressed = false
        for id in FloatingRingSlot.allCases { stopOutput(id) }
        boosts = [.one: .init(), .two: .init()]; movementAnalog = nil; aimRuntime = nil; fineGesture = false; fineLatchStages = []
        endPointer()
    }
    mutating func recenter() {
        macrosSuppressed = true
        movementAnalog = nil; aimRuntime?.analog = nil; movementOverridden = true; aimOverridden = true
        for stage in RingBoostStage.allCases { boosts[stage]!.deadline = nil; boosts[stage]!.pendingPayload = ""; boosts[stage]!.latched = false; stopOutput(slot(stage)) }
        fineLatchStages = []; fineGesture = false
    }
    mutating func yieldRetained(channel: ControllerControlID) {
        if movementAnalog?.channel == channel && movementAnalog?.retained == true { movementAnalog = nil; movementOverridden = true }
        if aimAnalog?.channel == channel && aimAnalog?.retained == true { aimRuntime = nil; aimOverridden = true }
    }
    mutating func localAction(_ action: FloatingLocalAction) {
        switch action {
        case .finish: finish()
        case .endSuppression: suppressed = false
        case .stopFire:
            fireStopped = true; fireEligible = false; armed = false; returnDeadline = nil; stopOutput(.fire)
            let keys = config.knobs.reduce(into: Set<RingOutputKey>()) { $0.formUnion(ringKeys($1.fire.firePayload)) }
            for stage in RingBoostStage.allCases {
                let id = slot(stage), payloads = [boosts[stage]!.pendingPayload, outputs[id]!.payload, outputs[id]!.queued?.payload ?? ""]
                if payloads.contains(where: { !ringKeys($0).isDisjoint(with: keys) }) { cancelBoost(stage) }
            }
        case .releaseADS:
            adsStopped = true; stopOutput(.ads)
            let ads = ringKeys(knob?.fire.adsPayload ?? "")
            for stage in RingBoostStage.allCases {
                let id = slot(stage), payloads = [boosts[stage]!.pendingPayload, outputs[id]!.payload, outputs[id]!.queued?.payload ?? ""]
                if payloads.contains(where: { isADS($0) || !ringKeys($0).isDisjoint(with: ads) }) { cancelBoost(stage) }
            }
            fineGesture = false; fineLatchStages = []
        }
    }
    private mutating func cancelBoost(_ stage: RingBoostStage) {
        boosts[stage]!.deadline = nil; boosts[stage]!.pendingPayload = ""; boosts[stage]!.latched = false
        stopOutput(slot(stage)); if fineLatchStages.remove(stage) != nil { fineGesture = false }
    }
}
