import Foundation

/// One ring-owned output slot. Reservation outlives its ON claim through every OFF gap.
/// All transitions occur on the enclosing engine's monotonic clock; no detached tasks exist.
struct FloatingRingOutput: Sendable {
    struct Request: Sendable {
        var payload: String
        var press: Double
        var gap: Double
        var gesture: UInt64
    }
    enum Phase: Sendable { case idle, held, on, gap }
    private(set) var phase: Phase = .idle
    private(set) var payload = ""
    private(set) var retained = false
    private(set) var repeating = false
    private(set) var generation: UInt64 = 0
    private(set) var activeGesture: UInt64?
    private(set) var queued: Request?
    private(set) var deadline: Double?
    private var press: Double = 0.035
    private var gap: Double = 0.035
    private var lease: OwnedGesturePayloadLease?
    private var logicalKeys: Set<RingOutputKey> = []
    private(set) var exclusiveKeys: Set<RingOutputKey> = []
    var held: Bool { phase == .held || phase == .on }
    var busy: Bool { phase == .on || phase == .gap }
    var hasReservation: Bool { phase != .idle }
    var keys: Set<RingOutputKey> { hasReservation ? logicalKeys : [] }
    var claims: GesturePayloadClaims { held ? lease?.claims(at: 0) ?? .init() : .init() }
    func macroLease(control: UUID, priority: Int) -> SustainedMacroLease? {
        guard hasReservation, let lease else { return nil }
        return .init(id: lease.activationID, control: control, program: lease.program,
                     priority: priority, started: 0, active: held, retained: retained)
    }

    mutating func stop() {
        generation &+= 1; phase = .idle; retained = false; repeating = false
        activeGesture = nil; queued = nil; deadline = nil; lease = nil; exclusiveKeys = []; logicalKeys = []
    }
    /// Same held payload reuses its original ownership generation; cancellation of a later
    /// touch can restore its earlier retained state rather than releasing someone else's hold.
    mutating func hold(_ payload: String, gesture: UInt64, exclusive: Set<RingOutputKey>,
                       permitted: Bool) -> Bool {
        guard !payload.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return true }
        if held && self.payload == payload { retained = false; return true }
        stop()
        guard permitted, let program = try? ringProgram(payload) else { return false }
        self.payload = payload; phase = .held; activeGesture = gesture; exclusiveKeys = exclusive; logicalKeys = ringKeys(payload)
        lease = .init(program: program, started: 0); return true
    }
    mutating func pulse(_ payload: String, pressMilliseconds: Int, gapMilliseconds: Int,
                        gesture: UInt64, now: Double, permitted: Bool) -> Bool {
        guard !payload.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return true }
        let request = Request(payload: payload, press: Double(pressMilliseconds)/1000,
                              gap: Double(gapMilliseconds)/1000, gesture: gesture)
        if busy { if queued == nil { queued = request }; return true }
        stop()
        guard permitted else { return false }
        return start(request, now: now, repeating: false)
    }
    mutating func repeatOutput(_ payload: String, pressMilliseconds: Int, gapMilliseconds: Int,
                               gesture: UInt64, now: Double, permitted: Bool) -> Bool {
        guard !payload.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return true }
        if repeating && self.payload == payload { return true }
        stop()
        guard permitted else { return false }
        return start(.init(payload: payload, press: Double(pressMilliseconds)/1000,
                           gap: Double(gapMilliseconds)/1000, gesture: gesture), now: now, repeating: true)
    }
    private mutating func start(_ request: Request, now: Double, repeating: Bool) -> Bool {
        guard now.isFinite, now >= 0, request.press.isFinite, request.gap.isFinite,
              (0.001...60).contains(request.press), (0.001...60).contains(request.gap),
              let program = try? ringProgram(request.payload) else { stop(); return false }
        generation &+= 1; payload = request.payload; press = request.press; gap = request.gap
        phase = .on; self.repeating = repeating; activeGesture = request.gesture; deadline = now + press
        logicalKeys = ringKeys(payload); exclusiveKeys = logicalKeys; lease = .init(program: program, started: 0)
        return true
    }
    /// Advance at most one phase. A late callback still exposes a full OFF gap and never
    /// invents a burst of missed taps. Queued retrigger acquisition is checked at that time.
    mutating func advance(to time: Double, permits: (Set<RingOutputKey>) -> Bool) -> Bool {
        guard let deadline, time + max(1e-10,time.ulp*2) >= deadline else { return true }
        switch phase {
        case .on:
            phase = .gap; self.deadline = time + gap
        case .gap:
            if repeating {
                guard permits(exclusiveKeys) else { stop(); return false }
                phase = .on; self.deadline = time + press; queued = nil
            } else if let request = queued {
                queued = nil; retained = false
                guard permits(ringKeys(request.payload)) else { stop(); return false }
                return start(request, now: time, repeating: false)
            } else { stop() }
        case .idle, .held: self.deadline = nil
        }
        return true
    }
    mutating func retainOrRelease(_ retain: Bool) {
        if retain && (held || repeating) { retained = true } else { stop() }
    }
    mutating func restoreRetained(_ value: Bool, cancelQueuedFrom gesture: UInt64) {
        retained = value
        if queued?.gesture == gesture { queued = nil }
    }
}
