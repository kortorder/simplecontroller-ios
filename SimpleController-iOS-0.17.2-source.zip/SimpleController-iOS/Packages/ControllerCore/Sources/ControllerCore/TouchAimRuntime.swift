import Foundation

/// Captured TouchAim owners. Configuration is supplied explicitly so the detector/diagnostic
/// foundation can compile independently of native-profile version migration.
struct TouchAimRuntime: Sendable {
    enum Slot:Int,Hashable,Sendable { case aim,low,medium,high,shoot,pressLow,pressMedium,pressHigh,pressShoot
        var priority:Int { switch self { case .aim:0;case .low,.pressLow:1;case .medium,.pressMedium:2;case .high,.pressHigh:3;case .shoot,.pressShoot:4 } }
    }
    struct Analog:Sendable { var channel:ControllerControlID;var position:StickPosition }
    struct Session:Sendable {
        var contact:Int;var settings:TouchAimSettings;var detector:TouchAimDetector
        var origin:ButtonPointerSample;var pointer:ButtonPointerSample;var started:Double;var lastElapsed:Double
        var lastDetectorTick: Double = 0
        var previousMouse=PointerDelta.zero
        var leases:[Slot:OwnedGesturePayloadLease]=[:]
        var analog:Analog?
        var macrosSuppressed = false
    }
    private var settings:[UUID:TouchAimSettings]
    private var programs:[UUID:[Slot:ControllerPayloadProgram]]
    private(set) var contacts:[Int:UUID]=[:]
    private(set) var sessions:[UUID:Session]=[:]
    private(set) var issues:[UUID:String]=[:]
    private var takeovers:Set<ControllerControlID>=[]
    init(configurations:[UUID:TouchAimSettings])throws {
        guard configurations.count<=64 else { throw ControllerProfileError.tooManyControls }
        settings=configurations;programs=[:]
        for (id,c) in configurations {
            try c.validate()
            programs[id]=[.aim:try advancedButtonProgram(c.twoState.aimPayload),.shoot:try advancedButtonProgram(c.twoState.shootPayload),
                .low:try advancedButtonProgram(c.threeStage.low.payload),.medium:try advancedButtonProgram(c.threeStage.medium.payload),.high:try advancedButtonProgram(c.threeStage.high.payload)]
        }
    }
    var active:Set<UUID> { Set(contacts.values) }
    var states:[UUID:TouchAimState] { sessions.mapValues{$0.detector.state}.merging(issues.mapValues{_ in .unavailable},uniquingKeysWith:{_,new in new}) }
    var scores:[UUID:Double] { sessions.mapValues{$0.detector.filteredScore} }
    var analogs:[UUID:Analog] { sessions.compactMapValues(\.analog) }
    var occupiedChannels:Set<ControllerControlID> { Set(analogs.values.map(\.channel)) }
    mutating func consumeTakeovers()->Set<ControllerControlID> { let result=takeovers;takeovers=[];return result }
    mutating func clear() { sessions.removeAll();contacts.removeAll();issues.removeAll();takeovers=[] }
    mutating func clear(controls ids:Set<UUID>) {
        let removedChannels=Set(sessions.filter { ids.contains($0.key) }.compactMap { $0.value.analog?.channel })
        sessions=sessions.filter { !ids.contains($0.key) };contacts=contacts.filter { !ids.contains($0.value) }
        issues=issues.filter { !ids.contains($0.key) };takeovers.subtract(removedChannels)
    }
    mutating func recenter() {
        // TouchAim's pointer remains captured; Re-center disables further analog output
        // until a new touch, while preserving this touch's independently owned payloads.
        for id in sessions.keys { sessions[id]?.analog=nil; sessions[id]?.macrosSuppressed = true }
    }
    mutating func begin(contact:Int,id:UUID,sample:TouchAimSample,time:Double,occupied:Set<ControllerControlID>,retained:Set<ControllerControlID>)throws->Bool {
        guard sample.isValid,sample.elapsed==0,time.isFinite,time>=0 else { throw ControllerInputError.invalidPosition }
        guard contacts[contact]==nil,!contacts.values.contains(id),let c=settings[id] else { return false }
        if let channel=c.aim.output.logicalStick,occupied.contains(channel) || occupiedChannels.contains(channel) { return false }
        var detector=try TouchAimDetector(settings:c)
        let actions=try detector.begin(metrics:sample.metrics,at:0)
        if let issue=detector.issue { issues[id]=issue;return false }
        issues[id]=nil
        var s=Session(contact:contact,settings:c,detector:detector,origin:sample.pointer,pointer:sample.pointer,started:time,lastElapsed:0)
        if let channel=c.aim.output.logicalStick {
            let initial=retained.contains(channel) ? AimSurfaceMath.stick(sample:sample.pointer,origin:sample.pointer,tuning:c.aim):.zero
            s.analog = .init(channel:channel,position:initial);takeovers.insert(channel)
        }
        apply(actions,to:&s,id:id,time:time)
        sessions[id]=s;contacts[contact]=id;return true
    }
    func validateBatch(contact:Int,samples:[TouchAimSample],time:Double)throws {
        guard time.isFinite,time>=0,samples.count<=256,samples.allSatisfy(\.isValid) else { throw ControllerInputError.invalidPosition }
        guard let id=contacts[contact],let s=sessions[id] else { return }
        var last=s.lastElapsed
        for sample in samples {
            guard sample.elapsed>=last,sample.elapsed<=max(0,time-s.started)+0.05 else { throw ControllerInputError.invalidTime }
            last=sample.elapsed
        }
    }
    /// The caller advances confirmation deadlines only after this complete batch is observed.
    mutating func move(contact:Int,samples:[TouchAimSample],time:Double)throws->[PointerDelta] {
        try validateBatch(contact:contact,samples:samples,time:time)
        guard let id=contacts[contact],var s=sessions[id] else { return [] }
        var movement:[PointerDelta]=[]
        for sample in samples {
            let actions=try s.detector.observe(metrics:sample.metrics,at:sample.elapsed,allowConfirmation:false)
            if let issue=s.detector.issue { issues[id]=issue;sessions[id]=nil;contacts[contact]=nil;return [] }
            apply(actions,to:&s,id:id,time:s.started+sample.elapsed)
            let tuning=currentTuning(s)
            if tuning.output.isMouse {
                let dx=(sample.pointer.x-s.pointer.x)*tuning.sensitivity
                let dy=(sample.pointer.y-s.pointer.y)*tuning.sensitivity*(tuning.invertY ? -1:1)
                if dx != 0 || dy != 0 {
                    var delta=PointerDelta(dx:dx,dy:dy)
                    if tuning.mouseResponse == .smoothedNonlinear {
                        s.previousMouse = .init(dx:dx*0.5+s.previousMouse.dx*0.5,dy:dy*0.5+s.previousMouse.dy*0.5)
                        delta = .init(dx:AimSurfaceMath.mouseCurve(s.previousMouse.dx),dy:AimSurfaceMath.mouseCurve(s.previousMouse.dy))
                    }
                    if abs(delta.dx)>=0.02 || abs(delta.dy)>=0.02 { movement.append(delta) }
                }
            } else if s.analog != nil { s.analog?.position=AimSurfaceMath.stick(sample:sample.pointer,origin:s.origin,tuning:tuning) }
            s.pointer=sample.pointer;s.lastElapsed=sample.elapsed
        }
        sessions[id]=s;return movement
    }
    mutating func end(contact:Int) {
        guard let id=contacts.removeValue(forKey:contact) else { return }
        // Never feed a final synthetic sensor sample or complete a return shot on lift/cancel.
        sessions[id]=nil
    }
    mutating func advance(to time:Double)throws {
        for id in Array(sessions.keys) {
            guard var s=sessions[id] else { continue }
            let elapsed=time-s.started
            guard elapsed>=0,elapsed<=3600 else { issues[id]="This touch exceeded the supported session duration. Lift and start again.";contacts[s.contact]=nil;sessions[id]=nil;continue }
            let priorState=s.detector.state
            let relativeDeadline = s.detector.nextDeadline
            let transitionTime = relativeDeadline.map { s.started + $0 } ?? time
            var detectorTime = max(elapsed, s.lastElapsed, s.lastDetectorTick)
            // Use the same absolute boundary we advertised to the app timer. Converting
            // it back by subtraction can otherwise leave the relative detector just short.
            if let relativeDeadline, GestureDeadline.reached(transitionTime, at: time) {
                detectorTime = max(detectorTime, relativeDeadline)
            }
            let actions = try s.detector.tick(at: detectorTime)
            s.lastDetectorTick = detectorTime
            // Finite presses belong to their confirmed deadline; a delayed callback must
            // not replay a press whose complete 90 ms lifetime has already elapsed.
            apply(actions,to:&s,id:id,time:min(time,transitionTime))
            if s.analog != nil && priorState != s.detector.state {
                let position=AimSurfaceMath.stick(sample:s.pointer,origin:s.origin,tuning:currentTuning(s))
                s.analog?.position=position
            }
            s.leases=s.leases.filter { $0.value.expires.map { !GestureDeadline.reached($0, at: time) } ?? true }
            sessions[id]=s
        }
    }
    func nextDeadline(after time:Double)->Double? {
        var due:[Double]=[]
        for s in sessions.values {
            if let detector=s.detector.nextDeadline { due.append(s.started+detector) }
            due += s.leases.values.compactMap{$0.nextDeadline(after:time)}
        }
        return due.filter { $0.isFinite && !GestureDeadline.reached($0, at: time) }.min()
    }
    func macroLeases(at time: Double) -> [SustainedMacroLease] {
        sessions.flatMap { id, session in
            guard !session.macrosSuppressed, !session.settings.requiresLocalSetup else { return [SustainedMacroLease]() }
            return session.leases.compactMap { slot, lease in
                if let expires = lease.expires, GestureDeadline.reached(expires, at: time) { return nil }
                return .init(id: lease.activationID, control: id, program: lease.program,
                             priority: slot.priority, started: lease.started, order: slot.rawValue)
            }
        }
    }
    func claims(at time:Double)->(claims:GesturePayloadClaims,producing:Set<UUID>,mouseOwners:Set<UUID>) {
        var result=GesturePayloadClaims(),producing:Set<UUID>=[],mouseOwners:Set<UUID>=[]
        for (id,s) in sessions {
            var own=GesturePayloadClaims()
            for (_,lease) in s.leases.sorted(by:{$0.key.priority == $1.key.priority ? $0.key.rawValue<$1.key.rawValue:$0.key.priority<$1.key.priority}) {
                own.union(lease.claims(at:time),overridePressure:true)
            }
            result.union(own)
            if !own.mouse.isEmpty { mouseOwners.insert(id) }
            if own.hasOutput || (s.analog?.position != nil && s.analog?.position != .zero) { producing.insert(id) }
        }
        return (result,producing,mouseOwners)
    }
    private func currentTuning(_ s:Session)->ButtonAimTuning {
        var tuning=s.settings.aim
        if s.detector.state == .shoot { tuning.sensitivity=s.settings.twoState.shootSensitivity }
        return tuning
    }
    private func apply(_ actions:[TouchAimDetectorAction],to s:inout Session,id:UUID,time:Double) {
        guard !s.settings.requiresLocalSetup else { s.leases.removeAll(); return }
        func stageSlot(_ level:TouchAimLevel,press:Bool=false)->Slot {
            switch level { case .low:return press ? .pressLow:.low;case .medium:return press ? .pressMedium:.medium;case .high:return press ? .pressHigh:.high;case .aimOnly:return .aim }
        }
        func acquire(_ slot:Slot,program:Slot,expires:Double?=nil) {
            s.leases[slot]=OwnedGesturePayloadLease(program:programs[id]![program]!,started:time,expires:expires)
        }
        for action in actions {
            switch action {
            case let .holdStage(level):acquire(stageSlot(level),program:stageSlot(level))
            case let .releaseStage(level):s.leases[stageSlot(level)]=nil
            case let .pressStage(level):acquire(stageSlot(level,press:true),program:stageSlot(level),expires:time+0.09)
            case .holdAim:acquire(.aim,program:.aim)
            case .releaseAim:s.leases[.aim]=nil
            case .holdShoot:acquire(.shoot,program:.shoot)
            case .releaseShoot:s.leases[.shoot]=nil
            case .pressShoot:acquire(.pressShoot,program:.shoot,expires:time+0.09)
            }
        }
    }
}
