import Foundation

/// A reversible output can be active, waiting for its start, or completing a finite release.
/// All deadlines use the enclosing engine's clock. Replacing/cancelling the bank invalidates
/// its entire schedule without asynchronous callbacks or calls to a receiver.
struct ModifiedPayloadRuntime<Slot: Hashable & Sendable>: Sendable {
    struct Cycle: Sendable {
        var period: Double
        var width: Double
    }
    private struct Key: Hashable, Sendable {
        let slot: Slot
        let program: String
        let index: Int
    }
    private struct Voice: Sendable {
        let id: UUID
        let step: ControllerPayloadStep
        let timing: PayloadCommandModifiers
        var start: Double
        let cycle: Cycle?
        let repeatsPulse: Bool
        let preserveAuthoredPulse: Bool
        let sendOnRelease: Bool
        var finiteEnd: Double?
        /// A completed normal release can own one remaining output window.
        var finitePress = false
        var released = false
        var window: Range<Double>?
        var resumable = false
        var needsGap = false

        var pressDuration: Double? {
            if case let .triggerPulse(_, _, duration) = step { return duration }
            return nil
        }
        func phase(at time: Double) -> (on: Bool, next: Double?) {
            if released {
                guard let window, !GestureDeadline.reached(window.upperBound, at: time) else { return (false, nil) }
                return GestureDeadline.reached(window.lowerBound, at: time) ? (true, window.upperBound) : (false, window.lowerBound)
            }
            guard !sendOnRelease else { return (false, nil) }
            guard GestureDeadline.reached(start, at: time) else { return (false, start) }
            if let cycle, timing.repeatMilliseconds == nil, timing.holdReleaseMilliseconds == nil {
                // D shifts the first press only. Later Turbo ticks stay on the control's cadence.
                let width = pressDuration ?? cycle.width
                let firstEnd = start + width
                if !GestureDeadline.reached(firstEnd, at: time) { return (true, firstEnd) }
                let origin = start - timing.delay
                let skip = ceil((firstEnd - origin - GestureDeadline.tolerance(at: firstEnd)) / cycle.period)
                let firstTick = origin + max(1, skip) * cycle.period
                if !GestureDeadline.reached(firstTick, at: time) { return (false, firstTick) }
                let result = GestureDeadline.phase(start: firstTick, period: cycle.period, width: min(width, cycle.period), at: time)
                return (result.on, result.next)
            }
            if let milliseconds = timing.repeatMilliseconds {
                let width = pressDuration ?? Double(min(milliseconds / 2, 50)) / 1000
                let phase = GestureDeadline.phase(start: start, period: Double(milliseconds) / 1000, width: width, at: time)
                return (phase.on, phase.next)
            }
            if let duration = pressDuration {
                let pulse = GestureDeadline.pulse(start: start, duration: duration, repeats: repeatsPulse, at: time)
                return (pulse.on, pulse.next)
            }
            return (true, nil)
        }
        mutating func release(at time: Double) {
            guard !released else { return }
            let on = phase(at: time).on
            released = true; finiteEnd = nil
            if sendOnRelease {
                let begin = time + max(timing.delay, needsGap ? 0.035 : 0)
                window = begin..<(begin + (pressDuration ?? 0.09) + timing.tail)
            } else if on {
                let pulseEnd = preserveAuthoredPulse && timing.tail == 0 && timing.repeatMilliseconds == nil && !repeatsPulse ? pressDuration.map { start + $0 } : nil
                let end = max(time + timing.tail, pulseEnd ?? time)
                if end > time {
                    window = time..<end
                    resumable = timing.tail > 0
                }
            }
        }
        func nextDeadline(after time: Double) -> Double? {
            [phase(at: time).next, finiteEnd].compactMap { $0 }.filter { !GestureDeadline.reached($0, at: time) }.min()
        }
    }

    private var voices: [Key: Voice] = [:]
    // A source may re-arm before its prior release shot finishes. Keep those shots independent.
    private var shots: [Key: [Voice]] = [:]

    mutating func start(_ slot: Slot, program: ControllerPayloadProgram, at time: Double,
                        inheritedRelease: Bool = false, releaseDelay: Double = 0,
                        cycle: Cycle? = nil, repeatsPulse: Bool = false, endsAt: Double? = nil,
                        resume: Bool = false, includePlain: Bool = false, stagePress: Bool = false, preserveAuthoredPulse: Bool = false) {
        guard program.hasModifiers else { return }
        advance(to: time, only: slot)
        for (index, step) in program.steps.enumerated() {
            var timing = program.modifiers[index]
            guard timing.isModified || includePlain else { continue }
            let defaultRelease = timing.timing == nil && inheritedRelease
            let sor = timing.timing == .sendOnRelease || defaultRelease
            if defaultRelease { timing.activationDelayMilliseconds = (timing.activationDelayMilliseconds ?? 0) + Int((releaseDelay * 1000).rounded()) }
            let key = Key(slot: slot, program: program.source, index: index)
            if resume, var prior = voices[key], prior.resumable, prior.phase(at: time).on {
                prior.released = false; prior.window = nil; prior.resumable = false
                prior.start = time
                prior.finiteEnd = endsAt
                voices[key] = prior
                continue
            }
            if var prior = voices[key], prior.released, let window = prior.window {
                // Overlapping shots of the same command share one physical hold.
                if let last = shots[key]?.last?.window, last.upperBound >= window.lowerBound && window.upperBound >= last.lowerBound {
                    prior.window = min(last.lowerBound, window.lowerBound)..<max(last.upperBound, window.upperBound)
                    shots[key]![shots[key]!.count - 1] = prior
                } else { shots[key, default: []].append(prior) }
            }
            let gap = sor && program.steps.indices.contains { sibling in
                guard sibling != index, step.timingTarget == program.steps[sibling].timingTarget else { return false }
                let m = program.modifiers[sibling]
                return m.repeatMilliseconds != nil || (cycle != nil && m.timing != .sendOnRelease && m.holdReleaseMilliseconds == nil)
            }
            var voice = Voice(id: UUID(), step: step, timing: timing, start: time + timing.delay,
                              cycle: cycle, repeatsPulse: repeatsPulse, preserveAuthoredPulse: preserveAuthoredPulse, sendOnRelease: sor, finiteEnd: endsAt)
            if stagePress {
                if sor || timing.repeatMilliseconds != nil { voice.finiteEnd = nil }
                else {
                    voice.finitePress = true
                    voice.finiteEnd = voice.start + (voice.pressDuration ?? 0.09)
                }
            }
            voice.needsGap = gap
            voices[key] = voice
        }
    }
    mutating func end(_ slot: Slot, at time: Double, suppressShot: Bool = false, preserveFinitePress: Bool = false) {
        guard voices.contains(where: { $0.key.slot == slot && !$0.value.released }) else { return }
        advance(to: time, only: slot)
        for key in voices.keys where key.slot == slot {
            if preserveFinitePress, let voice = voices[key], voice.finitePress, voice.phase(at: time).on { continue }
            if suppressShot && voices[key]?.sendOnRelease == true && voices[key]?.released == false { voices[key] = nil }
            else { voices[key]?.release(at: time) }
        }
        advance(to: time, only: slot)
    }
    mutating func suppressArmedShots(_ slot: Slot) {
        voices = voices.filter { $0.key.slot != slot || !$0.value.sendOnRelease || $0.value.released }
    }
    mutating func suppressMacros() {
        voices = voices.filter { if case .fixedStick = $0.value.step { false } else { true } }
        shots = shots.filter { if case .fixedStick = $0.value.first?.step { false } else { true } }
    }
    mutating func cancel(_ slot: Slot) { cancel { $0 == slot } }
    mutating func cancel(where predicate: (Slot) -> Bool) {
        voices = voices.filter { !predicate($0.key.slot) }; shots = shots.filter { !predicate($0.key.slot) }
    }
    mutating func advance(to time: Double, only slot: Slot? = nil) {
        for key in shots.keys where slot == nil || slot == key.slot {
            shots[key]?.removeAll { voice in voice.window.map { GestureDeadline.reached($0.upperBound, at: time) } ?? true }
            if shots[key]?.isEmpty == true { shots[key] = nil }
        }
        for key in voices.keys where slot == nil || slot == key.slot {
            guard var voice = voices[key] else { continue }
            if let end = voice.finiteEnd, GestureDeadline.reached(end, at: time) {
                if voice.finitePress { voices[key] = nil; continue }
                voice.release(at: end); voices[key] = voice
            }
            if voice.released, voice.window.map({ GestureDeadline.reached($0.upperBound, at: time) }) ?? true {
                voices[key] = nil
            }
        }
    }
    private func forEachVoice(in slot: Slot? = nil, _ body: (Key, Voice) -> Void) {
        for (key, voice) in voices where slot == nil || key.slot == slot { body(key, voice) }
        for (key, pending) in shots where slot == nil || key.slot == slot {
            for voice in pending { body(key, voice) }
        }
    }
    func nextDeadline(after time: Double) -> Double? {
        var result: Double?
        forEachVoice { _, voice in
            if let next = voice.nextDeadline(after: time) { result = min(result ?? next, next) }
        }
        return result
    }
    var targets: Set<RingOutputKey> {
        var keys: Set<RingOutputKey> = []
        forEachVoice { _, voice in if let target = voice.step.timingTarget { keys.insert(target) } }
        return keys
    }
    var slots: Set<Slot> { Set(voices.keys.map(\.slot)).union(shots.keys.map(\.slot)) }
    func claimsBySlot(at time: Double, only slot: Slot? = nil) -> [Slot: GesturePayloadClaims] {
        var claims: [Slot: GesturePayloadClaims] = [:]
        var pressureOrder: [Slot: [TriggerChannel: (Double, Int)]] = [:]
        forEachVoice(in: slot) { key, voice in
            guard voice.phase(at: time).on else { return }
            switch voice.step {
            case let .digital(id): claims[key.slot, default: .init()].actions.insert(id)
            case let .mouseDown(button): claims[key.slot, default: .init()].mouse.insert(button)
            case let .keyDown(button): claims[key.slot, default: .init()].keys.insert(button)
            case let .triggerPressure(channel, amount), let .triggerPulse(channel, amount, _):
                let order = (voice.sendOnRelease ? voice.window?.lowerBound ?? voice.start : voice.start, key.index)
                if let newer = pressureOrder[key.slot]?[channel], newer > order { return }
                claims[key.slot, default: .init()].pressure[channel] = amount
                pressureOrder[key.slot, default: [:]][channel] = order
            default: break
            }
        }
        return claims
    }
    func claims(for slot: Slot, at time: Double) -> GesturePayloadClaims {
        claimsBySlot(at: time, only: slot)[slot] ?? .init()
    }

    func macroLeases(for slot: Slot, control: UUID, at time: Double, priority: Int, order: Int = 0,
                     retained: Bool = false) -> [SustainedMacroLease] {
        var result: [SustainedMacroLease] = []
        forEachVoice(in: slot) { key, voice in
            guard case .fixedStick = voice.step else { return }
            let on = voice.phase(at: time).on
            // A pending activation cannot reserve a channel; live repeat gaps retain ownership.
            guard on || (!voice.released && !voice.sendOnRelease && GestureDeadline.reached(voice.start, at: time)
                         && (voice.timing.repeatMilliseconds != nil || voice.cycle != nil)) else { return }
            result.append(.init(id: voice.id, control: control, program: .init(steps: [voice.step], source: ""),
                         priority: priority, started: voice.start, order: order*64 + key.index, active: on, retained: retained))
        }
        return result
    }
}

extension ControllerPayloadStep {
    var timingTarget: RingOutputKey? {
        switch self {
        case let .digital(action): return .digital(action)
        case let .triggerPressure(channel, _), let .triggerPulse(channel, _, _): return .trigger(channel)
        case let .keyDown(key): return .key(key)
        case let .mouseDown(button): return .mouse(button)
        case let .fixedStick(macro): return .fixedStick(macro.channel)
        default: return nil
        }
    }
}
