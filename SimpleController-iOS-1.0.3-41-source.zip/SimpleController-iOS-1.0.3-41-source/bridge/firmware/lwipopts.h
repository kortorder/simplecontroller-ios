#pragma once
#define NO_SYS 1
#define LWIP_SOCKET 0
#define LWIP_NETCONN 0
#define LWIP_TCP 0
#define LWIP_UDP 1
#define LWIP_IPV4 1
#define LWIP_IPV6 0
#define LWIP_ARP 1
#define LWIP_ETHERNET 1
#define LWIP_ICMP 1
#define LWIP_DHCP 1
#define LWIP_DNS 0
#define LWIP_NETIF_HOSTNAME 1
#define LWIP_NETIF_STATUS_CALLBACK 1
#define LWIP_NETIF_LINK_CALLBACK 1
#define MEM_ALIGNMENT 4
#define MEM_SIZE 16384
#if defined(SC_CHAIR_RELAY) && SC_CHAIR_RELAY
// DHCP retains one PCB; the app listener and optional chair socket need two more.
#define MEMP_NUM_UDP_PCB 3
#else
#define MEMP_NUM_UDP_PCB 2
#endif
#define MEMP_NUM_SYS_TIMEOUT 12
#define PBUF_POOL_SIZE 16
#define LWIP_STATS 0
#define LWIP_CHKSUM_ALGORITHM 3
#define LWIP_SINGLE_NETIF 1
#define LWIP_DHCP_DOES_ACD_CHECK 0
