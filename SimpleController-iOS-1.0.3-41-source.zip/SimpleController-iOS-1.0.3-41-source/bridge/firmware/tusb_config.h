#pragma once
#include "pico/stdlib.h"
#define CFG_TUSB_MCU OPT_MCU_RP2040
#define CFG_TUSB_OS OPT_OS_PICO
#define CFG_TUSB_RHPORT0_MODE (OPT_MODE_DEVICE | OPT_MODE_FULL_SPEED)
#define CFG_TUD_ENDPOINT0_SIZE 64
#if SC_USB_XINPUT
#define CFG_TUD_HID 0
#else
#define CFG_TUD_HID 1
#endif
#define CFG_TUD_HID_EP_BUFSIZE 16
#define CFG_TUD_CDC 0
#define CFG_TUD_MSC 0
#define CFG_TUD_MIDI 0
#define CFG_TUD_VENDOR 0
